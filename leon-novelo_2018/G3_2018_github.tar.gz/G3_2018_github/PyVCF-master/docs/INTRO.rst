Introduction
============

.. include:: ../README.rst
