
PyVCF - A Variant Call Format Parser for Python 
===============================================

Contents:

.. toctree::
   :maxdepth: 2

   INTRO
   API
   FILTERS
   HISTORY
   

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

