Test data from GATK 1.4-9 and freebayes 0.9.4.


