R --no-save --args 1.csv 1_out.csv < NBmodel_WITHBOTH8_gammaalphadeltainboth.r
