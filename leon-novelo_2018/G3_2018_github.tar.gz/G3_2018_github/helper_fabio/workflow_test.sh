#!/bin/bash

module load sw/aligners/bwa/0.7.10
module load sw/bio/samtools/0.1.19



#This workflow is used to perform a test run of all the steps. We use already splitted fastq files, since that step shouldn't be causing problems

FASTQDIR=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18
TESTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/smalltest
head -n40000 $FASTQDIR/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001.fastq > $TESTDIR/smalltest.fq


SCRIPTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/scripts/helper_fabio
cd $SCRIPTDIR
./test_fastqSplitDups.sh $TESTDIR $TESTDIR/smalltest.fq


LANE1=L001

#Alternative haplotype alignment
REFERENCE=/genomes/vitis_vinifera/assembly/reference/12xCHR_alternative_aplotype/vitis_vinifera_entav_alternative.fasta
BAMDIR=$TESTDIR/ALT
if [ ! -e $BAMDIR ]; then mkdir -p $BAMDIR; fi
FASTQFILE=smalltest.fq
BAMFILE=${FASTQFILE/fq/bam}
SAMFILE=${FASTQFILE/fq/sam}
bwa mem -t 8 -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${TESTDIR}/${FASTQFILE} > ${BAMDIR}/$SAMFILE
samtools import ${REFERENCE} ${BAMDIR}/$SAMFILE ${BAMDIR}/$BAMFILE
samtools sort ${BAMDIR}/$BAMFILE ${BAMDIR}/${BAMFILE/.bam/_sorted}
samtools index ${BAMDIR}/${BAMFILE/.bam/_sorted.bam}




#Reference haplotype alignment
REFERENCE=/genomes/vitis_vinifera/assembly/reference/12xCHR/vitis_vinifera_12xCHR.fasta
BAMDIR=$TESTDIR/REF
if [ ! -e $BAMDIR ]; then mkdir -p $BAMDIR; fi
FASTQFILE=smalltest.fq
BAMFILE=${FASTQFILE/fq/bam}
SAMFILE=${FASTQFILE/fq/sam}
bwa mem -t 8 -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${TESTDIR}/${FASTQFILE} > ${BAMDIR}/$SAMFILE
samtools import ${REFERENCE} ${BAMDIR}/$SAMFILE ${BAMDIR}/$BAMFILE
samtools sort ${BAMDIR}/$BAMFILE ${BAMDIR}/${BAMFILE/.bam/_sorted}
samtools index ${BAMDIR}/${BAMFILE/.bam/_sorted.bam}



$SCRIPTDIR/sam_compare_bychrom.sh $TESTDIR/ALT/$SAMFILE $TESTDIR/REF/$SAMFILE $TESTDIR/ase_counts/smalltest $TESTDIR/smalltest.fq /projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/chr1_random.bed


########################################################
#
#Problems with sma_compare.py
#Looks like it is not able to report statistics for small regions
#Try aligning to the transcriptome
#
########################################################



LANE1=L001
TESTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/smalltest

#Alternative haplotype alignment
REFERENCE=/projects/vitis/genes/sequences/V2.1/V2.1.mRNA.fa
BAMDIR=$TESTDIR/TRASCALT
if [ ! -e $BAMDIR ]; then mkdir -p $BAMDIR; fi
FASTQFILE=smalltest.fq
BAMFILE=${FASTQFILE/fq/bam}
SAMFILE=${FASTQFILE/fq/sam}
bwa mem -t 8 -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${TESTDIR}/${FASTQFILE} > ${BAMDIR}/$SAMFILE
samtools import ${REFERENCE} ${BAMDIR}/$SAMFILE ${BAMDIR}/$BAMFILE
samtools sort ${BAMDIR}/$BAMFILE ${BAMDIR}/${BAMFILE/.bam/_sorted}
samtools index ${BAMDIR}/${BAMFILE/.bam/_sorted.bam}




#Reference haplotype alignment
REFERENCE=/projects/vitis/genes/sequences/V2.1/V2.1.mRNA.fa
BAMDIR=$TESTDIR/TRASCREF
if [ ! -e $BAMDIR ]; then mkdir -p $BAMDIR; fi
FASTQFILE=smalltest.fq
BAMFILE=${FASTQFILE/fq/bam}
SAMFILE=${FASTQFILE/fq/sam}
bwa mem -t 8 -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${TESTDIR}/${FASTQFILE} > ${BAMDIR}/$SAMFILE
samtools import ${REFERENCE} ${BAMDIR}/$SAMFILE ${BAMDIR}/$BAMFILE
samtools sort ${BAMDIR}/$BAMFILE ${BAMDIR}/${BAMFILE/.bam/_sorted}
samtools index ${BAMDIR}/${BAMFILE/.bam/_sorted.bam}


samtools view -SH $TESTDIR/TRASCALT/$SAMFILE > $TESTDIR/trasc_header.txt
sed -e $'s/@SQ\tSN://g' $TESTDIR/trasc_header.txt > $TESTDIR/halfway.txt
sed -e $'s/\tLN:/\t10000000\t/g' $TESTDIR/halfway.txt > $TESTDIR/transcriptome.bed

cut -f1 $TESTDIR/transcriptome.bed > $TESTDIR/faket.bed

$SCRIPTDIR/sam_compare_bychrom.sh $TESTDIR/TRASCALT/$SAMFILE $TESTDIR/TRASCREF/$SAMFILE $TESTDIR/ase_counts/smalltest $TESTDIR/smalltest.fq $TESTDIR/faket.bed







#########################
#OLD STUFF BELOW!!!!!
#########################



SCRIPTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/scripts/helper_fabio/
cd $SCRIPTDIR
#Perform alignment, import to bam and sort
./align.sh

#Split sorted bams by chr because sam_compare will be kille for memery eveno on 128Gb machines
BAMDIR=/projects/novabreed/share/marroni/collaborations/Lauren/dna_distinct_align/ALT
./split_by_chr.sh ${BAMDIR}/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_distinct_sorted.bam ${BAMDIR}/chr
./split_by_chr.sh ${BAMDIR}/exp_292_p_noir_vcr18_1_CGTACTAG_L002_MERGED_001_distinct_sorted.bam ${BAMDIR}/chr


BAMDIR=/projects/novabreed/share/marroni/collaborations/Lauren/dna_distinct_align/REF
./split_by_chr.sh ${BAMDIR}/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_distinct_sorted.bam ${BAMDIR}/chr
./split_by_chr.sh ${BAMDIR}/exp_292_p_noir_vcr18_1_CGTACTAG_L002_MERGED_001_distinct_sorted.bam ${BAMDIR}/chr



BAMALT=/projects/novabreed/share/marroni/collaborations/Lauren/dna_distinct_align/ALT
BAMREF=/projects/novabreed/share/marroni/collaborations/Lauren/dna_distinct_align/REF
#Run samcompare on files splitted by chromosomes
SAMFILE=exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_distinct_sorted.sam
for MYCHR in chr1_random
#for MYCHR in chr1_random chr1 chr2 chr3 chr4_random chr4 chr5 chr5_random chr6 chr7 chr7_random chr8 chr9 chr9_random \
#chr10 chr10_random chr11 chr11_random chr12 chr12_random chr13 chr13_random chr14 chr15 chr16 chr16_random chr17 chr17_random chr18 chr18_random chr19 chrUn
do
./sam_compare_bychrom.sh \
$BAMREF/chr/${MYCHR}_$SAMFILE \
$BAMALT/chr/${MYCHR}_$SAMFILE \
/projects/novabreed/share/marroni/collaborations/Lauren/dna_distinct_align/ase_counts/$MYCHR \
/projects/novabreed/share/marroni/collaborations/Lauren/qc_dna_p_noir_vcr18/fastq_split_dups/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_distinct.fq  
done 
#Paste the two lines below to run on cluster
#>${SCRIPTDIR}/${MYCHR}.out 2>>${SCRIPTDIR}/${MYCHR}.err \
#| -N ase_$MYCHR -l mem=32G,vmem=32G,walltime=8:00:00,nodes=1:ppn=1


#Try to sort by name 
#samtools view -Sb $BAMREF/chr/${MYCHR}_$SAMFILE 


