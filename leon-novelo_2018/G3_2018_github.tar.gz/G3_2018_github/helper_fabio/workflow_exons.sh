#!/bin/bash

#Here we assume we already have used the fastqsplitduplicates scripts, i.e. we want to align without duplicate reads.
# for this we have to use ./run_fastqSplitDups.sh or, even better ./test_fastqSplitDups.sh
SCRIPTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/scripts/helper_fabio
cd $SCRIPTDIR

#To be run only once to create the multifasta we need. I actually used the multifasta having one entry per exon.
./create_alt_transcriptomes.sh
module load sw/aligners/bowtie/2.0.2
samtools faidx /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/ALT_exons.fa
samtools faidx /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_exons.fa
bowtie2-build /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/ALT_exons.fa /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/ALT_exons
bowtie2-build /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_exons.fa /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_exons
PICARD=/iga/stratocluster/packages/sw/bio/picard-tools/1.88
java -jar $PICARD/CreateSequenceDictionary.jar R= /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/ALT_exons.fa O= /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/ALT_exons.dict
java -jar $PICARD/CreateSequenceDictionary.jar R= /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_exons.fa O= /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_exons.dict
#


BASEFQ=exp_292_p_noir_vcr18_1_CGTACTAG_L001_R1_001_distinct.fq
BASESAM=${BASEFQ/.fq/.sam}
BASEBAM=${BASEFQ/.fq/.bam}
BASESORT=${BASEFQ/.fq/_sorted}
module load sw/aligners/bowtie/2.0.2
bowtie2 -x /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/ALT_exons -U /projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/fastq_split_dups/$BASEFQ -p8 -k1 -S /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/$BASESAM

bowtie2 -x /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_exons -U /projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/fastq_split_dups/$BASEFQ -p8 -k1 -S /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/$BASESAM

# Import to bam and sort for downstream analyses
module load sw/bio/samtools/0.1.19
samtools import /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/ALT_exons.fa /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/$BASESAM /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/$BASEBAM 
samtools sort -@ 8 -m 1G /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/$BASEBAM /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/$BASESORT

samtools import /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_exons.fa /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/$BASESAM /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/$BASEBAM 
samtools sort -@ 8 -m 1G /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/$BASEBAM /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/$BASESORT


#Do precalling with GATK
./workflow_GATK.sh /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT \
/projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/ALT_exons.fa \
/projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/${BASESORT}.bam \
ALT

./workflow_GATK.sh /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF \
/projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_exons.fa \
/projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/${BASESORT}.bam \
REF


#Lines in these part are only needed to patch a bug in GATK (throws an error if names contains "=")

samtools view -H /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/REF_realigned.bam | sed -e '/s/=/_/g' > /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/header.txt

samtools reheader /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/header.txt /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/REF_realigned.bam > /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/REF2_realigned.bam
samtools index /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/REF2_realigned.bam /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/RE2F_realigned.bam.bai

samtools reheader /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/header.txt /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/ALT_realigned.bam > /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/ALT2_realigned.bam
samtools index /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/ALT2_realigned.bam /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/ALTF_realigned.bam.bai

#Do SNP calling
./only_SNP_call_GATK.sh /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/SNP /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_exons.fa

#Build alternative reference
./alternate_ref_GATK.sh /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/UPDATED.fasta /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_exons.fa /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/SNP/both.vcf


#Some work had to be done to remove exons including Ns, because that give errors!
#Basically I removed exons that gave errors from the file exon_fusion.bed
# and then ran samtools to extract from the bam the reads that did not belong to those exons. 
#Still I can't understand the reason why this error is given. 
#samtools view -bh -L /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/exon_fusion.bed /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/REF.tmp.3.bam > /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/REF.tmp.4.bam
#Also, had to rehead the bam
#samtools reheader /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/new_header.txt /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/REF.tmp.4.bam > /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/REF.tmp.3.bam

#then I recopied back the bam file
# cp /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/REF.tmp.4.bam /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/REF.tmp.3.bam
#And remember to re-index the file, otherwise everything will be useless
#samtools index /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/REF.tmp.3.bam /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/REF.tmp.3.bai



#SAME with the ALT files
#samtools view -bh -L /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/exon_fusion.bed /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/ALT.tmp.3.bam > /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/ALT.tmp.4.bam
# cp /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/ALT.tmp.4.bam /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/ALT.tmp.3.bam
#samtools index /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/ALT.tmp.3.bam /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/ALT.tmp.3.bai
#Some serious fix is needed


BAMALT=/projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/$BASESAM
BAMREF=/projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/$BASESAM
FQFILE=/projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/fastq_split_dups/$BASEFQ
OUTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ase_counts
FUSIONFILE=/projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/exon_fusion.bed
#CREATE FUSION FILE FROM SAM
#NEEDE ONLY ONCE
./fusion_from_sam.sh $BAMALT $FUSIONFILE

./sam_compare_bychrom.sh $BAMREF $BAMALT $OUTDIR $FQFILE $FUSIONFILE





#OLD STUFF BELOW




#Run samcompare on files splitted by chromosomes
#Using one read of 100bp it is also possible to run on tocai the script sam_compare_1st_read.qsub to perform analyses on the whole dataset
BAMALT=/projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/ALT
BAMREF=/projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/REF
SAMFILE=exp_292_p_noir_vcr18_1_CGTACTAG_L001_R1_001_distinct_sorted.sam
FASTQFILE=exp_292_p_noir_vcr18_1_CGTACTAG_L001_R1_001_distinct.fq
FUSION=/projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/chr1_random.bed
for MYCHR in chr1_random
#for MYCHR in chr1_random chr1 chr2 chr3 chr4_random chr4 chr5 chr5_random chr6 chr7 chr7_random chr8 chr9 chr9_random \
#chr10 chr10_random chr11 chr11_random chr12 chr12_random chr13 chr13_random chr14 chr15 chr16 chr16_random chr17 chr17_random chr18 chr18_random chr19 chrUn
do
./sam_compare_bychrom.sh \
$BAMREF/chr/${MYCHR}_${SAMFILE} \
$BAMALT/chr/${MYCHR}_${SAMFILE} \
/projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/ase_counts/$MYCHR \
/projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/fastq_split_dups/$FASTQFILE \
$FUSION
done 
#Paste the two lines below to run on cluster
#>${SCRIPTDIR}/${MYCHR}.out 2>>${SCRIPTDIR}/${MYCHR}.err \
#| -N ase_$MYCHR -l mem=32G,vmem=32G,walltime=8:00:00,nodes=1:ppn=1

###########################################################################
#
#Run The same workflow on the second read
#Slight changes are possbile as I updated the pipeline
#
###########################################################################


SCRIPTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/scripts/helper_fabio/
cd $SCRIPTDIR

#Split fastq based on uniqueness
./test_fastqSplitDups.sh /projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna_R2 /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/exp_292_p_noir_vcr18_1_CGTACTAG_L001_R2_001.fq

