#!/bin/bash

################################
# REALIGNER PROJECT VIGNETO
################################

#nodes=1:ppn=4,mem=16G,vmem=16G,walltime=30:00:00
show_usage() {
echo "Usage: ${0##/*} working_dir ref_file input variety"
echo
echo "working_dir: working directory. Files will be saved here."
echo "ref_file: reference file in fasta format"
echo "input: name of alignment file in BAM format"
echo "variety: sample name, used as distinguishable part of file name"
echo
exit
}

# Minimum number of arguments needed by this program
MINARGS=4

# get the number of command-line arguments given
ARGC=$#

# check to make sure enough arguments were given or exit
if [[ $ARGC -lt $MINARGS ]] ; then
 echo
 show_usage
fi


#FIXED PARAMETERS
GATK=/iga/stratocluster/packages/sw/bio/gatk/3.3-0/GenomeAnalysisTK.jar
PICARD=/iga/stratocluster/packages/sw/bio/picard-tools/1.88
tmp_dir=/projects/vigneto/share/marroni/tmp
#REF=/genomes/vitis_vinifera/assembly/reference/12xCHR/vitis_vinifera_12xCHR.fasta
#DIR=/projects/vigneto/share/marroni/chim_search/simul/merged


#BEGIN RUNNING on 4th JULY PN and pblanc
DIR=$1
REF=$2
INPUT=$3
VARIETY=$4

# !!!!!! attenzione ai percorsi!!!
#directory in cui lavorare
#cd /projects/vigneto/share/marroni/chim_search/simul/del_blanc_meun

# parametri che devi settare:
#DIR=/projects/vigneto/share/marroni/chim_search/simul/del_blanc_meun
#REF=/genomes/vitis_vinifera/assembly/reference/12xCHR/vitis_vinifera_12xCHR.fasta
#INPUT=/projects/vigneto/share/marroni/chim_search/simul/del_blanc_meun/orig_pinot_blanc_R5_uniq.bam
#VARIETY=Pblanc_del
cd $DIR


########## CLEAN SAM ################
# Clean sam to perform fix-up

if [ ! -e ${VARIETY}.tmp.bam ]; then
java -Xmx6g -Djava.io.tmpdir=$tmp_dir -jar ${PICARD}/CleanSam.jar \
        INPUT=${INPUT} \
        OUTPUT=${VARIETY}.tmp.bam \
        VALIDATION_STRINGENCY=LENIENT
fi
echo "Done sam cleaning"


########## ADDorREPLACEGROUPS and FIXMate ################

#AddOrReplaceGroups step
if [ ! -e ${VARIETY}.tmp.2.bam ]
then
java -Xmx6g -Djava.io.tmpdir=$tmp_dir -jar $PICARD/AddOrReplaceReadGroups.jar \
        INPUT=${VARIETY}.tmp.bam \
        OUTPUT=${VARIETY}.tmp.2.bam \
        SORT_ORDER=coordinate \
        RGID=${VARIETY} \
        RGLB=${VARIETY} \
        RGPL=hiseq \
        RGPU=${VARIETY} \
        RGSM=${VARIETY} \
        CREATE_INDEX=True \
        VALIDATION_STRINGENCY=LENIENT
fi
echo "Done replacing readgroups"
# fix mate information (still checking if the output file exists)
if [ ! -e ${VARIETY}.tmp.3.bam ]
then
java -Xmx6g -jar $PICARD/FixMateInformation.jar \
        INPUT=${VARIETY}.tmp.2.bam \
        OUTPUT=${VARIETY}.tmp.3.bam \
        TMP_DIR=$tmp_dir \
        SORT_ORDER=coordinate \
        CREATE_INDEX=True \
        VALIDATION_STRINGENCY=LENIENT
fi
echo "Done fixing mate information"

#Running July 2
########## INTERVALS calculation ################

java -Xmx6g -Djava.io.tmpdir=$tmp_dir -jar $GATK \
        -I ${VARIETY}.tmp.3.bam \
        -R $REF \
        -T RealignerTargetCreator \
        -o ${VARIETY}_uniq.intervals \
        --num_threads 4 &&



########## REALIGNMENT ################

java -Xmx6g -Djava.io.tmpdir=$tmp_dir -jar $GATK \
        -I ${VARIETY}.tmp.3.bam \
        -R $REF \
        -T IndelRealigner \
        -targetIntervals ${VARIETY}_uniq.intervals \
        -o ${VARIETY}_realigned.bam &&

samtools index ${VARIETY}_realigned.bam &&

rm ${VARIETY}.tmp.*

########## VARIATION DETECTION ################
#Trick to run only once, not sure it works...

#if [[ $VARIETY == pinot_meunier ]] ; then
#java -Xmx12g -Djava.io.tmpdir=$tmp_dir -jar $GATK \
#	-R $REF \
#	-T UnifiedGenotyper \
#	-I /projects/vitis/lanes/alignments/BWA/dna/pinot_blanc_R5/pinot_blanc_R5_realigned.bam \
#	-I /projects/vitis/lanes/alignments/BWA/dna/pinot_gris_R6/pinot_gris_R6_realigned.bam \
#	-I /projects/vitis/lanes/alignments/BWA/dna/pinot_meunier/pinot_meunier_realigned.bam \
#	-o /projects/vigneto/share/marroni/chim_search/pinot_snp/pinot.raw.variants.vcf \
#	--reference_sample_name vitis \
#	--genotype_likelihoods_model BOTH \
#	--num_threads 8
#fi

