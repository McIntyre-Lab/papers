split.uniq<-function(input="/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/test.fastq",
					out.distinct="/projects/novabreed/share/marroni/collaborations/Lauren/fastq_R_split_dups/test.distinct.fastq",
					out.duplicated="/projects/novabreed/share/marroni/collaborations/Lauren/fastq_R_split_dups/test.duplicated.fastq",
					out.unique="/projects/novabreed/share/marroni/collaborations/Lauren/fastq_R_split_dups/test.uniq.fastq")
{
library(data.table)
reads<-fread(input,data.table=F,sep="\n",header=F,colClasses="")
mreads<-matrix(reads,nrow=4,byrow=F)

# Create duplicated, unique and distinct files including the whole read information (if it will be too slow we will change)
reads.distinct<-mreads[,!duplicated(mreads[2,])]
reads.duplicated<-mreads[,duplicated(mreads[2,])]
reads.unique<-reads.distinct[,!reads.distinct[2,]%in%reads.duplicated[2,]]

write(reads.distinct,out.distinct,ncol=1)
write(reads.duplicated,out.duplicated,ncol=1)
write(reads.unique,out.unique,ncol=1)


# reads.distinct<-!duplicated(mreads[,2])
# reads.duplicated<-mreads[duplicated(mreads[,2]),2]
# reads.unique<-reads.distinct[!reads.distinct%in%reads.duplicated]


# myvec<-c("a","a","b","c","a")
# reads.distinct<-unique(myvec)
# reads.distinct<-!duplicated(myvec)
# reads.duplicated<-myvec[duplicated(myvec)]
# reads.unique<-reads.distinct[!reads.distinct%in%reads.duplicated]

# browser()

# tochange<-seq(1,nrow(read.one),by=2)
# read.one[tochange,]<-""
# read.two<-fread(read2,data.table=F,sep="\n",header=F)
# merged<-apply(cbind(read.one,read.two),1,paste,sep="",collapse="")
# write(merged,output)
}
