merge.reads<-function(read1="/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/exp_292_p_noir_vcr18_1_CGTACTAG_L001_R1_001.fastq",
					read2="/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/exp_292_p_noir_vcr18_1_CGTACTAG_L001_R2_001.fastq",
					output="/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/exp_292_p_noir_vcr18_1_CGTACTAG_L001_merged_001.fastq")
{
library(data.table)
read.one<-fread(read1,data.table=F,sep="\n",header=F,colClasses="")
tochange<-seq(1,nrow(read.one),by=2)
read.one[tochange,]<-""
read.two<-fread(read2,data.table=F,sep="\n",header=F)
merged<-apply(cbind(read.one,read.two),1,paste,sep="",collapse="")
write(merged,output)
}


# The one below is probably incomplete
merge.reads.scan<-function(read1="/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/exp_292_p_noir_vcr18_1_CGTACTAG_L001_R1_001.fastq",
						read2="/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/exp_292_p_noir_vcr18_1_CGTACTAG_L001_R2_001.fastq",
						output="/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/exp_292_p_noir_vcr18_1_CGTACTAG_L001_merged_001.fastq")
{
library(data.table)
read.one<-scan(read1,what="",sep="\n")
tochange<-seq(1,length(read.one),by=2)
browser()
read.one[tochange]<-""
read.two<-fread(read2,data.table=F,sep="\n",header=F)
merged<-paste(cbind(read.one,read.two),1,sep="",collapse="")
}



