#!/bin/bash
if [ "$#" -ne 2 ]; then
echo "Usage: $0 input.bam output_dir" 
exit 1
fi

module load sw/bio/samtools/0.1.19

BAMFILE=$1
OUTNAME=$(basename $BAMFILE)
BAMDIR=$2

for MYCHR in chr1 chr1_random chr2 chr3 chr4_random chr4 chr5 chr5_random chr6 chr7 chr7_random chr8 chr9 chr9_random \
chr10 chr10_random chr11 chr11_random chr12 chr12_random chr13 chr13_random chr14 chr15 chr16 chr16_random chr17 chr17_random chr18 chr18_random chr19 chrUn
do
samtools view $BAMFILE ${MYCHR} > $BAMDIR/${MYCHR}_${OUTNAME/.bam/.sam}
done 
