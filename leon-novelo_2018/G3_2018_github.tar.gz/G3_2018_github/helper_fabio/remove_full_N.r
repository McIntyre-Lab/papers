#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)
# test if there is at least one argument: if not, return an error
if (length(args)<2) {
  stop("At least two arguments must be supplied (input file).n", call.=FALSE)
} 
library(ShortRead)
library(Biostrings)
# myfile<-c("/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/ALT_PN_fusions.fasta",
# "/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/REF_PN_fusions.fasta")
# outfile<-c("/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/ALT_PN_noN_fusions.fasta",
# "/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/REF_PN_noN_fusions.fasta")
myfile<-args[1]
outfile<-args[2]

stringfasta <- readDNAStringSet(myfile, "fasta")
pino<-alphabetFrequency(stringfasta, baseOnly=TRUE)
#Identify the infamous exon which only includes "Ns"
remove.me<-names(stringfasta[pino[,"A"]+pino[,"C"]+pino[,"G"]+pino[,"T"]==0])
cleanfasta<-stringfasta[!names(stringfasta)%in%remove.me]
writeFasta(cleanfasta,outfile)

