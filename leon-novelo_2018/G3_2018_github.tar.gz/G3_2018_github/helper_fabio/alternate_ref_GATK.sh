#!/bin/bash

################################
# CREATE ALTERNATIVE REFERENCE
################################

show_usage() {
echo "Usage: ${0##/*} updated_reference.fasta ref_file.fasta input.vcf"
echo
echo "updated_reference.fasta: full name for the updated reference in fasta format"
echo "ref_file.fasta: reference file in fasta format"
echo "input.vcf: vcf containing variants that will be used to produce the updated reference"
echo
exit
}

# Minimum number of arguments needed by this program
MINARGS=3

# get the number of command-line arguments given
ARGC=$#

# check to make sure enough arguments were given or exit
if [[ $ARGC -lt $MINARGS ]] ; then
 echo
 show_usage
fi


#FIXED PARAMETERS
GATK=/iga/stratocluster/packages/sw/bio/gatk/3.3-0/GenomeAnalysisTK.jar
PICARD=/iga/stratocluster/packages/sw/bio/picard-tools/1.88
tmp_dir=/projects/novabreed/share/marroni/tmp
#REF=/genomes/vitis_vinifera/assembly/reference/12xCHR/vitis_vinifera_12xCHR.fasta
#DIR=/projects/vigneto/share/marroni/chim_search/simul/merged


#BEGIN RUNNING on 4th JULY PN and pblanc
OUTFASTA=$1
REF=$2
INVCF=$3
java -Xmx12g -Djava.io.tmpdir=$tmp_dir -jar $GATK \
	-R $REF \
	-T FastaAlternateReferenceMaker \
	-o ${OUTFASTA} \
	-V $INVCF

