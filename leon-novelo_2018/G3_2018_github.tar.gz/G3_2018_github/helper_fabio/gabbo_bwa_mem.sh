bwa mem -t 6 -M -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${fastafile} ${infile1} ${infile2} > $samfile


samtools idxstats F7_AAGACG_001_filtered_paired_sort.bam > stat.txt

bamfile=${samfile/.sam/.bam}
samtools import $fastafile $samfile $bamfile


samfileu=${saifileu/.sai/_MEM.sam}
bwa mem -t 8 -M -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${fastafile} $infileu > $samfileu
bamfileu=${samfileu/.sam/.bam}
samtools import $fastafile $samfileu $bamfileu
bamall=${bamfileu/unpaired_MEM.bam/MEM_all.bam}

samtools merge $bamall $bamfile $bamfileu
samtools sort $bamall $sortfile


nodupfile=${sortfile/_all_sort/_nodup}

usamfile=${sortfile/_all_sort/_U}".sam"
ubamfile=${usamfile/_U.sam/_U.bam}
sameusam=${ubamfile/_U.bam/_U_samechr.sam}
sameubam=${sameusam/_U_samechr.sam/_U_samechr.bam}
usortfile=${ubamfile/_U.bam/_sort}
statfile="mapping_"${usortfile/_sort/.txt}
insertstatfile=${samfile/.sam/_insertsize.txt}

samtools view -H ${sortfile}.bam > $usamfile

samtools view ${sortfile}.bam | awk '{ if ( $13 == "XT:A:U" ) {print $0} }' >> $usamfile

samtools import $fastafile $usamfile $ubamfile
samtools view ${ubamfile} | cut -f2 |sort|uniq -c > $statfile
rm $usamfile

