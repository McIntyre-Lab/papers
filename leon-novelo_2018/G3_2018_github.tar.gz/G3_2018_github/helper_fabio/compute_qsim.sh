#!/bin/bash

#This scripts runs all the needed steps to compute qsim (the bias factor to be used in the bayesian model for ASE estimation)

#I am sorry, it is not parameterized!!!

SCRIPTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/scripts
cd $SCRIPTDIR


#Load all the needed modules
module load lang/python/2.7.3
module load sw/bio/samtools/0.1.19
module load sw/aligners/bowtie/2.0.2


#Simulate the reads
python simulate_reads.py -i /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/REF_PN_noN_fusions.fasta -o /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/REF_PN_noN_fusions.fq -n 100 --prefix R

python simulate_reads.py -i /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/ALT_PN_noN_fusions.fasta -o /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/ALT_PN_noN_fusions.fq -n 100 --prefix A

#paste the two files together

cat /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/REF_PN_noN_fusions.fq /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/ALT_PN_noN_fusions.fq > /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/BOTH_PN_noN_fusions.fq

#Align the file containing reads originating from both references against both references
#We use bowtie2 to be consistent wiht what had been done on RNAseq
MYFILE=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/BOTH_PN_noN_fusions.fq
BASEFQ=$(basename $MYFILE)
BASESAM=${BASEFQ/.fq/.sam}
echo $BASEFQ
bowtie2 -x /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/ALT_PN_noN_fusions -U $MYFILE -p8 -k1 -S /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/align_ALT/$BASESAM
bowtie2 -x /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/REF_PN_noN_fusions -U $MYFILE -p8 -k1 -S /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/align_REF/$BASESAM


#Samcompare on the whole file would crash even with 60G ram
#I will create several subsets and run them in parallel


#Total number of reads in the file (including header > 166000000)
#Create several smaller files, each one with approx 20000000 reads. 
SAMA=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/align_ALT/$BASESAM
SAMB=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/align_REF/$BASESAM
#Create header
samtools view -SH $SAMA > /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/header.txt
MYCOUNTS=(321045 20000000 40000000 60000000 80000000 100000000 120000000 140000000 160000000 180000000)
MYLENGTH=${#MYCOUNTS[@]}
for (( i=1; i<${MYLENGTH}; i++ ))
do
echo ${MYCOUNTS[i-1]} ${MYCOUNTS[i]}
#awk -v start=${MYCOUNTS[i-1]} -v end=${MYCOUNTS[i]} '(NR>=0&&NR<=321044)||(NR>=start&&NR<=end)' $SAMA > /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/align_ALT/sm_${MYCOUNTS[i-1]}_${MYCOUNTS[i]}.sam
awk -v start=${MYCOUNTS[i-1]} -v end=${MYCOUNTS[i]} '(NR>=0&&NR<=321044)||(NR>=start&&NR<=end)' $SAMB > /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/align_REF/sm_${MYCOUNTS[i-1]}_${MYCOUNTS[i]}.sam
done




#Loop based on filename. I want to do this to put it in queue even before the files are created
SCRIPTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/scripts
MYFILE=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/BOTH_PN_noN_fusions.fq
#MYCOUNTS=(321045 20000000 40000000 60000000 80000000 100000000 120000000 140000000 160000000 180000000)
MYCOUNTS=(20000000 40000000 60000000 80000000 100000000 120000000 140000000 160000000 180000000)
MYLENGTH=${#MYCOUNTS[@]}
for (( i=1; i<${MYLENGTH}; i++ ))
do
echo ${MYCOUNTS[i-1]} ${MYCOUNTS[i]}
SAMA=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/align_ALT/sm_${MYCOUNTS[i-1]}_${MYCOUNTS[i]}.sam
SAMB=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/align_REF/sm_${MYCOUNTS[i-1]}_${MYCOUNTS[i]}.sam
BASE=$(basename $SAMA)
#echo "cd $SCRIPTDIR/helper_fabio; ./sam_compare_bychrom.sh $SAMA $SAMB /projects/novabreed/share/marroni/collaborations/Lauren/RNA_alignments/ase_counts/${BASE/.sam/} $MYFILE /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_fusion.bed"
echo "cd $SCRIPTDIR/helper_fabio; ./sam_compare_bychrom.sh $SAMA $SAMB /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/ase_counts/${BASE/.sam/} $MYFILE /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_fusion.bed" | qsub -N $BASE -l mem=62G,vmem=62G,walltime=8:00:00
done



#Loop looking for the files in dir
SCRIPTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/scripts
MYFILE=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/BOTH_PN_noN_fusions.fq
for aaa in /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/align_ALT/sm_*
do 
SAMA=$aaa
SAMB=${aaa/_ALT/_REF}
BASE=$(basename $SAMA)
echo "cd $SCRIPTDIR/helper_fabio; ./sam_compare_bychrom.sh $SAMA $SAMB /projects/novabreed/share/marroni/collaborations/Lauren/RNA_alignments/ase_counts/${BASE/.sam/} $MYFILE /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_fusion.bed"
#echo "cd $SCRIPTDIR/helper_fabio; ./sam_compare_bychrom.sh $SAMA $SAMB /projects/novabreed/share/marroni/collaborations/Lauren/RNA_alignments/ase_counts/${BASE/.sam/} $MYFILE /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_fusion.bed" | qsub -N $BASE -l vmem=62G,walltime=8:00:00
done





