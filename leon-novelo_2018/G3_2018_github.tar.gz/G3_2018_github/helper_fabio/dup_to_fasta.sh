#!/bin/bash
if [ "$#" -ne 2 ]; then
echo "Usage: $0 INFILE OUTFILE" 
echo "Where INFILE is the file reporting the number of times a read as been found an the read itself"
echo "adn OUTFILE is the output fasta file	"
exit 1
fi

awk '{ if ( $1 > 20 ) { print ( ">" $1 "\n" $2 ) } }' $1 >$2
