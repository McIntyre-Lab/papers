module load lang/python/2.7.3 
module load sw/bio/samtools/0.1.19

if [ "$#" -ne 5 ]; then
echo "Usage: $0 in.samA in.samB OUTPREFIX orig.fq fusion.bed" 
echo "where:"
echo "Parameter 3: OUTPREFIX is the prefix (including path and beginning of basename) of the ase count files"
echo "Parameter 4: orig.fq is the fastq file from which you obtained the alignment"
echo "Parameter 5: fusion.bed is the fusion file"
exit 1
fi



#### Set Directories
PROJ=/projects/novabreed/share/marroni/collaborations/Lauren
SCRIPTS=$PROJ/scripts

SAMA=$1
SAMB=$2
OUTPUT=$3
FASTQ=$4
FUSION=$5
if [ ! -e $OUTPUT ]; then mkdir $OUTPUT; fi

#### Create LOG directory
LOGS=$SCRIPTS/logs
if [ ! -e $LOGS ]; then mkdir $LOGS; fi

	
    # Run SAM Compare
    python $SCRIPTS/sam_compare.py \
	-d \
        -l 100 \
        -f $FUSION \
        -q $FASTQ \
        -A $SAMA \
        -B $SAMB \
        -c ${OUTPUT}_ase_counts.csv \
        -t ${OUTPUT}_ase_totals.csv \
        -g ${OUTPUT}_test_ase_counts.log








