#!/bin/bash

################################
# REALIGNER PROJECT VIGNETO
################################

#nodes=1:ppn=4,mem=16G,vmem=16G,walltime=30:00:00
show_usage() {
echo "Usage: ${0##/*} working_dir ref_file input variety"
echo
echo "working_dir: working directory. Files will be saved here."
echo "ref_file: reference file in fasta format"
echo
exit
}

# Minimum number of arguments needed by this program
MINARGS=2

# get the number of command-line arguments given
ARGC=$#

# check to make sure enough arguments were given or exit
if [[ $ARGC -lt $MINARGS ]] ; then
 echo
 show_usage
fi


#FIXED PARAMETERS
GATK=/iga/stratocluster/packages/sw/bio/gatk/3.3-0/GenomeAnalysisTK.jar
PICARD=/iga/stratocluster/packages/sw/bio/picard-tools/1.88
tmp_dir=/projects/novabreed/share/marroni/tmp
#REF=/genomes/vitis_vinifera/assembly/reference/12xCHR/vitis_vinifera_12xCHR.fasta
#DIR=/projects/vigneto/share/marroni/chim_search/simul/merged


#BEGIN RUNNING on 4th JULY PN and pblanc
OUTDIR=$1
REF=$2
java -Xmx12g -Djava.io.tmpdir=$tmp_dir -jar $GATK \
	-R $REF \
	-T UnifiedGenotyper \
	-I /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/REF/REF2_realigned.bam \
	-I /projects/novabreed/share/marroni/collaborations/Lauren/transcriptome_alignments/ALT/ALT2_realigned.bam \
	-o ${OUTDIR}/both.vcf \
	--reference_sample_name vitis \
	--genotype_likelihoods_model BOTH \
	--num_threads 24

