#!/bin/bash
if [ "$#" -ne 2 ]; then
echo "Usage: $0 project.dir input.fq" 
exit 1
fi
PROJ=$1
FASTQFILE=$2
#NAME=$(basename ${FASTQFILE/.fastq/})
NAME=$(basename ${FASTQFILE/.fq/})

# Load modules

module load lang/python/2.7.3

#Set directories
SCRIPTS=/projects/novabreed/share/marroni/collaborations/Lauren/scripts

OUTPUT=$PROJ/fastq_split_dups
if [ ! -e $OUTPUT ]; then mkdir -p $OUTPUT; fi

OUTCOUNTS=$PROJ/duplicate_counts
if [ ! -e $OUTCOUNTS ]; then mkdir -p $OUTCOUNTS; fi

OUTLOGS=$PROJ/duplicate_counts/logs
if [ ! -e $OUTLOGS ]; then mkdir -p $OUTLOGS; fi


$SCRIPTS/fastqSplitDups.py -r1 $FASTQFILE --outdir $OUTPUT -o $OUTCOUNTS/${NAME}_duplicate_counts_summary.csv -t $OUTCOUNTS/${NAME}_duplicate_sequences.tsv -g $OUTLOGS/${NAME}_fastqSplitDups.log

