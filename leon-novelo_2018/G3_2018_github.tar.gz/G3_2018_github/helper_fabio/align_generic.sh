#!/bin/bash
if [ "$#" -ne 3 ] && [ "$#" -ne 4 ]; then
echo "Usage: $0 read1.fastq read2.fastq reference.fasta bamdir" 
exit 1
fi
module load sw/aligners/bwa/0.7.5a
module load sw/bio/samtools/0.1.19

if [ "$#" -eq 3 ]; then
READ=$1
REFERENCE=$2
BAMDIR=$3
FASTQFILE=$(basename $READ)
LANE1=PINO
BAMFILE=${FASTQFILE/fq/bam}
SAMFILE=${FASTQFILE/fq/sam}
if [ ! -e $BAMDIR ]; then mkdir -p $BAMDIR; fi
bwa mem -t 8 -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${READ} > ${BAMDIR}/$SAMFILE
#bwa mem -t 8 -M -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${READ} > ${BAMDIR}/$SAMFILE
samtools import ${REFERENCE} ${BAMDIR}/$SAMFILE ${BAMDIR}/$BAMFILE
samtools sort ${BAMDIR}/$BAMFILE ${BAMDIR}/${BAMFILE/.bam/_sorted}
samtools index ${BAMDIR}/${BAMFILE/.bam/_sorted.bam}
fi


if [ "$#" -eq 4 ]; then
READ1=$1
READ2=$2
REFERENCE=$3
BAMDIR=$4
if [ ! -e $BAMDIR ]; then mkdir -p $BAMDIR; fi
FASTQFILE1=$(basename $READ1)
FASTQFILE2=$(basename $READ2)
LANE1=PINO
BAMFILE=${FASTQFILE1/fq/bam}
SAMFILE=${FASTQFILE1/fq/sam}
bwa mem -t 8 -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${READ1} ${READ2} > ${BAMDIR}/$SAMFILE
#bwa mem -t 8 -M -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${READ} ${READ2} > ${BAMDIR}/$SAMFILE
samtools import ${REFERENCE} ${BAMDIR}/$SAMFILE ${BAMDIR}/$BAMFILE
samtools sort ${BAMDIR}/$BAMFILE ${BAMDIR}/${BAMFILE/.bam/_sorted}
samtools index ${BAMDIR}/${BAMFILE/.bam/_sorted.bam}
fi

