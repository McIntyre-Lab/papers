#!/bin/bash

################################
# REALIGNER PROJECT VIGNETO
################################

#nodes=1:ppn=4,mem=16G,vmem=16G,walltime=30:00:00
show_usage() {
echo "Usage: ${0##/*} out_vcf ref_file haplo_or_geno"
echo
echo "out_vcf: Name of output vcf"
echo "ref_file: reference file in fasta format"
echo " haplo_or_geno: write 'haplo' if you want to use haplotypecaller and 'geno' if you want to use UnifiedGenotyper"
echo
exit
}

# Minimum number of arguments needed by this program
MINARGS=3

# get the number of command-line arguments given
ARGC=$#

# check to make sure enough arguments were given or exit
if [[ $ARGC -lt $MINARGS ]] ; then
 echo
 show_usage
fi


#FIXED PARAMETERS
GATK=/iga/stratocluster/packages/sw/bio/gatk/3.3-0/GenomeAnalysisTK.jar
PICARD=/iga/stratocluster/packages/sw/bio/picard-tools/1.88
tmp_dir=/projects/novabreed/share/marroni/tmp
#REF=/genomes/vitis_vinifera/assembly/reference/12xCHR/vitis_vinifera_12xCHR.fasta
#DIR=/projects/vigneto/share/marroni/chim_search/simul/merged


#BEGIN RUNNING on 4th JULY PN and pblanc
OUTFILE=$1
REF=$2
if [ $3 == "geno" ] ; then
java -Xmx12g -Djava.io.tmpdir=$tmp_dir -jar $GATK \
	-R $REF \
	-T UnifiedGenotyper \
	-I /projects/vitis/lanes/alignments/BWA/dna/pinot_noir_VCR18/exp_292_p_noir_vcr18_1_CGTACTAG_uniq_realigned.bam \
	-o ${OUTFILE} \
	--reference_sample_name vitis \
	--genotype_likelihoods_model BOTH \
	--num_threads 8

java -Xmx12g -Djava.io.tmpdir=$tmp_dir -jar $GATK \
	-R $REF \
	-T VariantFiltration \
	-V ${OUTFILE} \
	--filterExpression "QD < 10.0 || FS > 60.0 || MQ < 40.0 || HaplotypeScore > 15.0" \
	--filterName "exorcism" \
	-o ${OUTFILE/.vcf.gz/_filtered.vcf}
fi

if [ $3 == "haplo" ] ; then
java -Xmx12g -Djava.io.tmpdir=$tmp_dir -jar $GATK \
	-R $REF \
	-T HaplotypeCaller \
	-I /projects/vitis/lanes/alignments/BWA/dna/pinot_noir_VCR18/exp_292_p_noir_vcr18_1_CGTACTAG_uniq_realigned.bam \
	-o ${OUTFILE}
fi

