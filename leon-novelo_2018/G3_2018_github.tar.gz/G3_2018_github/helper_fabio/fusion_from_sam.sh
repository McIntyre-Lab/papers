#!/bin/bash
if [ "$#" -ne 2 ]; then
echo "Usage: $0 input.sam fusion.bed" 
exit 1
fi

SAMFILE=$1
OUTFILE=$2
module load sw/bio/samtools/0.1.19
#samtools view -SH $1
#sed -e $'s/@SQ\tSN://g' $TESTDIR/trasc_header.txt > $TESTDIR/halfway.txt
#sed -e $'s/\tLN:/\t10000000\t/g' $TESTDIR/halfway.txt > $TESTDIR/transcriptome.bed

sed -e $'s/\tLN:/\t1\t/g' <(sed -e $'s/@SQ\tSN://g' <(samtools view -SH $1)) > $OUTFILE
