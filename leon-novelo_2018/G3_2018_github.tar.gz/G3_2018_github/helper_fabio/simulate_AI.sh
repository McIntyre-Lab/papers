#!/bin/bash

#This scripts runs all the needed steps perform simulations of AI

#Simulate 60% ALT and 40% REF and their alignment on the REF and ALT references (we do this by sampling sam files)
#ALIGNED on REF

#Length of header (we have the exons, not the chromosomes)

HEADLENGTH=321045
HEADFILE=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/header.txt
for ALIGNTO in REF ALT
do
#Select if the file was the one aligned to ALT or to REF
INSAMFILE=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/align_${ALIGNTO}/BOTH_PN_noN_fusions.sam
#Total number of reads from the merged file (approximately 20000000)
#NREADS=$(wc -l $INSAMFILE | cut -d" " -f1)
NREADS=160000000
#Loop over the possible percentages of reads originating from the ALT allele
for PERCALT in 60 50 40
#60% ALT nd 40% REF
do
PERCREF=$((100-$PERCALT))
mkdir -p /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/${PERCALT}ALT${PERCREF}REF/align_${ALIGNTO}
#Compute the percentage of reads deriving from REF
#Compute the number of reads that we have to sample from each allele
GETALT=$(($NREADS*$PERCALT/100))
GETREF=$(($NREADS*$PERCREF/100))
#Write them to the right files
echo "tail -n +${HEADLENGTH} $INSAMFILE | grep "A_ID" | shuf -n $GETALT > /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/${PERCALT}ALT${PERCREF}REF/align_${ALIGNTO}/${PERCALT}_nohead.sam; 
tail -n +${HEADLENGTH} $INSAMFILE | grep "R_ID" | shuf -n $GETREF > /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/${PERCALT}ALT${PERCREF}REF/align_${ALIGNTO}/${PERCREF}_nohead.sam; 
cat $HEADFILE /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/${PERCALT}ALT${PERCREF}REF/align_${ALIGNTO}/${PERCALT}_nohead.sam /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/${PERCALT}ALT${PERCREF}REF/align_${ALIGNTO}/${PERCREF}_nohead.sam > /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/simulation_qsim/${PERCALT}ALT${PERCREF}REF/align_${ALIGNTO}/${PERCALT}ALT${PERCREF}REF.sam" | qsub -N simul_${PERCALT}_${PERCREF} -l vmem=60G,mem=60G,walltime=24:00:00
done
done

