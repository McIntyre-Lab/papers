#!/bin/bash

SCRIPTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/scripts/helper_fabio/
cd $SCRIPTDIR

#Merge first and second reads using awk. Remember to check that read names have no problems
FASTQDIR=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18
./merge_try.sh $FASTQDIR/exp_292_p_noir_vcr18_1_CGTACTAG_L001_R1_001.fastq $FASTQDIR/exp_292_p_noir_vcr18_1_CGTACTAG_L001_R2_001.fastq \
$FASTQDIR/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001.fastq
./merge_try.sh $FASTQDIR/exp_292_p_noir_vcr18_1_CGTACTAG_L002_R1_001.fastq $FASTQDIR/exp_292_p_noir_vcr18_1_CGTACTAG_L002_R2_001.fastq \
$FASTQDIR/exp_292_p_noir_vcr18_1_CGTACTAG_L002_MERGED_001.fastq



#Identify duplicates and remove them

FASTQDIR=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18
CHECKDIR=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18
if [ ! -e $CHECKDIR ]; then mkdir -p $CHECKDIR; fi

for MYFILE in exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001.fq exp_292_p_noir_vcr18_1_CGTACTAG_L002_MERGED_001.fq
do
SCRIPTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/scripts/helper_fabio
cd $SCRIPTDIR
./test_fastqSplitDups.sh $CHECKDIR $FASTQDIR/$MYFILE
done

#ALIGNMENT STILL TO PERFORM
#Perform alignment, import to bam and sort giving input fastq(s), reference sequence and output bam directory as parameters
# Only three (for SE) or 4 (for PE) parameters accepted
DISTDIR=$CHECKDIR/fastq_split_dups
for MYFILE in exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_distinct.fq exp_292_p_noir_vcr18_1_CGTACTAG_L002_MERGED_001_distinct.fq
do
echo "${SCRIPTDIR}/align_generic.sh $DISTDIR/$MYFILE /genomes/vitis_vinifera/assembly/reference/12xCHR/vitis_vinifera_12xCHR.fasta \
$CHECKDIR/REF >${SCRIPTDIR}/logs/REF_${MYFILE}.out 2>>${SCRIPTDIR}/logs/REF_${MYFILE}.err" | qsub -N align_REF_$MYCHR -l mem=8G,vmem=8G,walltime=8:00:00,nodes=1:ppn=8
echo "SCRIPTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/scripts/helper_fabio; ${SCRIPTDIR}/align_generic.sh $DISTDIR/$MYFILE /genomes/vitis_vinifera/assembly/reference/12xCHR_alternative_aplotype/vitis_vinifera_entav_alternative.fasta \
$CHECKDIR/ALT >${SCRIPTDIR}/logs/ALT_${MYFILE}.out 2>>${SCRIPTDIR}/logs/ALT_${MYFILE}.err" | qsub -N align_ALT_$MYCHR -l mem=8G,vmem=8G,walltime=8:00:00,nodes=1:ppn=8
done


#Split sorted bams by chr because sam_compare will be killed for memery eveno on 128Gb machines
BAMDIR=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/ALT
./split_by_chr.sh ${BAMDIR}/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_distinct_sorted.bam ${BAMDIR}/chr
./split_by_chr.sh ${BAMDIR}/exp_292_p_noir_vcr18_1_CGTACTAG_L002_MERGED_001_distinct_sorted.bam ${BAMDIR}/chr


BAMDIR=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/REF
./split_by_chr.sh ${BAMDIR}/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_distinct_sorted.bam ${BAMDIR}/chr
./split_by_chr.sh ${BAMDIR}/exp_292_p_noir_vcr18_1_CGTACTAG_L002_MERGED_001_distinct_sorted.bam ${BAMDIR}/chr



BAMALT=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/ALT
BAMREF=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/REF
#Run samcompare on files splitted by chromosomes
SAMFILE=exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_distinct_sorted.sam
#SAMFILE=exp_292_p_noir_vcr18_1_CGTACTAG_L002_MERGED_001_distinct_sorted.sam
#for MYCHR in chr1_random
for MYCHR in chr1_random chr1 chr2 chr3 chr4_random chr4 chr5 chr5_random chr6 chr7 chr7_random chr8 chr9 chr9_random \
chr10 chr10_random chr11 chr11_random chr12 chr12_random chr13 chr13_random chr14 chr15 chr16 chr16_random chr17 chr17_random chr18 chr18_random chr19 chrUn
do
echo "${SCRIPTDIR}/sam_compare_bychrom.sh \
$BAMREF/chr/${MYCHR}_$SAMFILE \
$BAMALT/chr/${MYCHR}_$SAMFILE \
/projects/novabreed/share/marroni/collaborations/Lauren/dna_distinct_align/ase_counts/$MYCHR \
/projects/novabreed/share/marroni/collaborations/Lauren/qc_dna_p_noir_vcr18/fastq_split_dups/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_distinct.fq >${SCRIPTDIR}/logs/${MYCHR}.out 2>>${SCRIPTDIR}/logs/${MYCHR}.err" |\
qsub -N ase_$MYCHR -l mem=30G,vmem=30G,walltime=4:00:00,nodes=1:ppn=1 
done  
#Paste the two lines below to run on cluster
#>${SCRIPTDIR}/${MYCHR}.out 2>>${SCRIPTDIR}/${MYCHR}.err \
#| -N ase_$MYCHR -l mem=32G,vmem=32G,walltime=8:00:00,nodes=1:ppn=1



