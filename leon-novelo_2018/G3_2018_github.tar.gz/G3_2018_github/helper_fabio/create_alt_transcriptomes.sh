module load sw/aligners/tophat/2.0.13
module load sw/bio/cufflinks/2.2.0
module load sw/bio/bedtools/2.16.2
module load sw/aligners/bowtie/2.0.2


gffread /projects/vitis/genes/annotation/V2.1/V2.1.gff3 -g /genomes/vitis_vinifera/assembly/reference/12xCHR_alternative_aplotype/vitis_vinifera_entav_alternative.fasta -w /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/ALT.fa

gffread /projects/vitis/genes/annotation/V2.1/V2.1.gff3 -g /genomes/vitis_vinifera/assembly/reference/12xCHR/vitis_vinifera_12xCHR.fasta -w /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF.fa


#Create the two references with all exons separated
# We use subshell (Thanks, Ettore!) and with awk only select exons, the we cut to a four column bed file (where the fourth column is the "name") and use getfasta from bedtools for assigning to the sequences the exon name.
bedtools getfasta -fi /genomes/vitis_vinifera/assembly/reference/12xCHR_alternative_aplotype/vitis_vinifera_entav_alternative.fasta -bed <(awk '{ if ($3 == "exon" ) {print $0} }' /projects/vitis/genes/annotation/V2.1/V2.1.gff3 | cut -f 1,4,5,9) -name -fo /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/ALT_exons.fa

bedtools getfasta -fi /genomes/vitis_vinifera/assembly/reference/12xCHR/vitis_vinifera_12xCHR.fasta -bed <(awk '{ if ($3 == "exon" ) {print $0} }' /projects/vitis/genes/annotation/V2.1/V2.1.gff3 | cut -f 1,4,5,9) -name -fo /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_exons.fa

#Replace all "=" signs with "_" because the stupid GATK will throw an error if it finds an "="
sed -i -e's/=/_/g' /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/ALT_exons.fa
sed -i -e's/=/_/g' /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_exons.fa

#Create a bed file that will then be used by vcfFastaUpdate (also already change "=" in "_")
awk '{ if ($3 == "exon" ) {print $0} }' /projects/vitis/genes/annotation/V2.1/V2.1.gff3 | cut -f 1,4,5,9 | sed -e's/=/_/g' > /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_fusion.bed

#bedtools getfasta -fi /genomes/vitis_vinifera/assembly/reference/12xCHR_alternative_aplotype/vitis_vinifera_entav_alternative.fasta -bed <(awk '{ if ($3 == "exon" ) {print $0} }' /projects/vitis/genes/annotation/V2.1/V2.1.gff3 ) -fo /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/ALT_exons.fa
#I was worried to see that if an exon is, e.g. 10731 to 10945 then bedtools will write the fasta saying chr1_10730:10945. However when I blasted, it was blasting from 10731 to 10945, so should be ok!

#Build index for bowtie2

bowtie2-build /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/ALT_exons.fa /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/ALT_exons

bowtie2-build /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_exons.fa /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_exons


