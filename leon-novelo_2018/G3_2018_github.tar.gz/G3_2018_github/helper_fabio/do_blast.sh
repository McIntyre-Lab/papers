#Sorry: no blast-db on assembler, you have to run it on stratocluster
if [ "$#" -ne 2 ]; then
echo "Usage: $0 INFILE OUTPREF" 
echo "Where INFILE is the fasta file you want to blast"
echo "adn OUTPREF is the prefix of the output file. Files OUTPREF.xml and OUTPREF.txt will be created"
exit 1
fi

INFILE=$1
OUTPREF=$2

module load sw/bio/blast/2.2.27
module load sw/bio/iga_tools/default

# 1 blast

blastn -db /iga/blast-db/db/ncbi/nt \
-query $INFILE -out ${OUTPREF}_nt.xml -num_threads 12 -outfmt 5 -evalue 1e-5 -num_descriptions 5 -num_alignments 5

blastx -db /iga/blast-db/db/ncbi/refseq_protein \
-query $INFILE -out ${OUTPREF}_prot.xml -num_threads 12 -outfmt 5 -evalue 1e-5 -num_descriptions 5 -num_alignments 5

# 2 convert xml to txt

blast_report.py --blastxml ${OUTPREF}_nt.xml --out ${OUTPREF}_nt.txt
blast_report.py --blastxml ${OUTPREF}_prot.xml --out ${OUTPREF}_prot.txt

# 1 blast
# module load sw/bio/blast/2.2.27
# blastn -db /iga/blast-db/db/ncbi/nt \
# -query /projects/novabreed/share/marroni/collaborations/Lauren/qc_dna_p_noir_vcr18/duplicate_counts/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_001_duplicate_sequences_more_than_20.fasta \
# -out /projects/novabreed/share/marroni/collaborations/Lauren/qc_dna_p_noir_vcr18/duplicate_counts/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_001_duplicate_sequences_more_than_20_blastn.xml \
# -num_threads 12 -outfmt 5 -evalue 1e-5 -num_descriptions 5 -num_alignments 5

# blastx -db /iga/blast-db/db/ncbi/refseq_protein \
# -query /projects/novabreed/share/marroni/collaborations/Lauren/qc_dna_p_noir_vcr18/duplicate_counts/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_001_duplicate_sequences_more_than_20.fasta \
# -out /projects/novabreed/share/marroni/collaborations/Lauren/qc_dna_p_noir_vcr18/duplicate_counts/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_001_duplicate_sequences_more_than_20_blastx.xml \
# -num_threads 12 -outfmt 5 -evalue 1e-5 -num_descriptions 5 -num_alignments 5

# 2 convert xml to txt
# module load sw/bio/iga_tools/default
# blast_report.py --blastxml /projects/novabreed/share/marroni/collaborations/Lauren/qc_dna_p_noir_vcr18/duplicate_counts/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_001_duplicate_sequences_more_than_20_blastn.xml \
# --out /projects/novabreed/share/marroni/collaborations/Lauren/qc_dna_p_noir_vcr18/duplicate_counts/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_001_duplicate_sequences_more_than_20_blastn.txt

# blast_report.py --blastxml /projects/novabreed/share/marroni/collaborations/Lauren/qc_dna_p_noir_vcr18/duplicate_counts/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_001_duplicate_sequences_more_than_20_blastx.xml \
# --out /projects/novabreed/share/marroni/collaborations/Lauren/qc_dna_p_noir_vcr18/duplicate_counts/exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_001_duplicate_sequences_more_than_20_blastx.txt

