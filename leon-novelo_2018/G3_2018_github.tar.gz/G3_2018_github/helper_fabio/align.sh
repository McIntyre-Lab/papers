module load sw/aligners/bwa/0.7.5a
module load sw/bio/samtools/0.1.19

#Process1

REFERENCE=/genomes/vitis_vinifera/assembly/reference/12xCHR_alternative_aplotype/vitis_vinifera_entav_alternative.fasta
FASTQDIR=/projects/novabreed/share/marroni/collaborations/Lauren/qc_dna_p_noir_vcr18/fastq_split_dups
BAMDIR=/projects/novabreed/share/marroni/collaborations/Lauren/dna_distinct_align/ALT

FASTQFILE=exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_distinct.fq
LANE1=L001

BAMFILE=${FASTQFILE/fq/bam}
SAMFILE=${FASTQFILE/fq/sam}
bwa mem -t 8 -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${FASTQDIR}/${FASTQFILE} > ${BAMDIR}/$SAMFILE
#bwa mem -t 8 -M -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${FASTQDIR}/${FASTQFILE} > ${BAMDIR}/$SAMFILE
samtools import ${REFERENCE} ${BAMDIR}/$SAMFILE ${BAMDIR}/$BAMFILE
#samtools sort ${BAMDIR}/$BAMFILE ${BAMDIR}/${BAMFILE/.bam/_sorted}
samtools index ${BAMDIR}/${BAMFILE/.bam/_sorted.bam}
#Process 2

REFERENCE=/genomes/vitis_vinifera/assembly/reference/12xCHR/vitis_vinifera_12xCHR.fasta
FASTQDIR=/projects/novabreed/share/marroni/collaborations/Lauren/qc_dna_p_noir_vcr18/fastq_split_dups
BAMDIR=/projects/novabreed/share/marroni/collaborations/Lauren/dna_distinct_align/REF

FASTQFILE=exp_292_p_noir_vcr18_1_CGTACTAG_L001_MERGED_001_distinct.fq
LANE1=L001

BAMFILE=${FASTQFILE/fq/bam}
SAMFILE=${FASTQFILE/fq/sam}
bwa mem -t 8 -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${FASTQDIR}/${FASTQFILE} > ${BAMDIR}/$SAMFILE
#bwa mem -t 8 -M -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${FASTQDIR}/${FASTQFILE} > ${BAMDIR}/$SAMFILE
#samtools import ${REFERENCE} ${BAMDIR}/$SAMFILE ${BAMDIR}/$BAMFILE
#samtools sort ${BAMDIR}/$BAMFILE ${BAMDIR}/${BAMFILE/.bam/_sorted}
samtools index ${BAMDIR}/${BAMFILE/.bam/_sorted.bam}

#Process 3

REFERENCE=/genomes/vitis_vinifera/assembly/reference/12xCHR_alternative_aplotype/vitis_vinifera_entav_alternative.fasta
FASTQDIR=/projects/novabreed/share/marroni/collaborations/Lauren/qc_dna_p_noir_vcr18/fastq_split_dups
BAMDIR=/projects/novabreed/share/marroni/collaborations/Lauren/dna_distinct_align/ALT

FASTQFILE=exp_292_p_noir_vcr18_1_CGTACTAG_L002_MERGED_001_distinct.fq
LANE=L002

BAMFILE=${FASTQFILE/fq/bam}
SAMFILE=${FASTQFILE/fq/sam}
bwa mem -t 8 -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${FASTQDIR}/${FASTQFILE} > ${BAMDIR}/$SAMFILE
#bwa mem -t 8 -M -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${FASTQDIR}/${FASTQFILE} > ${BAMDIR}/$SAMFILE
#samtools import ${REFERENCE} ${BAMDIR}/$SAMFILE ${BAMDIR}/$BAMFILE
#samtools sort ${BAMDIR}/$BAMFILE ${BAMDIR}/${BAMFILE/.bam/_sorted}
samtools index ${BAMDIR}/${BAMFILE/.bam/_sorted.bam}

#Process 4

REFERENCE=/genomes/vitis_vinifera/assembly/reference/12xCHR/vitis_vinifera_12xCHR.fasta
FASTQDIR=/projects/novabreed/share/marroni/collaborations/Lauren/qc_dna_p_noir_vcr18/fastq_split_dups
BAMDIR=/projects/novabreed/share/marroni/collaborations/Lauren/dna_distinct_align/REF

FASTQFILE=exp_292_p_noir_vcr18_1_CGTACTAG_L002_MERGED_001_distinct.fq
LANE=L002

BAMFILE=${FASTQFILE/fq/bam}
SAMFILE=${FASTQFILE/fq/sam}
bwa mem -t 8 -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${FASTQDIR}/${FASTQFILE} > ${BAMDIR}/$SAMFILE
#bwa mem -t 8 -M -R "@RG\tID:$LANE1\tPL:illumina\tPU:$LANE1\tLB:$LANE1\tSM:$LANE1" ${REFERENCE} ${FASTQDIR}/${FASTQFILE} > ${BAMDIR}/$SAMFILE
#samtools import ${REFERENCE} ${BAMDIR}/$SAMFILE ${BAMDIR}/$BAMFILE
#samtools sort ${BAMDIR}/$BAMFILE ${BAMDIR}/${BAMFILE/.bam/_sorted}
samtools index ${BAMDIR}/${BAMFILE/.bam/_sorted.bam}

