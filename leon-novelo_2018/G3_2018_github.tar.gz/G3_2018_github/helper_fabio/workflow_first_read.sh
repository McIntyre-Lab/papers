#!/bin/bash

#This workflow is used to perform the split-duplicates only on the first read of each pair (paired end didn't work due to memory)
#Workflow for the second read is basically identical (and it will be pasted below, at the end of this workflow)

#Load all the needed modules
module load lang/python/2.7.3
module load sw/bio/samtools/0.1.19
module load sw/aligners/bowtie/2.0.2
module load lang/r/3.2.3


SCRIPTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/scripts
cd $SCRIPTDIR
./run_fastqSplitDups.sh

#Split fastq based on uniqueness
./run_fastqSplitDups.sh


#Perform alignment, import to bam and sort giving input fastq(s), reference sequence and output bam directory as parameters
# ONly three (for SE) or 4 (for PE) parameters accepted
#ORiginal REF
./align_generic.sh  /projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/fastq_split_dups/exp_292_p_noir_vcr18_1_CGTACTAG_L001_R1_001_distinct.fq /genomes/vitis_vinifera/assembly/reference/12xCHR/vitis_vinifera_12xCHR.fasta \
/projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/REF
#Alternative ref (ALT)
./align_generic.sh  /projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/fastq_split_dups/exp_292_p_noir_vcr18_1_CGTACTAG_L001_R1_001_distinct.fq /genomes/vitis_vinifera/assembly/reference/12xCHR_alternative_aplotype/vitis_vinifera_entav_alternative.fasta /projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/ALT



###############################################################
#
# RUN THIS PART IF YOU WANT TO COMPARE ALIGNMENT OF DNA
# Begin

#Split sorted bams by chr because sam_compare will be kille for memery eveno on 128Gb machines
BAMALT=/projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/ALT
if [ ! -e $BAMALT/chr ]; then mkdir -p $BAMALT/chr; fi
./split_by_chr.sh ${BAMALT}/exp_292_p_noir_vcr18_1_CGTACTAG_L001_R1_001_distinct_sorted.bam ${BAMALT}/chr
#./split_by_chr.sh ${BAMALT}/exp_292_p_noir_vcr18_1_CGTACTAG_L002_R1_001_distinct_sorted.bam ${BAMALT}/chr


BAMREF=/projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/REF
if [ ! -e $BAMREF/chr ]; then mkdir -p $BAMREF/chr; fi
./split_by_chr.sh ${BAMREF}/exp_292_p_noir_vcr18_1_CGTACTAG_L001_R1_001_distinct_sorted.bam ${BAMREF}/chr
#./split_by_chr.sh ${BAMREF}/exp_292_p_noir_vcr18_1_CGTACTAG_L002_R1_001_distinct_sorted.bam ${BAMREF}/chr

#
# RUN THIS PART IF YOU WANT TO COMPARE ALIGNMENT OF DNA
# End
###############################################################





#CALL SNPS AND INDELS USING UNIFIED GENOTYPER AND FILTER
./only_SNP_call_GATK_PN_chr.sh /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/SNP/both.vcf /genomes/vitis_vinifera/assembly/reference/12xCHR/vitis_vinifera_12xCHR.fasta geno
#REMOVE SNPS that do not pass filter. Filter name="exorcism"
awk '{ if ($7 != "exorcism" ) {print $0} }' /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/SNP/both_filtered.vcf > /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/SNP/both_clean.vcf



#ERROR: IT says in position 1068838 of Chr13 the reference has A while vcf has G. However, I checked, and the reference has also G!!! Don't know what's going on! I know! GATK outputs one SNP and one INDEL in the same position!
#2016-09-02 03:35:38,542 - DEBUG - Seq ref: A, VCF ref: G, Chrom: chr1_random Original Pos: 314681 New Pos 314689
#2016-09-02 04:26:04,199 - DEBUG - Seq ref: AT, VCF ref: CT, Chrom: chr1_random Original Pos: 501142 New Pos 501142
#2016-09-02 06:07:48,380 - DEBUG - Seq ref: A, VCF ref: G, Chrom: chr13 Original Pos: 2411912 New Pos 2411865
#2016-09-02 06:19:38,008 - DEBUG - Seq ref: AA, VCF ref: AG, Chrom: chr13 Original Pos: 3479486 New Pos 3479381

#This issue was posted on BIOSTARS, let's see if someone can help!
#chr13   3479486 .       AAG     A       1640.73 PASS    AC=2;AF=1.00;AN=2;DP=56;FS=0.000;MLEAC=2;MLEAF=1.00;MQ=53.87;MQ0=0;QD=29.30;SOR=0.767  GT:AD:DP:GQ:PL  1/1:0,54:56:99:1678,151,0
#chr13   3479487 .       AG      A       1448.73 PASS    AC=2;AF=1.00;AN=2;DP=56;FS=0.000;MLEAC=2;MLEAF=1.00;MQ=53.87;MQ0=0;QD=25.87;SOR=0.767  GT:AD:DP:GQ:PL  1/1:0,54:56:99:1486,160,0
#Solved with the dirty fix below

#Dirty fix: 
#Use bcf tools and keep only SNPs that are at least one bp from indels and indels that are 3bp form each other.

/projects/novabreed/share/software/bcftools-1.2/bcftools filter --SnpGap 1 --IndelGap 3 /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/SNP/both_clean.vcf > /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/SNP/both_clean_nodup.vcf	


#Run bgzip and tabix independently, to prepare the files for vcfFastaUpdate.py
/projects/novabreed/share/software/tabix-0.2.6/bgzip /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/SNP/both_clean_nodup.vcf
/projects/novabreed/share/software/tabix-0.2.6/tabix /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/SNP/both_clean_nodup.vcf.gz




#Now, use R to remove the infamous exon including only Ns. This would create an error in samcompare

Rscript /projects/novabreed/share/marroni/collaborations/Lauren/scripts/helper_fabio/remove_full_N.r

#To be run only once:
# Create indexes for the two new references
samtools faidx /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/ALT_PN_noN_fusions.fasta
samtools faidx /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/REF_PN_noN_fusions.fasta
bowtie2-build /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/ALT_PN_noN_fusions.fasta /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/ALT_PN_noN_fusions
bowtie2-build /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/REF_PN_noN_fusions.fasta /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/REF_PN_noN_fusions


#Align rnaseq data to the two references.
MYDIR=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_split_dups_pe
for MYFILE in ${MYDIR}/*distinct*
do
BASEFQ=$(basename $MYFILE)
BASESAM=${BASEFQ/.fq/.sam}
echo $BASEFQ
bowtie2 -x /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/ALT_PN_noN_fusions -U $MYFILE -p8 -k1 -S /projects/novabreed/share/marroni/collaborations/Lauren/RNA_alignments/ALT/$BASESAM
bowtie2 -x /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/REF_PN_noN_fusions -U $MYFILE -p8 -k1 -S /projects/novabreed/share/marroni/collaborations/Lauren/RNA_alignments/REF/$BASESAM
done


#Switch first and fourth columns of the fusion file (First column need now to be the fusion id)
awk -F'\t' '{print $4 "\t" $2 "\t" $3 "\t" $1}' /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/orig_REF_fusion.bed > /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_fusion.bed


#Run samcompare
SCRIPTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/scripts
MYDIR=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_split_dups_pe
for MYFILE in ${MYDIR}/*distinct*
do
BASEFQ=$(basename $MYFILE)
BASESAM=${BASEFQ/.fq/.sam}
echo $BASEFQ
SAMA=/projects/novabreed/share/marroni/collaborations/Lauren/RNA_alignments/REF/$BASESAM
SAMB=/projects/novabreed/share/marroni/collaborations/Lauren/RNA_alignments/ALT/$BASESAM
./sam_compare_bychrom.sh \
$SAMA \
$SAMB \
/projects/novabreed/share/marroni/collaborations/Lauren/RNA_alignments/ase_counts/${BASEFQ/.fq/} \
$MYFILE \
/projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_fusion.bed
#echo "cd $SCRIPTDIR; ./sam_compare_bychrom.sh \
#$SAMA \
#$SAMB \
#/projects/novabreed/share/marroni/collaborations/Lauren/RNA_alignments/ase_counts/${BASEFQ/.fq/} \
#$MYFILE \
#/projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_fusion.bed" | qsub -N $BASESAM -l vmem=60G,walltime=2:00:00
done 



#Run simulations for obtaining qsim

./compute_qsim.sh






###############################
#OLD stuff below
#
##############################

#Run samcompare on files splitted by chromosomes
#Using one read of 100bp it is also possible to run on tocai the script sam_compare_1st_read.qsub to perform analyses on the whole dataset
BAMALT=/projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/ALT
BAMREF=/projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/REF
SAMFILE=exp_292_p_noir_vcr18_1_CGTACTAG_L001_R1_001_distinct_sorted.sam
FASTQFILE=exp_292_p_noir_vcr18_1_CGTACTAG_L001_R1_001_distinct.fq
FUSION=/projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/chr1_random.bed
for MYCHR in chr1_random
#for MYCHR in chr1_random chr1 chr2 chr3 chr4_random chr4 chr5 chr5_random chr6 chr7 chr7_random chr8 chr9 chr9_random \
#chr10 chr10_random chr11 chr11_random chr12 chr12_random chr13 chr13_random chr14 chr15 chr16 chr16_random chr17 chr17_random chr18 chr18_random chr19 chrUn
do
./sam_compare_bychrom.sh \
$BAMREF/chr/${MYCHR}_${SAMFILE} \
$BAMALT/chr/${MYCHR}_${SAMFILE} \
/projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/ase_counts/$MYCHR \
/projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna/fastq_split_dups/$FASTQFILE \
$FUSION
done 
#Paste the two lines below to run on cluster
#>${SCRIPTDIR}/${MYCHR}.out 2>>${SCRIPTDIR}/${MYCHR}.err \
#| -N ase_$MYCHR -l mem=32G,vmem=32G,walltime=8:00:00,nodes=1:ppn=1



#Run on the "clean_nodup" file: shouldn't issue errors!
PYTHONPATH=$PYTHONPATH:/projects/novabreed/share/marroni/collaborations/Lauren/scripts/PyVCF-master
python vcfFastaUpdate.py --vcf /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/SNP/both_clean_nodup.vcf --fasta /genomes/vitis_vinifera/assembly/reference/12xCHR/vitis_vinifera_12xCHR.fasta --bed /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_fusion.bed -o /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/ALT_PN_fusions.fasta --debug

#Create the original reference slicing out the same exons used for the alternative reference
module load sw/bio/bedtools/2.16.2
bedtools getfasta -fi /genomes/vitis_vinifera/assembly/reference/12xCHR/vitis_vinifera_12xCHR.fasta -bed /projects/novabreed/share/marroni/collaborations/Lauren/transcriptomes_fasta/REF_fusion.bed -name -fo /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/updated_fasta/REF_PN_fusions.fasta



###########################################################################
#
#Run The same workflow on the second read
#Slight changes are possbile as I updated the pipeline
#
###########################################################################


SCRIPTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/scripts/helper_fabio/
cd $SCRIPTDIR

#Split fastq based on uniqueness
./test_fastqSplitDups.sh /projects/novabreed/share/marroni/collaborations/Lauren/100bp_se_dna_R2 /projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18/exp_292_p_noir_vcr18_1_CGTACTAG_L001_R2_001.fq

