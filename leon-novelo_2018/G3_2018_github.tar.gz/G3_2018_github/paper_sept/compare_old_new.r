#compare.old.new
#compare.condition.genes: takes the list of genes showing differential AI between condition in the new model and see how it compares
#                          with the old model 
#compare.cis.trans: I don't trust my way of computing cis and trans!!!!

#AIMV.oldnew: Boxplot of thetas stratified by evidence of differential AI according to old empiri, new empiric and new stat test
#AIM.oldnew
#AIV.oldnew

compare.old.new<-function(newfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
	merged.file="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/merged_data.csv",
    pdf.compare.significant="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_3.pdf")
{

library(data.table)
#Old is Table S3 of Justin's paper
oldres<-fread("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/Supplemental_Table3_lmm1.csv",data.table=F)
oldres$line_gene<-apply(cbind(oldres$genotype,oldres$exonic_region),1,paste,collapse="_")
#Only keep essential columns
oldres<-oldres[,!names(oldres)%in%c("direction_cis","direction_trans")]
#Transform the dataset so that the structure is similar to the new one
#Mainly, we want one line for genotype and exon reporting results for mated and virgin in different columns

oldmated<-oldres[oldres$mating_status=="M",]
oldvirgin<-oldres[oldres$mating_status=="V",]

names(oldmated)[c(4,5,6,7,8,14)]<-paste(names(oldmated)[c(4,5,6,7,8,14)],"_M",sep="")
names(oldvirgin)[c(4,5,6,7,8,14)]<-paste(names(oldvirgin)[c(4,5,6,7,8,14)],"_V",sep="")
oldnice<-merge(oldmated,oldvirgin,by="line_gene")
#Remove some columns that we don't need and change some names
names(oldnice)[grep("\\.x",names(oldnice))]<-gsub("\\.x","",names(oldnice)[grep("\\.x",names(oldnice))])
oldnice<-oldnice[,grep("\\.y",names(oldnice),invert=T)]


#New is this one
newres<-fread(newfile,data.table=F)
newres$line_gene<-apply(cbind(newres$line,newres$fusion_id),1,paste,collapse="_")


#Merge results
merged<-merge(newres,oldnice,by="line_gene")
cat("Merged old and new data\n")
#Remove some columns that we don't need
merged<-merged[,!names(merged)%in%c("mating_status","FBpp_cat","exonic_region","chromosome","start_site","end_site",
			"Exon_Name_cat","Flybase551_FBgn","genotype","analyze_cis_effects_M","analyze_cis_effects_V")]
write.table(merged,merged.file,sep=",",quote=F,row.names=F)
cat("Wrote the merged data set\n")
#Start the comparisons

#Compare estimate of theta with the old and new model. Do plot for Mated and for Virgin
#Report significant results in colors

allcex=0.4
colboth<-"plum3"
colext<-"royalblue2"
merged$color_M<-merged$color_V<-"black"
merged$color_M[merged$AI_intersection_test_M>0]<-"red2"
merged$color_V[merged$AI_intersection_test_V>0]<-"red2"
merged$color_M[merged$AI_Mated_decision>0]<-colext
merged$color_V[merged$AI_Virgin_decision>0]<-colext
merged$color_M[merged$AI_intersection_test_M>0&merged$AI_Mated_decision>0]<-colboth
merged$color_V[merged$AI_intersection_test_V>0&merged$AI_Virgin_decision>0]<-colboth
merged$color_order_M<-merged$color_order_V<-1
merged$color_order_M[merged$color_M!="black"]<-2
merged$color_order_V[merged$color_V!="black"]<-2
pdf(pdf.compare.significant,width=14,height=7)
#pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots_old_vs_new/theta_hat_vs_mean_col.pdf",width=14,height=7)
layout(matrix(c(1,2),1,2))
#I sort by color because I want the black points to be plotted first and eventually overwritten by colored pooints
merged<-merged[order(merged$color_order_M),]
myreg<- lm(merged$theta_hat_AI_M~merged$TesterinMated_mean)
myr<-round(summary(myreg)$r.squared,2)
plot(merged$theta_hat_AI_M,merged$TesterinMated_mean,pch=19,cex=allcex,col=merged$color_M,xlab=expression(paste(theta, " Baseline mated")),ylab=expression(paste(theta, " Environmental mated")))
abline(myreg,col="red")
abline(0,1,col="blue")
#Remember to give credit to lukemiller: http://lukemiller.org/index.php/2012/10/adding-p-values-and-r-squared-values-to-a-plot-using-expression/
mylabel = bquote(italic(R)^2 == .(myr))
text(0.1,0.7,mylabel)
legend("topleft",c("Not significant","Significant Basic","Significant Ext","Significant Both"),pch=19,cex=0.3+allcex,col=c("black","red2",colext,colboth))
#I sort by color because I want the blac points to be plotted first and eventually overwritten by colored pooints
merged<-merged[order(merged$color_order_V),]
myreg<- lm(merged$theta_hat_AI_V~merged$TesterVirgin_mean)
myr<-round(summary(myreg)$r.squared,2)
plot(merged$theta_hat_AI_V,merged$TesterVirgin_mean,pch=19,cex=allcex,col=merged$color_V,xlab=expression(paste(theta, " Baseline virgin")),ylab=expression(paste(theta, " Environmental virgin")))
abline(myreg,col="red")
abline(0,1,col="blue")
#Remember to give credit to lukemiller: http://lukemiller.org/index.php/2012/10/adding-p-values-and-r-squared-values-to-a-plot-using-expression/
mylabel = bquote(italic(R)^2 == .(myr))
text(0.1,0.7,mylabel)
legend("topleft",c("Not significant","Significant Basic","Significant Ext","Significant Both"),pch=19,cex=0.3+allcex,col=c("black","red2",colext,colboth))
dev.off()
cat("plotted correlation plot\n")


#Print some tables
library(grid)
library(gridExtra)
library(gtable)

pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables_old_vs_new/significant_comparisons_bis.pdf")
#layout(matrix(c(1,2),1,2))
mytab<-table(merged$AI_intersection_test_M,merged$AI_Mated_decision)
row.names(mytab)<- paste("AI_Basic_M",row.names(mytab))
colnames(mytab)<- paste("AI_Extended_M",colnames(mytab))
t1 <- tableGrob(mytab)
padding <- unit(15,"mm")
title <- textGrob("AI in Mated",gp=gpar(fontsize=25))
table <- gtable_add_rows(t1, heights = grobHeight(title) + padding, pos = 0)
table <- gtable_add_grob(table, title, 1, 1, 1, ncol(table))
grid.newpage()
grid.draw(table)
mytab<-table(merged$AI_intersection_test_V,merged$AI_Virgin_decision)
row.names(mytab)<- paste("AI_Basic_V",row.names(mytab))
colnames(mytab)<- paste("AI_Extended_V",colnames(mytab))
t1 <- tableGrob(mytab)
padding <- unit(15,"mm")
title <- textGrob("AI in Virgin",gp=gpar(fontsize=25))
table <- gtable_add_rows(t1, heights = grobHeight(title) + padding, pos = 0)
table <- gtable_add_grob(table, title, 1, 1, 1, ncol(table))
grid.newpage()
grid.draw(table)
#Differences in AI between virgin and Mates (statistically tested)
#This one was commented because grid doesn't want to draw a table with only one row

#mytab<-table(merged$AI_diffinVirginandMated)
#t1 <- tableGrob(mytab)
#padding <- unit(15,"mm")
#title <- textGrob("AI_diffinVirginandMated",gp=gpar(fontsize=25))
#table <- gtable_add_rows(t1, heights = grobHeight(title) + padding, pos = 0)
#table <- gtable_add_grob(table, title, 1, 1, 1, ncol(table))
#grid.newpage()
#grid.draw(table)

#See how many times we have AI in one but not the other using the old model
mytab<-table(merged$AI_intersection_test_V,merged$AI_intersection_test_M)
row.names(mytab)<- paste("AI_Basic_V",row.names(mytab))
colnames(mytab)<- paste("AI_Basic_M",colnames(mytab))
t1 <- tableGrob(mytab)
padding <- unit(15,"mm")
title <- textGrob("AI differ Mated Virgin orig",gp=gpar(fontsize=25))
table <- gtable_add_rows(t1, heights = grobHeight(title) + padding, pos = 0)
table <- gtable_add_grob(table, title, 1, 1, 1, ncol(table))
grid.newpage()
grid.draw(table)
#See how many times we have AI in one but not the other using the NEW model
mytab<-table(merged$AI_Virgin_decision,merged$AI_Mated_decision)
row.names(mytab)<- paste("AI_Extended_V",row.names(mytab))
colnames(mytab)<- paste("AI_Extended_M",colnames(mytab))
t1 <- tableGrob(mytab)
padding <- unit(15,"mm")
title <- textGrob("AI differ Mated Virgin extended",gp=gpar(fontsize=25))
table <- gtable_add_rows(t1, heights = grobHeight(title) + padding, pos = 0)
table <- gtable_add_grob(table, title, 1, 1, 1, ncol(table))
grid.newpage()
grid.draw(table)

#See how many times in the four usual categories we find differential AI according to the bayesian model
merged$V0M0<-merged$V1M0<-merged$V0M1<-merged$V1M1<-0
merged$V0M0[merged$AI_Virgin_decision==0&merged$AI_Mated_decision==0&merged$AI_diffinVirginandMated]<-1
merged$V1M0[merged$AI_Virgin_decision==1&merged$AI_Mated_decision==0&merged$AI_diffinVirginandMated]<-1
merged$V0M1[merged$AI_Virgin_decision==0&merged$AI_Mated_decision==1&merged$AI_diffinVirginandMated]<-1
merged$V1M1[merged$AI_Virgin_decision==1&merged$AI_Mated_decision==1&merged$AI_diffinVirginandMated]<-1

mytab<-data.frame(matrix(c(sum(merged$V0M0),sum(merged$V0M1),sum(merged$V1M0),sum(merged$V1M1)),nrow=2,byrow=T))
row.names(mytab)<- paste("AI_Extended_V",row.names(mytab))
colnames(mytab)<- paste("AI_Extended_M",colnames(mytab))
t1 <- tableGrob(mytab)
padding <- unit(15,"mm")
title <- textGrob("Exons with different AI",gp=gpar(fontsize=25))
table <- gtable_add_rows(t1, heights = grobHeight(title) + padding, pos = 0)
table <- gtable_add_grob(table, title, 1, 1, 1, ncol(table))
grid.newpage()
grid.draw(table)


dev.off()
cat("Printed some tables\n")


#Boxplot difference theta
pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots_old_vs_new/Mated_minus_Virgin.pdf")
mycol<-"cyan"
boxplot(abs(merged$TesterinMated_mean-merged$TesterVirgin_mean) ~ merged$AI_diffinVirginandMated, col=mycol, main="Absolute Value of Diff Mate Virgin", xlab="diffinVirginandMated")
boxplot(abs(merged$TesterinMated_mean-merged$TesterVirgin_mean) ~ abs(merged$AI_Mated_decision-merged$AI_Virgin_decision), col=mycol, main="Absolute Value of Diff Mate Virgin", xlab="Mated vs Virgin decision")
boxplot(abs(merged$theta_hat_AI_M-merged$theta_hat_AI_V) ~ abs(merged$AI_intersection_test_V-merged$AI_intersection_test_M), col=mycol, main="Absolute Value of Diff Mate Virgin", xlab="Mated vs Virgin decision Fear")
dev.off()





pp<-aggregate(cbind(merged$AI_intersection_test_M,merged$AI_Mated_decision),by=list(merged$fusion_id),FUN="sum")
qq<-aggregate(cbind(merged$AI_intersection_test_M,merged$AI_Mated_decision),by=list(merged$line),FUN="sum")
#Scatterplot of the number of exons with AI per line
pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots_old_vs_new/corr_numb_exons_per_line.pdf")
plot(qq$V1,qq$V2,pch=19,cex=0.5)
myreg<- lm(qq$V2~qq$V1)
myr<-round(summary(myreg)$r.squared,2)
abline(myreg,col="red")
abline(0,1,col="blue")
#Remember to give credit to lukemiller: http://lukemiller.org/index.php/2012/10/adding-p-values-and-r-squared-values-to-a-plot-using-expression/
mylabel = bquote(italic(R)^2 == .(myr))
text(100,600,mylabel)
dev.off()

# Plot density of theta in mated and virgin in new (solid) and old (dotted) data
# ALso compare results with the last graph in: https://github.com/McIntyre-Lab/papers/blob/master/fear_ase_2016/scripts/ase_summary/ase_filters.ipynb
#I don't know where Justin tooke the Figure 2A which is in the paper.
#PS one thing I noticed is that Justin removed from analysis all (or most) the lines in which large differences between mated and virgins were observed.
 
pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots_old_vs_new/density_theta_sampleprop.pdf")
plot(density(merged$TesterinMated_sampleprop),main=paste("Comparison ext vs base on",length(unique(merged$line)),"lines"))
lines(density(merged$TesterVirgin_sampleprop),col="red")
lines(density(merged$theta_hat_AI_M),col="black",lty=3)
lines(density(merged$theta_hat_AI_V),col="red",lty=3)
legend("topright",legend=c("Mated_new","Virgin_new","Mated_old","Virgin_old"),lty=c(1,1,3,3),col=c("black","red","black","red"))
dev.off()

cat("Plotted overall density data\n")


# Plot density of theta in mated and virgin in new (solid) and old (dotted) data stratified by line
pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots_old_vs_new/density_theta_sampleprop_by_line.pdf")
for(aaa in unique(merged$line))
{
mydf<-merged[merged$line==aaa,]
plot(density(mydf$TesterinMated_sampleprop),main=paste("Comparison ext vs base",aaa))
lines(density(mydf$TesterVirgin_sampleprop),col="red")
lines(density(mydf$theta_hat_AI_M),col="black",lty=3)
lines(density(mydf$theta_hat_AI_V),col="red",lty=3)
legend("topright",legend=c("Mated_new","Virgin_new","Mated_old","Virgin_old"),lty=c(1,1,3,3),col=c("black","red","black","red"))
}
dev.off()
}


AIMV.oldnew<-function(newfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/merged_data.csv",
	outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots_old_vs_new/box_mix_AI_MV.pdf",
    testfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables_old_vs_new/box_mix_AI_MV_mu_greater_than_0.01.txt",mu=0.01)
{
library(data.table)
library(multcompView)
#New is my clean data
newres<-fread(newfile,data.table=F)
newres<-newres[,!names(newres)%in%c("M_num_reps","V_num_reps","FBtr_cat")]
newres$diff_ext<-abs(newres$TesterinMated_mean-newres$TesterVirgin_mean)
newres$diff_ori<-abs(newres$theta_hat_AI_V-newres$theta_hat_AI_M)

pdf(outgraph)
#Create vectors carrying data for each result to perform pairwise wilcoxon test
Basic_0<-cbind(newres$diff_ori[(newres$AI_intersection_test_M==newres$AI_intersection_test_V)&newres$AI_intersection_test_M<1],1)
Basic_01<-cbind(newres$diff_ori[newres$AI_intersection_test_M!=newres$AI_intersection_test_V],2)
Basic_1<-cbind(newres$diff_ori[(newres$AI_intersection_test_M==newres$AI_intersection_test_V)&newres$AI_intersection_test_M>0],3)
Ext_0<-cbind(newres$diff_ext[(newres$AI_Mated_decision==newres$AI_Virgin_decision)&newres$AI_Virgin_decision<1],4)
Ext_01<-cbind(newres$diff_ext[newres$AI_Mated_decision!=newres$AI_Virgin_decision],5)
Ext_1<-cbind(newres$diff_ext[(newres$AI_Mated_decision==newres$AI_Virgin_decision)&newres$AI_Virgin_decision>0],6)
ExtB_0<-cbind(newres$diff_ext[(newres$AI_Mated_decision==newres$AI_Virgin_decision)&newres$AI_diffinVirginandMated<1&newres$AI_Mated_decision<1],7)
ExtB_01<-cbind(newres$diff_ext[newres$AI_diffinVirginandMated>0],8)
ExtB_1<-cbind(newres$diff_ext[(newres$AI_Mated_decision==newres$AI_Virgin_decision)&newres$AI_diffinVirginandMated<1&newres$AI_Mated_decision>0],9)
full<-rbind(Basic_0,Basic_01,Basic_1,Ext_0,Ext_01,Ext_1,ExtB_0,ExtB_01,ExtB_1)
pp<-pairwise.wilcox.test(full[,1], full[,2], p.adjust.method = "bonferroni", paired = FALSE, mu=0)
mymat<-tri.to.squ(pp$p.value)
myletters<-multcompLetters(mymat,compare="<=",threshold=0.05,Letters=letters)
#Fake boxplot (i.e. no plot) to compute the position of the whiskers that will be used to plot the letters
pp<-boxplot(newres$diff_ori[(newres$AI_intersection_test_M==newres$AI_intersection_test_V)&newres$AI_intersection_test_M<1],
		newres$diff_ori[newres$AI_intersection_test_M!=newres$AI_intersection_test_V],
		newres$diff_ori[(newres$AI_intersection_test_M==newres$AI_intersection_test_V)&newres$AI_intersection_test_M>0],
		newres$diff_ext[(newres$AI_Mated_decision==newres$AI_Virgin_decision)&newres$AI_Virgin_decision<1],
		newres$diff_ext[newres$AI_Mated_decision!=newres$AI_Virgin_decision],
		newres$diff_ext[(newres$AI_Mated_decision==newres$AI_Virgin_decision)&newres$AI_Virgin_decision>0],
		newres$diff_ext[(newres$AI_Mated_decision==newres$AI_Virgin_decision)&newres$AI_diffinVirginandMated<1&newres$AI_Mated_decision<1],
		newres$diff_ext[newres$AI_diffinVirginandMated>0],
		newres$diff_ext[(newres$AI_Mated_decision==newres$AI_Virgin_decision)&newres$AI_diffinVirginandMated<1&newres$AI_Mated_decision>0],plot=F)
whereletters<-pp$stats[nrow(pp$stats),]
boxplot(newres$diff_ori[(newres$AI_intersection_test_M==newres$AI_intersection_test_V)&newres$AI_intersection_test_M<1],
		newres$diff_ori[newres$AI_intersection_test_M!=newres$AI_intersection_test_V],
		newres$diff_ori[(newres$AI_intersection_test_M==newres$AI_intersection_test_V)&newres$AI_intersection_test_M>0],
		newres$diff_ext[(newres$AI_Mated_decision==newres$AI_Virgin_decision)&newres$AI_Virgin_decision<1],
		newres$diff_ext[newres$AI_Mated_decision!=newres$AI_Virgin_decision],
		newres$diff_ext[(newres$AI_Mated_decision==newres$AI_Virgin_decision)&newres$AI_Virgin_decision>0],
		newres$diff_ext[(newres$AI_Mated_decision==newres$AI_Virgin_decision)&newres$AI_diffinVirginandMated<1&newres$AI_Mated_decision<1],
		newres$diff_ext[newres$AI_diffinVirginandMated>0],
		newres$diff_ext[(newres$AI_Mated_decision==newres$AI_Virgin_decision)&newres$AI_diffinVirginandMated<1&newres$AI_Mated_decision>0],
		col=c("red2","red2","red2","dodgerblue3","dodgerblue3","dodgerblue3","deepskyblue","deepskyblue","deepskyblue"),
	main=expression(paste(theta," Difference M vs V  Stratified by Contrast")),
    ylim=c(0,0.1+max(whereletters)),ylab=bquote(c(theta ~ "Difference between environments")),
    names=c(expression(paste("Both ",alpha, "=1")),expression(paste("One ",alpha, "=1")),expression(paste("Both ",alpha!=1)),
            expression(paste("Both ",alpha, "=1")),expression(paste("One ",alpha, "=1")),expression(paste("Both ",alpha!=1)),
            expression(paste("Both ",alpha, "=1")),expression(paste("One ",alpha, "=1")),expression(paste("Both ",alpha!=1))),
    outline=F,cex.lab=0.8,cex.axis=0.7)
legend("topleft",c("Base Descriptive","Env Descriptive","Env Bayesian"),fill=c("red2","dodgerblue3","deepskyblue"))
text(c(1,2,3,4,5,6,7,8,9),0.05+whereletters,
    c(myletters$Letters[1],myletters$Letters[2],myletters$Letters[3],myletters$Letters[4],myletters$Letters[5],myletters$Letters[6],myletters$Letters[7],myletters$Letters[8],myletters$Letters[9]))
dev.off()

}

AI.oldnew<-function(newfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/merged_data.csv",
	outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots_old_vs_new/box_AI_changehere.pdf",virgin=T)
{
library(data.table)
library(multcompView)
pdf(outgraph,width=10)
par(mfrow=c(1,2))
for (aaa in c("Mated","Virgin"))
{
#Set all the names according to Virgin or Mated status
if(aaa=="Virgin")
{
oldtheta<-"theta_hat_AI_V"
newtheta<-"TesterVirgin_mean"
oldtest<-"AI_intersection_test_V"
newtest<-"AI_Virgin_decision"
myword<-"Virgin"
} else {
oldtheta<-"theta_hat_AI_M"
newtheta<-"TesterinMated_mean"
oldtest<-"AI_intersection_test_M"
newtest<-"AI_Mated_decision"
myword<-"Mated"
}

#New is my clean data
newres<-fread(newfile,data.table=F)
newres<-newres[,!names(newres)%in%c("M_num_reps","V_num_reps","FBtr_cat")]
newres$oldshift<-abs(newres[,oldtheta]-0.5)
newres$newshift<-abs(newres[,newtheta]-0.5)
mynumbers<-paste("N =",c(length(newres$oldshift[newres[,oldtest]<1]),length(newres$oldshift[newres[,oldtest]>0]),
		length(newres$newshift[newres[,newtest]<1]),length(newres$newshift[newres[,newtest]>0])))

#Inutilizzato ma memorabile use di bquote.
#main=bquote("Deviation of" ~ theta ~ "in " ~ .(myword))
mynames<-c("No AI","AI","No AI","AI")
ifelse(aaa=="Mated",mylab<-c(bquote("Deviation of" ~ theta)),mylab<-"")
#mynames<-c(expression(paste(alpha[B], "=1")),expression(paste(alpha[B]!=1)),expression(paste(alpha[E], "=1")),expression(paste(alpha[E]!=1)))
boxplot(newres$oldshift[newres[,oldtest]<1],
		newres$oldshift[newres[,oldtest]>0],
		newres$newshift[newres[,newtest]<1],
		newres$newshift[newres[,newtest]>0],
		col=c("lightpink","lightpink","hotpink4","hotpink4"),
	main=myword,names=mynames,outline=F,cex.lab=0.8,cex.axis=0.8,ylim=c(0,0.08+max(newres$oldshift,newres$newshift)),ylab=mylab)
legend("topleft",c("Base","Env"),fill=c("lightpink","hotpink4"))
one<-cbind(newres$oldshift[newres[,oldtest]<1],1)
two<-cbind(newres$oldshift[newres[,oldtest]>0],2)
three<-cbind(newres$newshift[newres[,newtest]<1],3)
four<-cbind(newres$newshift[newres[,newtest]>0],4)
full<-rbind(one,two,three,four)
pp<-pairwise.wilcox.test(full[,1], full[,2], p.adjust.method = "none", paired = FALSE)
mymat<-tri.to.squ(pp$p.value)
myletters<-multcompLetters(mymat,compare="<=",threshold=0.05,Letters=letters)
text(c(1,2,3,4),0.05+c(max(one[,1]),max(two[,1]),max(three[,1]),max(four[,1])),c(myletters$Letters[1],myletters$Letters[2],myletters$Letters[3],myletters$Letters[4]))
}
dev.off()
}


BA.oldnew<-function(newfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/merged_data.csv",
	outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots_old_vs_new/box_AI_changehere.pdf",
    out.table="",out.table2="")
{
library(data.table)
pdf(outgraph,width=10)
par(mfrow=c(1,2))
for (aaa in c("Mated","Virgin"))
{
#Set all the names according to Virgin or Mated status
if(aaa=="Virgin")
{
oldtheta<-"theta_hat_AI_V"
newtheta<-"TesterVirgin_mean"
oldtest<-"AI_intersection_test_V"
newtest<-"AI_Virgin_decision"
myword<-"Virgin"
} else {
oldtheta<-"theta_hat_AI_M"
newtheta<-"TesterinMated_mean"
oldtest<-"AI_intersection_test_M"
newtest<-"AI_Mated_decision"
myword<-"Mated"
}
#New is my clean data
newres<-fread(newfile,data.table=F)
newres<-newres[,!names(newres)%in%c("M_num_reps","V_num_reps","FBtr_cat")]
newres$oldshift<-abs(newres[,oldtheta]-0.5)
newres$newshift<-abs(newres[,newtheta]-0.5)
newres$oldenv<-abs(newres$AI_intersection_test_V-newres$AI_intersection_test_M)
mynumbers<-paste("N =",c(length(newres$oldshift[newres[,oldtest]<1]),length(newres$oldshift[newres[,oldtest]>0]),
		length(newres$newshift[newres[,newtest]<1]),length(newres$newshift[newres[,newtest]>0])))

#Inutilizzato ma memorabile use di bquote.
#main=bquote("Deviation of" ~ theta ~ "in " ~ .(myword))
mynames<-c("No AI","AI","No AI","AI")
ifelse(aaa=="Mated",mylab<-c(bquote("Deviation of" ~ theta)),mylab<-"")
#mynames<-c(expression(paste(alpha[B], "=1")),expression(paste(alpha[B]!=1)),expression(paste(alpha[E], "=1")),expression(paste(alpha[E]!=1)))
bax<-apply(cbind(newres$oldshift,newres$newshift),1,mean)
bay<-newres$oldshift-newres$newshift
plot(bax,bay,cex=0.7,xlab="(Base + Env)/2",ylab="Base - Env",main=aaa)
abline(h=mean(bay),col="red")
abline(h=mean(bay)+1.96*sd(bay),lty=3)
abline(h=mean(bay)-1.96*sd(bay),lty=3)
pp<-lm(bay~bax)
abline(pp,col="blue")
message("Performing analysis stratified by difference in theta estimate...")
lowlim<-mean(bay)-1.96*sd(bay)
highlim<-mean(bay)+1.96*sd(bay)
message("Lowlim ",aaa," ",lowlim)
message("Highlim ",aaa," ",highlim)
plow<-newres[bay<(lowlim),]
tlow<-table(plow$oldenv,plow$AI_diffinVirginandMated)
phigh<-newres[bay>highlim,]
thigh<-table(phigh$oldenv,phigh$AI_diffinVirginandMated)
pmed<-newres[bay<=highlim&bay>=(lowlim),]
tmed<-table(pmed$oldenv,pmed$AI_diffinVirginandMated)
row.names(tmed)<-c("base_env_0","base_env_1")
colnames(tmed)<-c("env_env_0","env_env_1")
pextr<-rbind(plow,phigh)
textr<-table(pextr$oldenv,pextr$AI_diffinVirginandMated)
row.names(textr)<-c("base_env_0","base_env_1")
colnames(textr)<-c("env_env_0","env_env_1")

disclow<-tlow[1,2]+tlow[2,1]
conclow<-tlow[1,1]+tlow[2,2]
dischigh<-thigh[1,2]+thigh[2,1]
conchigh<-thigh[1,1]+thigh[2,2]
discmed<-tmed[1,2]+tmed[2,1]
concmed<-tmed[1,1]+tmed[2,2]
discext<-disclow+dischigh
concext<-conclow+conchigh

message("Proportion of discordance in exons showing differences outside of 95% CI in ", aaa, " flies: ", discext/(concext+discext))
message("Proportion of discordance in exons showing differences inside  95% CI in ", aaa, " flies: ", discmed/(concmed+discmed))
mat1<-matrix(c(discext,concext,discmed,concmed),2)
row.names(mat1)<-c("Base=Env","Base!=Env")
colnames(mat1)<-c("Out 95","In 95")
print(fisher.test(mat1))
message("Significant only in baseline model ", textr[2,1]," out of ",sum (textr)," in exons showing differences outside of 95% CI in ",aaa," flies")
message("Significant only in baseline model ", tmed[2,1]," out of ",sum (tmed)," in exons showing differences inside 95% CI in ",aaa," flies")
mat2<-matrix(c(textr[2,1],sum(textr)-textr[2,1],tmed[2,1],sum(tmed)-tmed[2,1]),2)
row.names(mat2)<-c("Base!=0 Env=0","Universe 1")
colnames(mat2)<-c("Out 95","In 95")
print(fisher.test(mat2))
message("Significant only in environmental model ", textr[1,2]," out of ",sum (textr)," in exons showing differences outside of 95% CI in ",aaa," flies")
message("Significant only in environmental model ", tmed[1,2]," out of ",sum (tmed)," in exons showing differences inside 95% CI in ",aaa," flies")
mat3<-matrix(c(textr[1,2],sum(textr)-textr[1,2],tmed[1,2],sum(tmed)-tmed[1,2]),2)
row.names(mat3)<-c("Env!0 Base=0","Universe 2")
colnames(mat3)<-c("Out 95","In 95")
print(fisher.test(mat3))

mytab<-rbind(mat1,mat2,mat3)
row.names(mytab)<-paste(row.names(mytab),aaa)
ifelse(aaa=="Mated",myfinal<-mytab,myfinal<-rbind(myfinal,mytab))
}
dev.off()
write.table(myfinal,out.table,sep="\t",quote=F)
browser()
}

concordance.table<-function(newfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/merged_data.csv",
	    out.table="")
{
library(data.table)


#New is my clean data
newres<-fread(newfile,data.table=F)
newres<-newres[,!names(newres)%in%c("M_num_reps","V_num_reps","FBtr_cat")]
newres$olddiff<-abs(newres$theta_hat_AI_V-newres$theta_hat_AI_M)
newres$newdiff<-abs(newres$TesterVirgin_mean-newres$TesterinMated_mean)
newres$oldenv<-abs(newres$AI_intersection_test_V-newres$AI_intersection_test_M)



env_thetadiff__0env0base<-summary(newres$newdiff[newres$AI_diffinVirginandMated==0&newres$oldenv==0])
env_thetadiff__0env1base<-summary(newres$newdiff[newres$AI_diffinVirginandMated==0&newres$oldenv==1])
env_thetadiff__1env0base<-summary(newres$newdiff[newres$AI_diffinVirginandMated==1&newres$oldenv==0])
env_thetadiff__1env1base<-summary(newres$newdiff[newres$AI_diffinVirginandMated==1&newres$oldenv==1])
base_thetadiff__0base0env<-summary(newres$olddiff[newres$oldenv==0&newres$AI_diffinVirginandMated==0])
base_thetadiff__0base1env<-summary(newres$olddiff[newres$oldenv==0&newres$AI_diffinVirginandMated==1])
base_thetadiff__1base0env<-summary(newres$olddiff[newres$oldenv==1&newres$AI_diffinVirginandMated==0])
base_thetadiff__1base1env<-summary(newres$olddiff[newres$oldenv==1&newres$AI_diffinVirginandMated==1])
pp<-rbind(env_thetadiff__0env0base,env_thetadiff__0env1base,env_thetadiff__1env0base,env_thetadiff__1env1base,base_thetadiff__0base0env,base_thetadiff__0base1env,base_thetadiff__1base0env,base_thetadiff__1base1env)
env_thetadiff__0env0base<-median(newres$newdiff[newres$AI_diffinVirginandMated==0&newres$oldenv==0])
env_thetadiff__0env1base<-median(newres$newdiff[newres$AI_diffinVirginandMated==0&newres$oldenv==1])
env_thetadiff__1env0base<-median(newres$newdiff[newres$AI_diffinVirginandMated==1&newres$oldenv==0])
env_thetadiff__1env1base<-median(newres$newdiff[newres$AI_diffinVirginandMated==1&newres$oldenv==1])
base_thetadiff__0base0env<-median(newres$olddiff[newres$oldenv==0&newres$AI_diffinVirginandMated==0])
base_thetadiff__0base1env<-median(newres$olddiff[newres$oldenv==0&newres$AI_diffinVirginandMated==1])
base_thetadiff__1base0env<-median(newres$olddiff[newres$oldenv==1&newres$AI_diffinVirginandMated==0])
base_thetadiff__1base1env<-median(newres$olddiff[newres$oldenv==1&newres$AI_diffinVirginandMated==1])
myt<-matrix(c(env_thetadiff__0env0base,env_thetadiff__0env1base,env_thetadiff__1env0base,env_thetadiff__1env1base,base_thetadiff__0base0env,base_thetadiff__1base0env,base_thetadiff__0base1env,base_thetadiff__1base1env),ncol=2,byrow=F,dimnames=list(c("0env0base","0env1base","1env0base","1env1base"),c("Env","Base")))
write.table(myt,out.table,quote=F,sep="\t")
newres$scenario<-1
newres$scenario[newres$AI_diffinVirginandMated==0&newres$oldenv==1]<-2
newres$scenario[newres$AI_diffinVirginandMated==1&newres$oldenv==0]<-3
newres$scenario[newres$oldenv==1&newres$AI_diffinVirginandMated==1]<-4

#The 4 scenarios are described in the four lines of the table myt
newres$cov_V<-newres$counts_V_both+newres$counts_V_line+newres$counts_V_tester
newres$cov_M<-newres$counts_M_both+newres$counts_M_line+newres$counts_M_tester
newpp<-aggregate(newres[,c("olddiff","newdiff","cov_M","cov_V","counts_V_both","counts_M_both","counts_V_line","counts_M_line","counts_V_tester","counts_M_tester")],by=list(newres$scenario),FUN=median)
newpp<-newpp[,c("olddiff","newdiff","cov_M","cov_V")]
row.names(newpp)<-c("0env0base","0env1base","1env0base","1env1base")
write.table(newpp,out.table,quote=F,sep="\t")
browser()
}



compare.condition.genes<-function(
	infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/merged_data.csv",
	pdfstats="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/AI_diff_VM.pdf")
{
#Print some tables
library(grid)
library(gridExtra)
library(gtable)

library(data.table)
myres<-fread(infile,data.table=F)

newdiffcond<-myres[myres$AI_diffinVirginandMated>0,]
newnodiffcond<-myres[myres$AI_diffinVirginandMated<1,]

empnwediff<-myres[myres$AI_Virgin_decision!=myres$AI_Mated_decision,]
empnwenodiff<-myres[myres$AI_Virgin_decision==myres$AI_Mated_decision,]
empolddiff<-myres[myres$AI_intersection_test_M!=myres$AI_intersection_test_V,]
empnoldnodiff<-myres[myres$AI_intersection_test_M==myres$AI_intersection_test_V,]

countall<-table(myres$AI_diffinVirginandMated)
exon.nosig<-length(unique(newnodiffcond$fusion_id[!newnodiffcond$fusion_id%in%newdiffcond$fusion_id]))
exon.sig<-length(unique(newdiffcond$fusion_id))
empnewexon.nodiff<-length(unique(empnwenodiff$fusion_id[!empnwenodiff$fusion_id%in%empnwediff$fusion_id]))
empnewexon.diff<-length(unique(empnwediff$fusion_id))
empoldexon.nodiff<-length(unique(empnoldnodiff$fusion_id[!empnoldnodiff$fusion_id%in%empolddiff$fusion_id]))
empoldexon.diff<-length(unique(empolddiff$fusion_id))
exons.empnew<-c(empnewexon.nodiff,empnewexon.diff)
exons.empold<-c(empoldexon.nodiff,empoldexon.diff)
exons<-c(exon.nosig,exon.sig)
totalemp.new<-c(nrow(empnwenodiff),nrow(empnwediff))
totalemp.old<-c(nrow(empnoldnodiff),nrow(empolddiff))


mytab<-rbind(countall,totalemp.new,totalemp.old,exons,exons.empnew,exons.empold)
row.names(mytab)<-c("Total (Exons*Lines)","Total Emp. New","Total Emp. Old","Exons","Exons Emp. New","Exons Emp. Old")
colnames(mytab)<-c("Equal","Differ")

#Report the number of exons that show Different AI in mated VS virgin
#Open pdf
pdf(pdfstats)
t1 <- tableGrob(mytab)
padding <- unit(15,"mm")
title <- textGrob("AI differ Mated Virgin extended",gp=gpar(fontsize=15))
table <- gtable_add_rows(t1, heights = grobHeight(title) + padding, pos = 0)
table <- gtable_add_grob(table, title, 1, 1, 1, ncol(table))
grid.newpage()
grid.draw(table)
dev.off()
#Close pdf

}


cov.and.diff.AI<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/merged_data.csv",
                    outfile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_S_AI_class_cov.pdf")
{
library(data.table)
library(multcompView)
newres<-fread(infile,data.table=F)
newres$FBtr_cat<-newres$TesterinMated_q025<-newres$TesterVirgin_q975<-newres$TesterVirgin_q025<-newres$TesterinMated_q975<-newres$exon_ID_cat<-NULL
newres$counts_V_total<-newres$counts_V_tester+newres$counts_V_line+newres$counts_V_both
newres$counts_M_total<-newres$counts_M_tester+newres$counts_M_line+newres$counts_M_both
newres$counts_all_total<-newres$counts_M_total+newres$counts_V_total
newres$class_V<-newres$class_M<-0
newres$class_V[newres$AI_Virgin_decision==1&newres$AI_intersection_test_V==0]<-1
newres$class_V[newres$AI_Virgin_decision==0&newres$AI_intersection_test_V==1]<-2
newres$class_V[newres$AI_Virgin_decision==1&newres$AI_intersection_test_V==1]<-3
newres$class_M<-newres$class_M<-0
newres$class_M[newres$AI_Mated_decision==1&newres$AI_intersection_test_M==0]<-1
newres$class_M[newres$AI_Mated_decision==0&newres$AI_intersection_test_M==1]<-2
newres$class_M[newres$AI_Mated_decision==1&newres$AI_intersection_test_M==1]<-3
mycol<-c("gray","yellow2","firebrick","orange")

sig.m<-pairwise.wilcox.test(newres$counts_M_total,newres$class_M,p.adjust.method="b")
sig.v<-pairwise.wilcox.test(newres$counts_V_total,newres$class_V,p.adjust.method="b")
mymat.m<-tri.to.squ(sig.m$p.value)
mymat.v<-tri.to.squ(sig.v$p.value)
myletters.m<-multcompLetters(mymat.m,compare="<=",threshold=0.01,Letters=letters)
myletters.v<-multcompLetters(mymat.v,compare="<=",threshold=0.01,Letters=letters)
limdo<-log10(0.1+min(newres$counts_M_total,newres$counts_V_total))
limup<-log10(max(newres$counts_M_total,newres$counts_V_total))

pdf(outfile)
par(mfrow=c(1,2))
par(mar=c(6, 4.5, 2, 0))
boxplot(log10(counts_M_total) ~ class_M, ylim=c(limdo,0.2+limup),data=newres,col=mycol,xaxt="n",ylab=expression("Log"[10]*" Coverage"), main="Mated")
text(c(1,2,3,4),0.15+limup,c(myletters.m$Letters[1],myletters.m$Letters[2],myletters.m$Letters[3],myletters.m$Letters[4]))
axis(1,las=2,at=c(1,2,3,4),padj=0.5,labels=c("Env = No AI\nBase = No AI","Env = AI\nBase = No AI","Env = No AI\nBase = AI","Env = AI\nBase = AI"),cex.axis=0.8)
par(mar=c(6, 3, 2, 1))
boxplot(log10(counts_V_total) ~ class_V,ylim=c(limdo,0.2+limup), data=newres,col=mycol,xaxt="n", main="Virgin")
text(c(1,2,3,4),0.15+limup,c(myletters.v$Letters[1],myletters.v$Letters[2],myletters.v$Letters[3],myletters.v$Letters[4]))
axis(1,las=2,at=c(1,2,3,4),padj=0.5,labels=c("Env = No AI\nBase = No AI","Env = AI\nBase = No AI","Env = No AI\nBase = AI","Env = AI\nBase = AI"),cex.axis=0.8)
dev.off()

}

exons.genes.AI<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/merged_data.csv",
outfile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Table_4.txt",
outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_test.pdf")
{
library(data.table)
library(VennDiagram)
library(gridExtra)
myres<-fread(infile)
bygene<-aggregate(cbind(myres$AI_intersection_test_M,myres$AI_intersection_test_V,myres$AI_Mated_decision,myres$AI_Virgin_decision,myres$AI_diffinVirginandMated),by=list(myres$FBgn_cat),FUN=sum)
setnames(bygene,c("FBgn_cat","AI_intersection_test_M","AI_intersection_test_V","AI_Mated_decision","AI_Virgin_decision","AI_diffinVirginandMated"))
bygene[,2:ncol(bygene)][bygene[,2:ncol(bygene)]>0]<-1
mat1<-table(bygene$AI_intersection_test_V,bygene$AI_intersection_test_M)
mat2<-table(bygene$AI_Virgin_decision,bygene$AI_Mated_decision)
mat3<-mat2
mat3[1,1]<-sum(bygene$AI_Virgin_decision==0&bygene$AI_Mated_decision==0&bygene$AI_diffinVirginandMated==1)
mat3[1,2]<-sum(bygene$AI_Virgin_decision==0&bygene$AI_Mated_decision==1&bygene$AI_diffinVirginandMated==1)
mat3[2,1]<-sum(bygene$AI_Virgin_decision==1&bygene$AI_Mated_decision==0&bygene$AI_diffinVirginandMated==1)
mat3[2,2]<-sum(bygene$AI_Virgin_decision==1&bygene$AI_Mated_decision==1&bygene$AI_diffinVirginandMated==1)
dimnames(mat1)<-list(c("Base_Virgin_No_AI","Base_Virgin_AI"),c("Base_Mated_No_AI","Base_Mated_AI"))
dimnames(mat2)<-list(c("Env_Virgin_No_AI","Env_Virgin_AI"),c("Env_Mated_No_AI","Env_Mated_AI"))
dimnames(mat3)<-list(c("Bdiff_Virgin_No_AI","Bdiff_Virgin_AI"),c("Bdiff_Mated_No_AI","Bdiff_Mated_AI"))
allmat<-rbind(mat1,mat2,mat3)
write.table(allmat,outfile,sep="\t",quote=F)
matcross<-mat1
matcross[1,1]<-sum(bygene$AI_Virgin_decision==0&bygene$AI_Mated_decision==0&bygene$AI_intersection_test_V==0&bygene$AI_intersection_test_M==0)
matcross[1,2]<-sum(bygene$AI_Virgin_decision==0&bygene$AI_Mated_decision==1&bygene$AI_intersection_test_V==0&bygene$AI_intersection_test_M==1)
matcross[2,1]<-sum(bygene$AI_Virgin_decision==1&bygene$AI_Mated_decision==0&bygene$AI_intersection_test_V==1&bygene$AI_intersection_test_M==0)
matcross[2,2]<-sum(bygene$AI_Virgin_decision==1&bygene$AI_Mated_decision==1&bygene$AI_intersection_test_V==1&bygene$AI_intersection_test_M==1)
nono<-draw.pairwise.venn(area1=mat1[1,1],area2=mat2[1,1],cross.area=matcross[1,1],fill = c("deepskyblue","red2"), alpha = rep(0.5, 2),category=c("Env","Base"),scale=F,plot=F,cat.pos=c(180,180))
yesno<-draw.pairwise.venn(area1=mat1[1,2],area2=mat2[1,2],cross.area=matcross[1,2],fill = c("deepskyblue","red2"), alpha = rep(0.5, 2),category=c("Env","Base"),scale=F,plot=F,cat.pos=c(180,180))
noyes<-draw.pairwise.venn(area1=mat1[2,1],area2=mat2[2,1],cross.area=matcross[2,1],fill = c("deepskyblue","red2"), alpha = rep(0.5, 2),category=c("Env","Base"),scale=F,plot=F,cat.pos=c(180,180))
yesyes<-draw.pairwise.venn(area1=mat1[2,2],area2=mat2[2,2],cross.area=matcross[2,2],fill = c("deepskyblue","red2"), alpha = rep(0.5, 2),category=c("Env","Base"),scale=F,plot=F,cat.pos=c(180,180))
main.nono<-textGrob(x=0.5,y=0.9,label=expression(paste(alpha[M]==1," ",alpha[V]==1)))
nono<-gList(nono,main.nono)
main.yesno<-textGrob(x=0.5,y=0.9,label=expression(paste(alpha[M]!=1," ",alpha[V]==1)))
yesno<-gList(yesno,main.yesno)
main.noyes<-textGrob(x=0.5,y=0.9,label=expression(paste(alpha[M]==1," ",alpha[V]!=1)))
noyes<-gList(noyes,main.noyes)
main.yesyes<-textGrob(x=0.5,y=0.9,label=expression(paste(alpha[M]!=1," ",alpha[V]!=1)))
yesyes<-gList(yesyes,main.yesyes)
pdf(outgraph)
grid.arrange(gTree(children=nono),gTree(children=yesno),gTree(children=noyes),gTree(children=yesyes))
dev.off()
browser()
}

#Read the 200 genes for which Justin identified significant ASE, and see how they behave in our model.
compare.200.genes<-function(jfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/Supplemental_Table4_lmm2.csv",
                    myfile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Suppl_Table_genes_AI.txt",
                    mfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/merged_data.csv",
                    fullfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv")
{
library(data.table)
#These are the 200 genes of supplementary table 4
orig<-fread(jfile,data.table=F)
new<-fread(myfile,data.table=F)
new$orig.genes<-0
new$orig.genes[new$Gene_name%in%orig$gene_name]<-1
new$Diff_AI_frac<-new$Diff_AI/new$Count
new$top_frac<-0
new$top_frac[new$Diff_AI_frac>0.25]<-1
new$top_numb<-0
new$top_numb[new$Diff_AI>20]<-1

merged<-fread(mfile,data.table=F)
merged$orig.genes<-0
merged$orig.genes[merged$gene_name%in%orig$gene_name]<-1
merged$FBtr_cat<-merged$exon_ID_cat<-NULL
merged$TesterinMated_q025<-merged$TesterinMated_q975<-NULL
merged$TesterVirgin_q025<-merged$TesterVirgin_q975<-NULL
merged$Exon_Gene_ID_cat<-merged$chisqpvalue<-NULL
merged$emp<-merged$AI_Mated_decision-merged$AI_Virgin_decision
pp<-aggregate(merged[,c("orig.genes","AI_diffinVirginandMated","emp")],by=list(merged$gene_name),FUN="sum")
ff<-fread(fullfile,data.table=F)
ff$line_gene<-apply(cbind(ff$line,ff$symbol_cat),1,paste,collapse="_")
}

several.tables<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/merged_data.csv",
                        out1="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Table_3.txt")
{
library(data.table)
library(psych)
myres<-fread(infile,data.table=F)
vir<-table(myres$AI_intersection_test_V,myres$AI_Virgin_decision)

mat<-table(myres$AI_intersection_test_M,myres$AI_Mated_decision)
full<-rbind(mat,vir)
row.names(full)<-paste(c("Mated_Base","Mated_Base","Virgin_Base","Virgin_Base"),row.names(full),sep="_")
colnames(full)<-paste(c("Env","Env"),colnames(full),sep="_")
write.table(full,out1,sep="\t",quote=F)
cohen.kappa(vir)
cohen.kappa(mat)

}

#####
#OLd stuff below!
######


compare.oldnewpython<-function(
	old.cistrans="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/Supplemental_Table3_lmm1.csv",
	inpython1="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/cistrans_Justin/outputcistrans_M_Justin.csv",
	inpython2="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/cistrans_Justin/outputcistrans_V_Justin.csv",
	outpdf="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/cis_trans_old_new_python.pdf")
{
library(data.table)
#Read the new python results
mypyth1<-fread(inpython1,data.table=F)
mypyth2<-fread(inpython2,data.table=F)
mypyth1$fusion_line<-apply(cbind(mypyth1$line,mypyth1$fusion_id),1,paste,collapse="_")
mypyth2$fusion_line<-apply(cbind(mypyth2$line,mypyth2$fusion_id),1,paste,collapse="_")
mypyth1<-mypyth1[,c("fusion_line","cis_tester" ,"cis_line", "trans_tester","trans_line")]
mypyth2<-mypyth2[,c("fusion_line","cis_tester" ,"cis_line", "trans_tester","trans_line")]

#Read the old python results
oldres<-fread(old.cistrans,data.table=F)
oldres$fusion_line<-apply(cbind(oldres$genotype,oldres$exonic_region),1,paste,collapse="_")
#Only keep essential columns
oldres<-oldres[,!names(oldres)%in%c("direction_cis","direction_trans")]
#Transform the dataset so that the structure is similar to the new one
#Mainly, we want one line for genotype and exon reporting results for mated and virgin in different columns
oldres<-oldres[,c("fusion_line","mating_status","cis_effects_genotype","trans_effects_genotype")]
oldmated<-oldres[oldres$mating_status=="M",]
oldvirgin<-oldres[oldres$mating_status=="V",]
oldmated<-na.omit(oldmated)
oldvirgin<-na.omit(oldvirgin)

allM<-merge(mypyth1,oldmated,by="fusion_line",all=F)
allV<-merge(mypyth2,oldvirgin,by="fusion_line",all=F)
browser()

}


compare.methods<-function(
	inr="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/extend_library8.cistrans.csv",
	inpython1="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/cistrans_Justin/outputcistrans_M_Justin.csv",
	inpython2="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/cistrans_Justin/outputcistrans_V_Justin.csv",
	outpdf="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/cis_trans_r_python.pdf")
{
library(data.table)
myrdata<-fread(inr,data.table=F)
mypyth1<-fread(inpython1,data.table=F)
mypyth2<-fread(inpython2,data.table=F)
myrdata$fusion_line<-apply(cbind(myrdata$line,myrdata$fusion_id),1,paste,collapse="_")
mypyth1$fusion_line<-apply(cbind(mypyth1$line,mypyth1$fusion_id),1,paste,collapse="_")
mypyth2$fusion_line<-apply(cbind(mypyth2$line,mypyth2$fusion_id),1,paste,collapse="_")
Mrdata<-myrdata[,c("fusion_line","cis_line_M","trans_line_M","cis_tester_M","trans_tester_M")]
Vrdata<-myrdata[,c("fusion_line","cis_line_V","trans_line_V","cis_tester_V","trans_tester_V")]
mypyth1<-mypyth1[,c("fusion_line","cis_tester" ,"cis_line", "trans_tester","trans_line")]
mypyth2<-mypyth2[,c("fusion_line","cis_tester" ,"cis_line", "trans_tester","trans_line")]
Mmerged<-merge(Mrdata,mypyth1,all=F)
Vmerged<-merge(Vrdata,mypyth2,all=F)
#Ok, I stopped here writing the function because it was obvious that my R function has something wrong.
#Maybe I will try to rewrite it so that it is ok, or maybe I will just use the python version


}



winsor1<-function (x, fraction=.05)
{
   if(length(fraction) != 1 || fraction < 0 ||
         fraction > 0.5) {
      stop("bad value for 'fraction'")
   }
	x<-na.omit(x)   
	lim <- quantile(x, probs=c(fraction, 1-fraction))
   x[ x < lim[1] ] <- lim[1]
   x[ x > lim[2] ] <- lim[2]
   x
}



tri.to.squ<-function(x)
{
rn<-row.names(x)
cn<-colnames(x)
an<-unique(c(cn,rn))
myval<-x[!is.na(x)]
mymat<-matrix(1,nrow=length(an),ncol=length(an),dimnames=list(an,an))
for(ext in 1:length(cn))
{
    for(int in 1:length(rn))
    {
    if(is.na(x[row.names(x)==rn[int],colnames(x)==cn[ext]])) next
    mymat[row.names(mymat)==rn[int],colnames(mymat)==cn[ext]]<-x[row.names(x)==rn[int],colnames(x)==cn[ext]]
    mymat[row.names(mymat)==cn[ext],colnames(mymat)==rn[int]]<-x[row.names(x)==rn[int],colnames(x)==cn[ext]]
    }
 
}
return(mymat)
}