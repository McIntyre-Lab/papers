#clean.2016
#Perform some cleaning steps and save new file

#add.cis.trans: estimates contributes of cis and trans and appends them to the data.frame
#plot.cis.trans: plots cis and trans values as in Justin Figure 4

#check.dist.rand:

clean.2016<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/extend_library8_18jan2016.csv",
	outfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/extend_library8.clean.csv",
	gene.info.file="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/Supplemental_Data2_lmm3.csv",	
	max.fusion.dev.mean=0.05,max.fusion.dev.median=0.05,
	ratio.to.total=0.01,min.assigned=50,min.total=200,max.dev.mean=0.05,max.dev.median=0.05,min.line.per.fusion=2,min.fusions.per.line=500)
{
library(data.table)
ww<-fread(infile,data.table=F)

#1st Cleaning step
#Remove entries (i.e. fusions in lines) in which the proportion of reads that can be attributed to an allele is
#less than x% (default=1) than the total 

ratio_M<-(ww$counts_M_tester+ww$counts_M_line)/(ww$counts_M_tester+ww$counts_M_line+ww$counts_M_both)
ww<-ww[ratio_M>=ratio.to.total,]
ratio_V<-(ww$counts_V_tester+ww$counts_V_line)/(ww$counts_V_tester+ww$counts_V_line+ww$counts_V_both)
ww<-ww[ratio_V>=ratio.to.total,]
ww<-ww[ww$counts_M_line+ww$counts_M_tester>min.assigned&ww$counts_V_line+ww$counts_V_tester>min.assigned,]
ww<-ww[ww$counts_M_line+ww$counts_M_tester+ww$counts_M_both>min.total&ww$counts_V_line+ww$counts_V_tester+ww$counts_V_both>min.total,]

#2nd cleaning step. 
#Remove fusions that have mean or medians different from 0.5 or different between conditions

mymean<-aggregate(cbind(ww$TesterinMated_mean,ww$TesterVirgin_mean),by=list(ww$fusion_id),FUN=mean)
mymedian<-aggregate(cbind(ww$TesterinMated_mean,ww$TesterVirgin_mean),by=list(ww$fusion_id),FUN=median)
mycount<-aggregate(ww$TesterinMated_mean,by=list(ww$fusion_id),FUN=length)
#reformat the data.frame
names(mymedian)<-c("fusion_id","Median_A","Median_B")
names(mymean)<-c("fusion_id","Mean_A","Mean_B")
names(mycount)<-c("fusion_id","counts")
mysummary<-merge(mymean,mymedian)
mysummary<-merge(mysummary,mycount)
mysummary$fail<-""
mysummary$fail[abs(mysummary$Median_A-0.5)>max.fusion.dev.median]<-paste(mysummary$fail[abs(mysummary$Median_A-0.5)>max.fusion.dev.median],"Med_A",sep="")
mysummary$fail[abs(mysummary$Median_B-0.5)>max.fusion.dev.median]<-paste(mysummary$fail[abs(mysummary$Median_B-0.5)>max.fusion.dev.median],"Med_B",sep="")
mysummary$fail[abs(mysummary$Median_B-mysummary$Median_A)>max.fusion.dev.median]<-paste(mysummary$fail[abs(mysummary$Median_B-mysummary$Median_A)>max.fusion.dev.median],"Med_AB",sep="")
mysummary$fail[abs(mysummary$Mean_A-0.5)>max.fusion.dev.mean]<-paste(mysummary$fail[abs(mysummary$Mean_A-0.5)>max.fusion.dev.mean],"Mean_A",sep="")
mysummary$fail[abs(mysummary$Mean_B-0.5)>max.fusion.dev.mean]<-paste(mysummary$fail[abs(mysummary$Mean_B-0.5)>max.fusion.dev.mean],"Mean_B",sep="")
mysummary$fail[abs(mysummary$Mean_B-mysummary$Mean_A)>max.fusion.dev.mean]<-paste(mysummary$fail[abs(mysummary$Mean_B-mysummary$Mean_A)>max.fusion.dev.mean],"Mean_AB",sep="")

tokeep<-mysummary$fusion_id[mysummary$fail==""]
ww<-ww[ww$fusion_id%in%tokeep,]

#3rd cleaning step
#Remove lines that have mean or median theta different from 0.5 or different between conditions 

#Compute summary statistics
mymean<-aggregate(cbind(ww$TesterinMated_mean,ww$TesterVirgin_mean),by=list(ww$line),FUN=mean)
mymedian<-aggregate(cbind(ww$TesterinMated_mean,ww$TesterVirgin_mean),by=list(ww$line),FUN=median)
mycount<-aggregate(ww$TesterinMated_mean,by=list(ww$line),FUN=length)
#reformat the data.frame
names(mymedian)<-c("Line","Median_A","Median_B")
names(mymean)<-c("Line","Mean_A","Mean_B")
names(mycount)<-c("Line","counts")
mysummary<-merge(mymean,mymedian)
mysummary$fail<-""
mysummary$fail[abs(mysummary$Median_A-0.5)>max.dev.median]<-paste(mysummary$fail[abs(mysummary$Median_A-0.5)>max.dev.median],"Median_A",sep="")
mysummary$fail[abs(mysummary$Median_B-0.5)>max.dev.median]<-paste(mysummary$fail[abs(mysummary$Median_B-0.5)>max.dev.median],"Median_B",sep="")
mysummary$fail[abs(mysummary$Median_B-mysummary$Median_A)>max.dev.median]<-paste(mysummary$fail[abs(mysummary$Median_B-mysummary$Median_A)>max.dev.median],"Median_AB",sep="")
mysummary$fail[abs(mysummary$Mean_A-0.5)>max.dev.mean]<-paste(mysummary$fail[abs(mysummary$Mean_A-0.5)>max.dev.mean],"Mean_A",sep="")
mysummary$fail[abs(mysummary$Mean_B-0.5)>max.dev.mean]<-paste(mysummary$fail[abs(mysummary$Mean_B-0.5)>max.dev.mean],"Mean_B",sep="")
mysummary$fail[abs(mysummary$Mean_B-mysummary$Mean_A)>max.dev.mean]<-paste(mysummary$fail[abs(mysummary$Mean_B-mysummary$Mean_A)>max.dev.mean],"Mean_AB",sep="")

tokeep<-mysummary$Line[mysummary$fail==""]
newdf<-ww[ww$line%in%tokeep,]

#Final step. Add information on the location and gene name of the fusion
#I took the info from published results
gene.info<-fread(gene.info.file,data.table=F)
gene.info<-gene.info[,c("exonic_region","chrom","start","end","symbol_cat","Exon_Gene_ID_cat","exon_ID_cat","Exon_Name_cat",
	"FBgn_cat","FBpp_cat","FBtr_cat")]
gene.info<-gene.info[!duplicated(gene.info),]
names(gene.info)[1]<-"fusion_id"

newdf<-merge(newdf,gene.info,by="fusion_id",all.x=T,all.y=F)
#Save the results
write.table(newdf,outfile,sep=",",quote=F,row.names=F)

}


do.density.byline<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/extend_library8.clean.csv",outfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/density_theta_mean_by_line_clean.pdf")
{
library(data.table)
ww<-fread(infile)
pdf(outfile)
for(aaa in unique(ww$line))
{
mydf<-ww[ww$line==aaa,]
plot(density(mydf$TesterinMated_mean),main=paste("clean_by_distr",aaa))
lines(density(mydf$TesterVirgin_mean),col="red")
legend("topright",legend=c("Mated","Virgin"),lty=1,col=c("black","red"))
}
dev.off()

}

do.density.together<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/extend_library8.clean.csv",
		outfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/Figure_S_theta_together.pdf")
{
library(data.table)
ww<-fread(infile)
mylength<-length(unique(ww$line))
totalpoints<-nrow(ww)
pdf(outfile)
par(mar=c(5,4,2,2))
plot(density(ww$TesterinMated_mean),main="",col="black",xlab=bquote(theta ~ "distribution in" ~ .(mylength) ~ "lines," ~ .(totalpoints) ~ "data points"))
lines(density(ww$TesterVirgin_mean),col="red")
legend("topright",legend=c("Mated","Virgin"),lty=1,col=c("black","red"))
dev.off()
}

loop.density.together<-function(indir="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/",
        pattern="csv",remove.lines=F,toremove,
		outfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/Figure_S_theta_loop.pdf")
{
library(data.table)
setwd(indir)
myfiles<-dir(indir,pattern=pattern)
pdf(outfile,width=20,height=20)
#par(mar=c(5,4,4,2))
par(mfrow=c(5,5))
for(aaa in 1:length(myfiles))
{
    cat(myfiles[aaa],"\n")
    ww<-fread(myfiles[aaa])
    if(remove.lines) ww<-ww[!ww$line%in%toremove,]
    exon.max<-unlist(strsplit(myfiles[aaa],"_"))[7]
    line.max<-gsub(".csv","",unlist(strsplit(myfiles[aaa],"_"))[11])
    mylength<-length(unique(ww$line))
    totalpoints<-nrow(ww)
    plot(density(ww$TesterVirgin_mean),main=paste("Max deviation exons=",exon.max,"Max deviation line=",line.max),col="red",xlab=bquote(theta ~ "distribution in" ~ .(mylength) ~ "lines," ~ .(totalpoints) ~ "data points"))
    lines(density(ww$TesterinMated_mean),col="black")
    legend("topright",legend=c("Mated","Virgin"),lty=1,col=c("black","red"))
}
dev.off()
}

#This function was born because we noticed that some bias was added when adding lines 42-59 (actually, when going to 0.05 to 0.1 in the proportion of deviation allowed for)
# Thus we were curious to see what happened if we removed from analysis only such lines. To find those lines we simply have to see which lines are introduced when changing from 0.05
# to 0.1. Then, we will repeat the "loop" analysis and see what happens. 
select.lines.and.do.loop<-function(file1="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_0.75_line_max_dev_0.05.csv",
                        file2="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_0.1_line_max_dev_0.1.csv",
                        out.graph="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/density_minline_1_minfusion_1_bad_lines_removed.pdf",
                        indir="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/")
{
library(data.table)
restrictive<-fread(file1,data.table=F)
permissive<-fread(file2,data.table=F)
toremove<-unique(permissive$line[!permissive$line%in%restrictive$line])
loop.density.together(indir=indir,remove.lines=T,toremove=toremove,outfile=out.graph)
browser()

}

check.dist.rand<-function(
    newfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
	outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/exon_dist.pdf",
    outtable="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/exon_dist.txt",
    max.num=10,do.log=F,bygene=F)
{
library(data.table)
#New is my clean data
newres<-fread(newfile,data.table=F)
ifelse(bygene,byfusion<-aggregate(newres$AI_diffinVirginandMated,by=list(newres$symbol_cat),FUN=sum),
            byfusion<-aggregate(newres$AI_diffinVirginandMated,by=list(newres$fusion_id),FUN=sum))
byfusion<-byfusion[order(byfusion$x,decreasing=T),]
names(byfusion)<-c("fusion_id","counts")
mydf<-data.frame(table(byfusion$counts))

tosample<-sum(newres$AI_diffinVirginandMated)
#Compare distribution with random
#Every time we randomly take a number of exons equal to the number of exons showing different AI in Virgin and Mated
#And compute its distribution
#browser()
ifelse(bygene,mydist<-newres[,c("symbol_cat","line","AI_diffinVirginandMated")],mydist<-newres[,c("fusion_id","line","AI_diffinVirginandMated")])
for(aaa in 1:1000)
{
cat(aaa,"\n")
mydist$AI_diffinVirginandMated<-0
mydist$AI_diffinVirginandMated[sample(nrow(mydist),tosample)]<-1
ifelse(bygene,myfusion<-aggregate(mydist$AI_diffinVirginandMated,by=list(mydist$symbol_cat),FUN=sum),
            myfusion<-aggregate(mydist$AI_diffinVirginandMated,by=list(mydist$fusion_id),FUN=sum))
myfusion<-myfusion[order(myfusion$x,decreasing=T),]
names(myfusion)<-c("fusion_id","counts")
cat(as.character(myfusion[1,]),"\n")
rdf<-data.frame(table(myfusion$counts))
names(rdf)<-c("Var",paste("Freq_",aaa,sep=""))
if(aaa==1) alldf<-rdf else alldf<-merge(alldf,rdf,by="Var",all=T)
}

myfinal<-data.frame(t(apply(alldf[,2:ncol(alldf)],1,quantile,probs=c(0.025,0.5,0.975),na.rm=T)))
myfinal$Var<-alldf$Var
superfinal<-merge(mydf,myfinal,by.x="Var1",by.y="Var",sort=F,all=T)
superfinal$"X2.5."[is.na(superfinal$"X2.5.")]<-0
superfinal$"X50."[is.na(superfinal$"X50.")]<-0
superfinal$"X97.5."[is.na(superfinal$"X97.5.")]<-0
superfinal<-superfinal[order(superfinal$Var1),]
#Exons showing the same behavior in more than 10 (e.g.) lines are quite rare, thus we aggregate this results in one class ">10"
#The number can be changed
#We write summary statistics for this last aggregated class
last.class<-apply(superfinal[as.numeric(as.character(superfinal$Var1))>=max.num,2:ncol(superfinal)],2,sum,na.rm=T)
superfinal$Var1<-as.numeric(as.character(superfinal$Var1))
#Remove all classes greater than the selected number
superfinal<-superfinal[as.numeric(as.character(superfinal$Var1))<=max.num,]
#Substitute the aggregated statistics in the last line, to which we wl also change name
superfinal[nrow(superfinal),2:ncol(superfinal)]<-last.class
superfinal$Var1[nrow(superfinal)]<-paste(">",max.num,sep="")
if(do.log)
{
    superfinal$Freq<-log10(superfinal$Freq)
    superfinal$"X2.5."<-log10(superfinal$"X2.5.")
    superfinal$"X50."<-log10(superfinal$"X50.")
    superfinal$"X97.5."<-log10(superfinal$"X97.5.")
    outgraph<-gsub(".pdf","_log.pdf",outgraph)
    outtable<-gsub(".csv","_log.csv",outtable)
}
library(gplots)
mycolors=c("deepskyblue3","deepskyblue4")
pdf(outgraph)
barplot2(t(cbind(superfinal$Freq,superfinal$"X50.")),plot.ci=T,ci.l=t(cbind(superfinal$Freq,superfinal$"X2.5.")),beside=T,
	ci.u=t(cbind(superfinal$Freq,superfinal$"X97.5.")),names.arg=superfinal$Var1,col=mycolors)
legend("topright",legend=c("Real","Simulated"),fill=mycolors)
#barplot(cbind(superfinal$Freq,superfinal$"X50."),beside=T)
dev.off()
write.table(superfinal,outtable,quote=F,sep="\t",row.names=F)
browser()
}



add.cis.trans<-function(
	infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/extend_library8.clean.csv",
	outfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/extend_library8.cistrans.csv",
	exon=c("fusion_id","fusion_id"),
	paternal_counts=c("counts_M_tester","counts_V_tester"),
	maternal_counts=c("counts_M_line","counts_V_line"),
	both_counts=c("counts_M_both","counts_V_both"),
	out.suffix=c("M","V")	
	)
{
library(data.table)
source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/compute_cis_trans.r")
mydata<-fread(infile,data.table=F)
if(length(exon)!=length(paternal_counts)) stop("Exons and parental counts length should be the same")
for(aaa in 1: length(out.suffix))
{
cat(aaa,"\n")
estim<-cistrans(mydata[,c(exon[aaa],paternal_counts[aaa],maternal_counts[aaa],both_counts[aaa])],exon=exon[aaa],paternal_counts=paternal_counts[aaa],maternal_counts=maternal_counts[aaa],
	both_counts=both_counts[aaa])
#The function add the last four columns. I just append the suffix to them, to distinguish MAted from Virgin
names(estim)<-paste(names(estim),out.suffix[aaa],sep="_")
mydata<-cbind(mydata,estim)
}
write.table(mydata,outfile,sep=",",quote=F,row.names=F)
}



plot.cis.trans<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/extend_library8.cistrans.csv",
	outpdf="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/Justin4.pdf",
	onlysig=T,adjmean=50,adjvar=1000,varlim=1000000,meanlim=1000,nbreaks=1000,winsor=T,lev=0.025)
{
library(data.table)
bb<-fread(infile,data.table=F)

#Select exons with AI in mated
if(onlysig) TAIM<-bb[bb$AI_Mated_decision>0,] else TAIM<-bb
#compute mean and variance (should it be done across lines or across exons?)
#IN the paper Justin did by exons

AIM_cis_mean<-aggregate(TAIM$cis_line_M,by=list(TAIM$fusion_id),FUN=mean)
AIM_cis_sd<-aggregate(TAIM$cis_line_M,by=list(TAIM$fusion_id),FUN=sd)
AIM_cis_var<-AIM_cis_sd$x^2
AIM_cis_var[AIM_cis_mean$x<0]<-(-AIM_cis_var[AIM_cis_mean$x<0])

AIM_trans_mean<-aggregate(TAIM$trans_line_M,by=list(TAIM$fusion_id),FUN=mean)
AIM_trans_sd<-aggregate(TAIM$trans_line_M,by=list(TAIM$fusion_id),FUN=sd)
AIM_trans_var<-AIM_trans_sd$x^2
AIM_trans_var[AIM_trans_mean$x<0]<-(-AIM_trans_var[AIM_trans_mean$x<0])

#Select exons with AI in virgins
if (onlysig) TAIV<-bb[bb$AI_Virgin_decision>0,] else TAIV<-bb
AIV_cis_mean<-aggregate(TAIV$cis_line_V,by=list(TAIV$fusion_id),FUN=mean)
AIV_cis_sd<-aggregate(TAIV$cis_line_V,by=list(TAIV$fusion_id),FUN=sd)
AIV_cis_var<-AIV_cis_sd$x^2
AIV_cis_var[AIV_cis_mean$x<0]<-(-AIV_cis_var[AIV_cis_mean$x<0])

AIV_trans_mean<-aggregate(TAIV$trans_line_V,by=list(TAIV$fusion_id),FUN=mean)
AIV_trans_sd<-aggregate(TAIV$trans_line_V,by=list(TAIV$fusion_id),FUN=sd)
AIV_trans_var<-AIV_trans_sd$x^2
AIV_trans_var[AIV_trans_mean$x<0]<-(-AIV_trans_var[AIV_trans_mean$x<0])



#Remove outliers by a rough winsorization
if(winsor)
{
	AIM_cis_mean$x<-winsor1(AIM_cis_mean$x,fraction=lev)
	AIM_trans_mean$x<-winsor1(AIM_trans_mean$x,fraction=lev)
	AIV_cis_mean$x<-winsor1(AIV_cis_mean$x,fraction=lev)
	AIV_trans_mean$x<-winsor1(AIV_trans_mean$x,fraction=lev)
	AIM_cis_var<-winsor1(AIM_cis_var,fraction=lev)
	AIM_trans_var<-winsor1(AIM_trans_var,fraction=lev)
	AIV_cis_var<-winsor1(AIV_cis_var,fraction=lev)
	AIV_trans_var<-winsor1(AIV_trans_var,fraction=lev)
}

#Plot mean and variance of cis and trans estimates in each exon
colcis<-"plum2"
coltrans<-"darkorange"
pdf(outpdf)
layout(matrix(c(1,2,3,4),2,2,byrow=T))
plot(density(AIM_cis_mean$x,adjust=adjmean),col=colcis,xlim=c(-meanlim,meanlim),cex.axis=0.8,main="Mated mean",xlab=NA)
lines(density(AIM_trans_mean$x,adjust=adjmean),col=coltrans)
legend("topleft",legend=c("cis","trans"),lty=1,col=c(colcis,coltrans))
#plot(density(AIM_cis_sd$x,na.rm=T),col=colcis,main="Mated sd")
#lines(density(AIM_trans_sd$x,na.rm=T),col=coltrans)
plot(density(AIM_cis_var,na.rm=T,adjust=adjvar),col=colcis,xlim=c(-varlim,varlim),cex.axis=0.8,main="Mated variance",xlab=NA)
lines(density(AIM_trans_var,na.rm=T,adjust=adjvar),col=coltrans)
legend("topleft",legend=c("cis","trans"),lty=1,col=c(colcis,coltrans))
plot(density(AIV_cis_mean$x,adjust=adjmean),col=colcis,xlim=c(-meanlim,meanlim),cex.axis=0.8,main="Virgin mean",xlab="")
lines(density(AIV_trans_mean$x,adjust=adjmean),col=coltrans)
legend("topleft",legend=c("cis","trans"),lty=1,col=c(colcis,coltrans))
#plot(density(AIV_cis_sd$x,na.rm=T),col=colcis,,main="Virgin sd")
#lines(density(AIV_trans_sd$x,na.rm=T),col=coltrans)
plot(density(AIV_cis_var,na.rm=T,adjust=adjvar),col=colcis,xlim=c(-varlim,varlim),cex.axis=0.8,main="Virgin variance",xlab="")
lines(density(AIV_trans_var,na.rm=T,adjust=adjvar),col=coltrans)
legend("topleft",legend=c("cis","trans"),lty=1,col=c(colcis,coltrans))

dev.off()
browser()
}




winsor2<-function (x, multiple=3)
{
   if(length(multiple) != 1 || multiple <= 0) {
      stop("bad value for 'multiple'")
   }
   med <- median(x)
   y <- x - med
   sc <- mad(y, center=0) * multiple
   y[ y > sc ] <- sc
   y[ y < -sc ] <- -sc
   y + med
}

winsor1<-function (x, fraction=.05)
{
   if(length(fraction) != 1 || fraction < 0 ||
         fraction > 0.5) {
      stop("bad value for 'fraction'")
   }
	x<-na.omit(x)   
	lim <- quantile(x, probs=c(fraction, 1-fraction))
   x[ x < lim[1] ] <- lim[1]
   x[ x > lim[2] ] <- lim[2]
   x
}
