#!/bin/bash

LOGDIR=/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/logs
cd $LOGDIR
MINLINEPERFUSION=1
MINFUSIONPERLINE=1
OUTDIR=/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_${MINLINEPERFUSION}_minfusion_${MINFUSIONPERLINE}
mkdir -p $OUTDIR
# Explore the best cleaning method.
# We expect that on average theta is symmetric around 0.5. When this is not true, we have some bias. 
# The best approach is to remove the situations givin rise to bias (may be sequencing artifacts, or mapping artifacts, we cannot correct the bias, better remove it)
# Plots showing the distribution of theta for each cleaning approach will be generated.
for EXONDEV in 0.05 0.1 0.25 1 
do
for LINEDEV in 0.05 0.1 0.25 1
do
OUTFILE=${OUTDIR}/extend_library8_clean_exon_max_dev_${EXONDEV}_line_max_dev_${LINEDEV}.csv
OUTPDF=${OUTDIR}/extend_library8_clean_exon_max_dev_${EXONDEV}_line_max_dev_${LINEDEV}.pdf

echo "module load lang/r/3.2.3; R --no-save --args status=best_cleaning exondev=$EXONDEV linedev=$LINEDEV \
minline=$MINLINEPERFUSION minfusion=$MINFUSIONPERLINE outfile=$OUTFILE outpdf=$OUTPDF < \
/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/workflow.r \
>${LOGDIR}/do_all.out 2>${LOGDIR}/do_all.err"| qsub -N do_all -l vmem=6G,walltime=10:00:00
done
done

OUTPDF=/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/density_minline_${MINLINEPERFUSION}_minfusion_${MINFUSIONPERLINE}.pdf
#Plots the distributions of thetas obtained with all the loops over EXONDEV and LINEDEV in a single plot (as a EXONDEV by LINEDEV array)
# to facilitate selection of the best performing cleaning approach
echo "module load lang/r/3.2.3; R --no-save --args status=plot_together indir=$OUTDIR outfile=$OUTPDF < \
/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/workflow.r \
>${LOGDIR}/together.out 2>${LOGDIR}/together.err"| qsub -N do_all -l vmem=3G,walltime=2:00:00

#Perform additional analysis, such as checking if exons tend to show different behavior across lines
echo "module load lang/r/3.2.3; R --no-save --args status=some_more_analysis < \
/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/workflow.r \
>${LOGDIR}/together.out 2>${LOGDIR}/together.err"| qsub -N compare_old_new -l vmem=30G,walltime=24:00:00



echo "module load lang/r/3.2.3; R --no-save --args status=compare_old_new < \
/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/workflow.r \
>${LOGDIR}/together.out 2>${LOGDIR}/together.err"| qsub -N compare_old_new -l vmem=30G,walltime=24:00:00

#Do all that is needed for Gene Ontology
echo "module load lang/r/3.3; R --no-save --args status=do_GO < \
/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/workflow.r \
>${LOGDIR}/together.out 2>${LOGDIR}/together.err"| qsub -N do_GO -l vmem=16G,walltime=24:00:00

#Do KEGG analysis
echo "module load lang/r/3.3; R --no-save --args status=do_kegg < \
/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/workflow.r \
>${LOGDIR}/kegg.out 2>${LOGDIR}/kegg.err"| qsub -N do_GO -l vmem=16G,walltime=24:00:00


#Convert huge sas data to csv using python sas7bdat package (faste than the R package)
cd /projects/novabreed/share/software/sas7bdat-2.0.7
#This file has read counts seprately for each replicates, which is what I need for running the model
./sas7bdat_to_csv /projects/novabreed/share/marroni/collaborations/Lauren/agerken/ase_extended/sas_data/counts_for_extended_bayesian.sas7bdat
mv /projects/novabreed/share/marroni/collaborations/Lauren/agerken/ase_extended/sas_data/counts_for_extended_bayesian.csv /projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/counts_for_extended_bayesian.csv


outdir=/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/sas_converted
for aaa in /projects/novabreed/share/marroni/collaborations/Lauren/agerken/ase_extended/sas_data/*
do
bbb=$(basename $aaa)
bbb=${bbb/sas7bdat/csv}
./sas7bdat_to_csv $aaa ${outdir}/${bbb}
echo $bbb
done

./sas7bdat_to_csv /projects/novabreed/share/marroni/collaborations/Lauren/agerken/ase_extended/sas_data/data_for_bayes_both_extended_sbs.sas7bdat
mv /projects/novabreed/share/marroni/collaborations/Lauren/agerken/ase_extended/sas_data/data_for_bayes_both_extended_sbs.csv /projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/data_for_bayes_both_extended_sbs.csv

#Perform some analysis using genotype as environment: 
#1 Prepare input file
echo "module load lang/r/3.3; R --no-save --args status=geno_env < \
/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/workflow.r \
>${LOGDIR}/kegg.out 2>${LOGDIR}/kegg.err"| qsub -N prep_geno_env -l vmem=8G,walltime=12:00:00

#2 run the model 
/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/bayesian_geno_as_env/run_model.sh
