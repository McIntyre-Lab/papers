#prep.geno.as.env 
#extract several info for 2 selected lines which will then be used to run the model using genotypes as environments.
#line 1 is denoted as "M" in the output file
#line 2 is denoted as "V" in the output file
prep.geno.as.env<-function(
	rawfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/counts_for_extended_bayesian.csv",
	line1="r365",line2="r907",
	asefile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/merged_data.csv",
	qsimfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/sas_converted/ase_qsim_both.csv",
	outfile=paste("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/geno_as_environment/in_",line1,"_",line2,"_",status,".csv",sep=""),
	status="V")
{
library(data.table)
#Read input files and only select the data regarding the two selected lines
raw.data<-fread(rawfile,data.table=F)
raw.data<-raw.data[raw.data$line==line1|raw.data$line==line2,]
ase.data<-fread(asefile,data.table=F)
ase.data<-ase.data[ase.data$line==line1|ase.data$line==line2,]
qsim.data<-fread(qsimfile,data.table=F)
qsim.data<-qsim.data[qsim.data$line==line1|qsim.data$line==line2,]
#Clean data.frames by removeing some useless columns
ase.data$flag_AI_alternate_direction_V<-ase.data$flag_AI_alternate_direction_M<-ase.data$FBtr_cat<-NULL
ase.data$FBgn_cat<-ase.data$exon_ID_cat<-NULL
ase.data$cis_effects_genotype_M<-ase.data$cis_effects_genotype_V<-NULL
ase.data$trans_effects_genotype_M<-ase.data$trans_effects_genotype_V<-NULL
#Select fusions analyzed in both lines
fusel<-ase.data$fusion_id[duplicated(ase.data$fusion_id)]
ase.data<-ase.data[ase.data$fusion_id%in%fusel,]
#Sort by fusion name for easier human reading
ase.data<-ase.data[order(ase.data$fusion_id),]
#Compute mean 
qsim.mean<-aggregate(cbind(qsim.data$qsim_line,qsim.data$qsim_tester,qsim.data$qsim_both),by=list(qsim.data$fusion_id),FUN="mean")
#Start building the output file, which will then be the input of the model
setnames(qsim.mean,c("fusion_id","qsim_line","qsim_tester","qsim_both"))
outdata<-qsim.mean[qsim.mean$fusion_id%in%fusel,]
outdata$V_flag_analyze<-outdata$M_flag_analyze<-1
outdata$V_num_reps<-outdata$M_num_reps<-NA
outdata$M_Both_total_1<-outdata$M_Line_total_1<-outdata$M_tester_total_1<-NA
outdata$M_Both_total_2<-outdata$M_Line_total_2<-outdata$M_tester_total_2<-NA
outdata$M_Both_total_3<-outdata$M_Line_total_3<-outdata$M_tester_total_3<-NA
outdata$V_Both_total_1<-outdata$V_Line_total_1<-outdata$V_tester_total_1<-NA
outdata$V_Both_total_2<-outdata$V_Line_total_2<-outdata$V_tester_total_2<-NA
outdata$V_Both_total_3<-outdata$V_Line_total_3<-outdata$V_tester_total_3<-NA

outdata$line<-status
#Only select raw data relevant for the selected status
raw.data<-raw.data[raw.data$mating_status==status,]

for(aaa in 1:nrow(outdata))
{
	cat(aaa,"\n")
	smallraw<-raw.data[raw.data$fusion_id==outdata$fusion_id[aaa],]
	outdata$M_num_reps[aaa]<-max(smallraw$rep[smallraw$line==line1])
	outdata$V_num_reps[aaa]<-max(smallraw$rep[smallraw$line==line2])
	#Report unassigned reads for the three replicates in line1
	outdata$M_Both_total_1[aaa]<-smallraw$BOTH_TOTAL[smallraw$line==line1&smallraw$rep==1]
	outdata$M_Both_total_2[aaa]<-smallraw$BOTH_TOTAL[smallraw$line==line1&smallraw$rep==2]
	outdata$M_Both_total_3[aaa]<-smallraw$BOTH_TOTAL[smallraw$line==line1&smallraw$rep==3]
	#Report unassigned reads for the three replicates in line2
	outdata$V_Both_total_1[aaa]<-smallraw$BOTH_TOTAL[smallraw$line==line2&smallraw$rep==1]
	outdata$V_Both_total_2[aaa]<-smallraw$BOTH_TOTAL[smallraw$line==line2&smallraw$rep==2]
	outdata$V_Both_total_3[aaa]<-smallraw$BOTH_TOTAL[smallraw$line==line2&smallraw$rep==3]
	#Report reads aligning to "line" allele for the three replicates in line1
	outdata$M_Line_total_1[aaa]<-smallraw$LINE_TOTAL[smallraw$line==line1&smallraw$rep==1]
	outdata$M_Line_total_2[aaa]<-smallraw$LINE_TOTAL[smallraw$line==line1&smallraw$rep==2]
	outdata$M_Line_total_3[aaa]<-smallraw$LINE_TOTAL[smallraw$line==line1&smallraw$rep==3]
	#Report reads aligning to "line" allele for the three replicates in line2
	outdata$V_Line_total_1[aaa]<-smallraw$LINE_TOTAL[smallraw$line==line2&smallraw$rep==1]
	outdata$V_Line_total_2[aaa]<-smallraw$LINE_TOTAL[smallraw$line==line2&smallraw$rep==2]
	outdata$V_Line_total_3[aaa]<-smallraw$LINE_TOTAL[smallraw$line==line2&smallraw$rep==3]
	#Report reads aligning to "tester" allele for the three replicates in line1
	outdata$M_tester_total_1[aaa]<-smallraw$TESTER_TOTAL[smallraw$line==line1&smallraw$rep==1]
	outdata$M_tester_total_2[aaa]<-smallraw$TESTER_TOTAL[smallraw$line==line1&smallraw$rep==2]
	outdata$M_tester_total_3[aaa]<-smallraw$TESTER_TOTAL[smallraw$line==line1&smallraw$rep==3]
	#Report reads aligning to "tester" allele for the three replicates in line2
	outdata$V_tester_total_1[aaa]<-smallraw$TESTER_TOTAL[smallraw$line==line2&smallraw$rep==1]
	outdata$V_tester_total_2[aaa]<-smallraw$TESTER_TOTAL[smallraw$line==line2&smallraw$rep==2]
	outdata$V_tester_total_3[aaa]<-smallraw$TESTER_TOTAL[smallraw$line==line2&smallraw$rep==3]
}
write.table(outdata,outfile,sep=",",quote=F,row.names=F)
browser()
}



geno.as.env<-function()
{


}
