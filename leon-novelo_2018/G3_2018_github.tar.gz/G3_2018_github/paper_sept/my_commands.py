# coding: utf-8
import pandas as pd
mytest=pd.read_csv("extend_library8.clean.csv")
df=mytest
cols = df.columns.tolist()
cols
cols.extend(['mu', 'cis_line', 'trans_line', 'cis_tester', 'trans_tester'])
df['Eti']=df['counts_V_tester']
df['Eii']=df['counts_V_line']
df['diffEtiEii'] = df['Eti'] - df['Eii']
df['diffEiiEti'] = df['Eii'] - df['Eti']
df['sumEtiEii'] = df['Eti'] + df['Eii']
group='fusion_id'
grp = df.groupby(group)
n = grp.count().iloc[:, 0]
n.name = 'n'
mu = grp['sumEtiEii'].sum() / (2 * n)
mu.name = 'mu'
sumEti = grp['Eti'].sum()
sumEti.name = 'sumEti'
mun = pd.concat([n, mu, sumEti], axis=1)
mun.reset_index(inplace=True)
munMerge = df.merge(mun, how='left', on=group)
munMerge['diff_n'] = munMerge['diffEtiEii'] / munMerge['n']
grp2 = munMerge.groupby(group)
Ct = grp2['diff_n'].sum()
Ct.name = 'cis_tester'
CtI = Ct.reset_index()
ctMerge = munMerge.merge(CtI, how='left', on=group)
ctMerge['cis_line'] = ctMerge['diffEiiEti'] + ctMerge['cis_tester']
ctMerge['trans_tester'] = 2 * (ctMerge['sumEti'] / ctMerge['n'] - ctMerge['mu'] - ctMerge['cis_tester'])
ctMerge['trans_line'] = 2 * (ctMerge['Eti'] - ctMerge['mu'] - ctMerge['cis_tester']) - ctMerge['trans_tester']
ctMerge.to_csv("outputcistrans_V.csv")
