exons.AI.plot<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
	outfile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_S_Justin2B.pdf")
{
#Plot the number of exons showing AI in each line
library(gplots)
library(data.table)
ww<-fread(infile,data.table=F)
exon.line<-data.frame(table(ww$line))
ex.sig<-aggregate(cbind(ww$AI_Mated_decision,ww$AI_Virgin_decision,ww$AI_diffinVirginandMated),by=list(ww$line),FUN="sum")
new.sig<-merge(ex.sig,exon.line,by.x="Group.1",by.y="Var1")
new.sig$propMated<-new.sig$V1/new.sig$Freq
new.sig$propVirgin<-new.sig$V2/new.sig$Freq
new.sig$propdiff<-new.sig$V3/new.sig$Freq
new.sig<-new.sig[order(new.sig$propdiff,decreasing=T),]
pdf(outfile,width=6.5,height=9.8)
par(mar=c(1.7,2,0.1,0.6),oma=c(0,0,0,0),mgp=c(1,0.1,-1))
barplot2(height=t(cbind(new.sig$propMated,new.sig$propVirgin,new.sig$propdiff)),horiz=T,beside=T,border=NA,col=c("royalblue3","red3","yellow3"),names=new.sig$Group.1,las=2,cex.axis=0.6,cex.names=0.6,xlim=c(0,0.9))
legend("topright",legend=c("AI in Mated","AI in Virgin","AI Mated and Virgin differ"),fill=c("royalblue3","red3","yellow3"),cex=0.6,pt.cex=0.6)
dev.off()
}

exons.AI.old.new.plot<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/merged_data.csv",
	outfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/Justin2B.old.and.new.pdf",status="Mated",plotme=F)
{
#Plot the number of exons showing AI in each line
library(gplots)
library(data.table)
ww<-fread(infile,data.table=F)
exon.line<-data.frame(table(ww$line))
ifelse(status=="Mated",ex.sig<-aggregate(cbind(ww$AI_Mated_decision,ww$AI_intersection_test_M),by=list(ww$line),FUN="sum"),ex.sig<-aggregate(cbind(ww$AI_Virgin_decision,ww$AI_intersection_test_V),by=list(ww$line),FUN="sum"))
new.sig<-merge(ex.sig,exon.line,by.x="Group.1",by.y="Var1")
new.sig$env<-new.sig$V1/new.sig$Freq
new.sig$base<-new.sig$V2/new.sig$Freq
new.sig<-new.sig[order(new.sig$env,decreasing=T),]
mymat<-t(cbind(new.sig$env,new.sig$base))
rownames(mymat)<-c(paste("AI",status,"env"),paste("AI",status,"base"))
colnames(mymat)<-new.sig$Group.1
if(plotme)
{
    pdf(outfile,width=6.5,height=9.8)
    par(mar=c(1.7,2,0.1,0.6),oma=c(0,0,0,0),mgp=c(1,0.1,-1))
    barplot(height=mymat,horiz=T,beside=T,col=c("deepskyblue","red2"),border=NA,names=new.sig$Group.1,las=1,cex.axis=0.6,cex.names=0.6,xlim=c(0,0.5),legend.text=rownames(mymat),tck=-0.01)
    #mtext("Proportion of exons with AI", side=1, line=1.6)
    #barplot2(height=mymat,horiz=T,beside=T,border=NA,las=2,cex.axis=0.6,cex.names=0.6,xlim=c(0,0.5),legend.text=rownames(mymat))
    #legend("topright",legend=c("AI Mated Ext","AI Mated Base","AI Virgin Ext","AI Virgin base"),fill=c("deepskyblue","royalblue2","palegreen2","darkgreen"),cex=0.6,pt.cex=0.6)
    dev.off()
}
}



lines.cov.plot<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
	outfile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_S2.pdf")
{
#Plot the number of exons showing AI in each line
library(gplots)
library(data.table)
ww<-fread(infile,data.table=F)
exon.line<-data.frame(table(ww$line))
mycov<-aggregate(cbind(ww$counts_M_tester+ww$counts_M_line,ww$counts_V_tester+ww$counts_V_line),by=list(ww$line),FUN="mean")
mycov$both<-mycov$V1+mycov$V2
mycov<-mycov[order(mycov$both,decreasing=T),]
pdf(outfile,width=11,height=7)
barplot2(height=t(cbind(mycov$V1,mycov$V2)),beside=T,col=c("royalblue4","red2"),names=mycov$Group.1,las=2,cex.axis=0.6,cex.names=0.6,ylim=c(0,10+max(mycov$V1,mycov$V2)))
legend("topright",legend=c("Coverage Mated","Coverage Virgin"),fill=c("royalblue4","red2"),cex=0.6,pt.cex=0.6)
dev.off()
}



#Generate a text document, reporting several interesting summary statistics that will go in the paper
summary.statistics<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
    outfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/summary_stats.txt")
{
library(data.table)
newres<-fread(infile,data.table=F)
newres$TesterinMated_sampleprop<-newres$TesterinMated_q025<-newres$TesterinMated_q975<-NULL
newres$TesterVirgin_sampleprop<-newres$TesterVirgin_q975<-newres$TesterVirgin_q025<-NULL


newres$line_gene<-apply(cbind(newres$line,newres$FBgn_cat),1,paste,collapse="_")
newres$line_fusion<-apply(cbind(newres$line,newres$fusion_id),1,paste,collapse="_")

cat(paste("Total number of data points (exons by lines):",nrow(newres),"\n"),file=outfile)
byexons<-aggregate(cbind(newres$AI_Mated_decision,newres$AI_Virgin_decision),by=list(newres$fusion_id),FUN=sum)
setnames(byexons,c("V1","V2"),c("AI_M","AI_V"))
byexons$Tot<-byexons$AI_M+byexons$AI_V
cat(paste("Exons:",nrow(byexons),"\n"),file=outfile,append=T)
cat(paste("Genes:",length(unique(newres$symbol_cat)),"\n"),file=outfile,append=T)
cat(paste("Exons significant in at least one line (%):",length(byexons$Tot[byexons$Tot>0]),"(",round(100*length(byexons$Tot[byexons$Tot>0])/nrow(byexons),0),"%)","\n"),file=outfile,append=T)
esbe<-length(byexons$Tot[byexons$AI_M>0&byexons$AI_V>0])
cat(paste("Exons significant in both environments in at least one line (%):",esbe,"(",round(100*esbe/nrow(byexons),0),"%)","\n"),file=outfile,append=T)
onlysig<-newres[newres$AI_Mated_decision>0|newres$AI_Virgin_decision>0|newres$AI_diffinVirginandMated>0,]

fusion.sig.by.cross<-aggregate(newres[,c("AI_Mated_decision","AI_Virgin_decision")],by=list(newres$fusion_id),FUN=sum)
fusion.tot.by.cross<-aggregate(newres[,c("AI_Mated_decision","AI_Virgin_decision")],by=list(newres$fusion_id),FUN=NROW)
sig60<-sum(fusion.sig.by.cross$AI_Mated_decision>=60)+sum(fusion.sig.by.cross$AI_Virgin_decision>=60)
cover60<-sum(fusion.tot.by.cross$AI_Mated_decision>=60)+sum(fusion.tot.by.cross$AI_Virgin_decision>=60)
cat(paste("Exons significant in at least 60 lines:",sig60,"out of a total of",cover60,"exons analyzed in at least 60 lines\n"),file=outfile,append=TRUE)
myav<-mean(c(fusion.sig.by.cross$AI_Mated_decision/fusion.tot.by.cross$AI_Mated_decision,fusion.sig.by.cross$AI_Virgin_decision/fusion.tot.by.cross$AI_Virgin_decision))
cat(paste("Average proportion of crosses with data for which an exon shows AI:",myav,"\n"),file=outfile,append=TRUE)


cat(paste("Number of exons showing different AI in the two environments:",sum(newres$AI_diffinVirginandMated==1),"\n"),file=outfile,append=TRUE)
cat(paste("Number of exons not showing different AI in the two environments:",sum(newres$AI_diffinVirginandMated==0),"\n"),file=outfile,append=TRUE)
cat(paste("Average proportion of exons showing different AI in the two environments:",round(mean(newres$AI_diffinVirginandMated),3),"\n"),file=outfile,append=TRUE)
EAIsigbyline<-aggregate(newres$AI_diffinVirginandMated,by=list(newres$fusion_id),FUN=sum)
setnames(EAIsigbyline,c("fusion_id","n_sig"))
EAItotbyline<-aggregate(newres$AI_diffinVirginandMated,by=list(newres$fusion_id),FUN=length)
setnames(EAItotbyline,c("fusion_id","n_tot"))
EAI<-merge(EAIsigbyline,EAItotbyline,by="fusion_id")
EAI$prop<-round(EAI$n_sig/EAI$n_tot,3)
fus_gene<-data.frame(newres$fusion_id,newres$symbol_cat)
setnames(fus_gene,c("fusion_id","symbol_cat"))
fus_gene<-fus_gene[!duplicated(fus_gene),]
EAI<-merge(EAI,fus_gene,by="fusion_id",all=F)
EAI<-EAI[order(EAI$prop,decreasing=T),]
GAI<-aggregate(EAI[,c("n_sig","n_tot","prop")],by=list(EAI$symbol_cat),FUN=sum)
GAI$prop<-round(GAI$n_sig/GAI$n_tot,3)
GAI<-GAI[order(GAI$prop,decreasing=T),]

browser()
}

#Perform several analysis focused on behavior across environments
summary.MV<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
    min.lines=20,
    outfusion="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/summary.MV.by.fusion.txt",
    outgene="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/summary.MV.by.gene.txt",
    outline="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/summary.MV.by.line.txt",
    onlyvirgin="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/AI.only.virgin.txt",
    onlymated="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/AI.only.mated.txt")
{
library(data.table)
newres<-fread(infile,data.table=F)
newres$TesterinMated_sampleprop<-newres$TesterinMated_q025<-newres$TesterinMated_q975<-NULL
newres$TesterVirgin_sampleprop<-newres$TesterVirgin_q975<-newres$TesterVirgin_q025<-NULL
newres$line_gene<-apply(cbind(newres$line,newres$FBgn_cat),1,paste,collapse="_")
newres$line_fusion<-apply(cbind(newres$line,newres$fusion_id),1,paste,collapse="_")

#Summarize AI results across Environments aggregating by Exons
EAIsigbyline<-aggregate(newres$AI_diffinVirginandMated,by=list(newres$fusion_id),FUN=sum)
setnames(EAIsigbyline,c("fusion_id","n_sig"))
EAItotbyline<-aggregate(newres$AI_diffinVirginandMated,by=list(newres$fusion_id),FUN=length)
setnames(EAItotbyline,c("fusion_id","n_tot"))
EAI<-merge(EAIsigbyline,EAItotbyline,by="fusion_id")
EAI$prop<-round(EAI$n_sig/EAI$n_tot,3)
fus_gene<-data.frame(newres$fusion_id,newres$symbol_cat)
setnames(fus_gene,c("fusion_id","symbol_cat"))
fus_gene<-fus_gene[!duplicated(fus_gene),]
EAI<-merge(EAI,fus_gene,by="fusion_id",all=F)
EAI<-EAI[order(EAI$prop,decreasing=T),]
EAI<-EAI[EAI$n_tot>min.lines,]
top.EAI<-EAI[1:10,]
write.table(top.EAI,outfusion,sep="\t",quote=F,row.names=F)

#Summarize AI results across environments aggregating by Genes
GAIsigbyline<-aggregate(newres$AI_diffinVirginandMated,by=list(newres$symbol_cat),FUN=sum)
setnames(GAIsigbyline,c("symbol_cat","n_sig"))
GAItotbyline<-aggregate(newres$AI_diffinVirginandMated,by=list(newres$symbol_cat),FUN=length)
setnames(GAItotbyline,c("symbol_cat","n_tot"))
GAI<-merge(GAIsigbyline,GAItotbyline,by="symbol_cat")
GAI$prop<-round(GAI$n_sig/GAI$n_tot,3)
GAI<-GAI[order(GAI$prop,decreasing=T),]
GAI<-GAI[GAI$n_tot>min.lines,]
top.GAI<-GAI[1:10,]
write.table(top.GAI,outgene,sep="\t",quote=F,row.names=F)

#Summarize AI results across environments aggregating by Lines
LAIsig<-aggregate(newres$AI_diffinVirginandMated,by=list(newres$line),FUN=sum)
setnames(LAIsig,c("line","n_sig"))
LAItot<-aggregate(newres$AI_diffinVirginandMated,by=list(newres$line),FUN=length)
setnames(LAItot,c("line","n_tot"))
LAI<-merge(LAIsig,LAItot,by="line")
LAI$prop<-round(LAI$n_sig/LAI$n_tot,3)
LAI<-LAI[order(LAI$prop,decreasing=T),]
top.LAI<-LAI[1:10,]
write.table(top.LAI,outline,sep="\t",quote=F,row.names=F)

#Select genes showing AI only in Virgin, and select the ones with the highest proportion of significant genes in Virgin
onlyV<-aggregate(newres[,c("AI_Mated_decision","AI_Virgin_decision","AI_diffinVirginandMated")],by=list(newres$symbol_cat),FUN=sum)
setnames(onlyV,"Group.1","symbol_cat")
onlyVlength<-aggregate(newres$AI_Mated_decision,by=list(newres$symbol_cat),FUN=length)
setnames(onlyVlength,c("symbol_cat","count"))
onlyV<-merge(onlyV,onlyVlength,by="symbol_cat")
onlyV<-onlyV[onlyV$AI_Mated_decision<1&onlyV$AI_Virgin_decision>0,]
onlyV<-onlyV[order(onlyV$AI_diffinVirginandMated,onlyV$AI_Virgin_decision,decreasing=T),]
onlyV<-onlyV[1:5,]
write.table(onlyV,onlyvirgin,quote=F,sep="\t",row.names=F)

#Select genes showing AI only in mated, and select the ones with the highest proportion of significant genes in mated
onlyM<-aggregate(newres[,c("AI_Mated_decision","AI_Virgin_decision","AI_diffinVirginandMated")],by=list(newres$symbol_cat),FUN=sum)
setnames(onlyM,"Group.1","symbol_cat")
onlyMlength<-aggregate(newres$AI_Mated_decision,by=list(newres$symbol_cat),FUN=length)
setnames(onlyMlength,c("symbol_cat","count"))
onlyM<-merge(onlyM,onlyMlength,by="symbol_cat")
onlyM<-onlyM[onlyM$AI_Mated_decision>0&onlyM$AI_Virgin_decision<1,]
onlyM<-onlyM[order(onlyM$AI_diffinVirginandMated,onlyM$AI_Mated_decision,decreasing=T),]
onlyM<-onlyM[1:5,]
write.table(onlyM,onlymated,quote=F,sep="\t",row.names=F)
browser()
}


#Test which lines have an higher than average level of AI
test.excess.AI.in.lines<-function(
                        infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
                        outfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/excess_AI_in_lines.txt",
                        outpdf="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_S_excess_AI_in_lines.pdf")
{
library(data.table)
library(multcompView)
newres<-fread(infile,data.table=F)
newres$TesterinMated_sampleprop<-newres$TesterinMated_q025<-newres$TesterinMated_q975<-NULL
newres$TesterVirgin_sampleprop<-newres$TesterVirgin_q975<-newres$TesterVirgin_q025<-NULL
sig<-aggregate(newres[,c("AI_Mated_decision","AI_Virgin_decision","AI_diffinVirginandMated")],by=list(newres$line),FUN=sum)
setnames(sig,c("line","AI_Mated_decision","AI_Virgin_decision","AI_diffinVirginandMated"))
len<-aggregate(newres[,"AI_diffinVirginandMated"],by=list(newres$line),FUN=NROW)
setnames(len,c("line","count"))
totest<-merge(len,sig,by="line")
totest$fisher_AI_M<-totest$fisher_AI_V<-totest$fisher_diff_AI<-totest$whole_prop_M<-totest$whole_prop_V<-totest$whole_prop_diff<-1
totest$prop_M<-totest$AI_Mated_decision/totest$count
totest$prop_V<-totest$AI_Virgin_decision/totest$count
totest$prop_diff<-totest$AI_diffinVirginandMated/totest$count
for(aaa in 1:nrow(totest))
{
wholetot<-sum(totest$count)-totest$count[aaa]
wholesig_M<-sum(totest$AI_Mated_decision)-totest$AI_Mated_decision[aaa]
wholesig_V<-sum(totest$AI_Virgin_decision)-totest$AI_Virgin_decision[aaa]
wholesig_diff<-sum(totest$AI_diffinVirginandMated)-totest$AI_diffinVirginandMated[aaa]
totest$whole_prop_M[aaa]<-wholesig_M/wholetot
totest$whole_prop_V[aaa]<-wholesig_V/wholetot
totest$whole_prop_diff[aaa]<-wholesig_diff/wholetot
cat(aaa,"\n")
totest$fisher_AI_M[aaa]<-fisher.test(matrix(c(wholetot,wholesig_M,totest$count[aaa],totest$AI_Mated_decision[aaa]),nrow=2))$p.value
totest$fisher_AI_V[aaa]<-fisher.test(matrix(c(wholetot,wholesig_V,totest$count[aaa],totest$AI_Virgin_decision[aaa]),nrow=2))$p.value
totest$fisher_diff_AI[aaa]<-fisher.test(matrix(c(wholetot,wholesig_diff,totest$count[aaa],totest$AI_diffinVirginandMated[aaa]),nrow=2))$p.value
}
write.table(totest,outfile,sep="\t",quote=F,row.names=F)

mated<-cbind(totest$prop_M,rep("M",length(totest$prop_M)))
virgin<-cbind(totest$prop_V,rep("V",length(totest$prop_V)))
mydiff<-cbind(totest$prop_diff,rep("D",length(totest$prop_diff)))

full.data<-data.frame(rbind(mated,virgin,mydiff),stringsAsFactors=F)
setnames(full.data,c("Prop","Group"))
full.data$Prop<-as.numeric(full.data$Prop)

pp<-pairwise.wilcox.test(full.data$Prop, full.data$Group, p.adjust.method = "none", paired = FALSE)
mymat<-tri.to.squ(pp$p.value)
Letters<-multcompLetters(mymat,compare="<=",threshold=0.05,Letters=letters,reversed=T)

pdf(outpdf)
boxplot(list(totest$prop_M,totest$prop_V,totest$prop_diff),ylab="Proportion of exons showing AI",names=c("Mated","Virgin","Difference"),ylim=c(0,0.1+max(totest$prop_M,totest$prop_V,totest$prop_diff)))
stripchart(list(totest$prop_M,totest$prop_V,totest$prop_diff), vertical = TRUE, 
    method = "jitter", add = TRUE, pch = 20, cex=0.8, col = 'black')
text(c(1,2,3),0.05+max(totest$prop_M,totest$prop_V,totest$prop_diff),c(Letters$Letters["M"],Letters$Letters["V"],Letters$Letters["D"]))
dev.off()


}




gene.summary<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
        keggfile="/projects/novabreed/share/marroni/collaborations/Lauren/GO/cat_tokegg.txt",
        outfile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/test_Suppl_Table_genes_AI.txt",
        outtop="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/test_Table_6.txt",
        outtopless="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/test_Table_7.txt")
{
library(data.table)
newres<-fread(infile,data.table=F)
newres$line_gene<-apply(cbind(newres$line,newres$FBgn_cat,newres$fusion_id),1,paste,collapse="_")
setnames(newres,"symbol_cat","gene_name")
myres<-data.frame(aggregate(newres$AI_Mated_decision,by=list(newres$gene_name),FUN=length),
        aggregate(cbind(newres$AI_Mated_decision,newres$AI_Virgin_decision,newres$AI_diffinVirginandMated),by=list(newres$gene_name),FUN=sum))
setnames(myres,c("Gene_name","Count","Gene_name_2","AI_Mated","AI_Virgin","Diff_AI"))
myres<-myres[,c("Gene_name","Count","AI_Mated","AI_Virgin","Diff_AI")]
#myres$fisher_Diff_AI<-myres$fisher_AI_Virgin<-myres$fisher_AI_Mated<-0
message("Performing analysis...")
for(aaa in 1:nrow(myres))
{
#Count number of significant (Y) and non-significant (N) comparisons in the considered gene for Mated (M), Virgin (V) and difference (D)
gene_M_Y<-myres$AI_Mated[aaa]
gene_M_N<-myres$Count[aaa]-myres$AI_Mated[aaa]
gene_V_Y<-myres$AI_Virgin[aaa]
gene_V_N<-myres$Count[aaa]-myres$AI_Virgin[aaa]
gene_D_Y<-myres$Diff_AI[aaa]
gene_D_N<-myres$Count[aaa]-myres$Diff_AI[aaa]


#Count number of significant (Y) and non-significant (N) comparisons in all genes excluded the considered one (remaining) for Mated (M), Virgin (V) and difference (D)
remaining_M_Y<-sum(myres$AI_Mated)-gene_M_Y
remaining_M_N<-sum(myres$Count-myres$AI_Mated)-gene_M_N
remaining_V_Y<-sum(myres$AI_Virgin)-gene_V_Y
remaining_V_N<-sum(myres$Count-myres$AI_Virgin)-gene_V_N
remaining_D_Y<-sum(myres$Diff_AI)-gene_D_Y
remaining_D_N<-sum(myres$Count-myres$Diff_AI)-gene_D_N

#Perform Fisher's exact test to test for excess of AI in each gene
myres$fisher_AI_Mated_g[aaa]<-fisher.test(matrix(c(gene_M_Y,gene_M_N,remaining_M_Y,remaining_M_N),2,2),alternative="greater")$p.value
myres$fisher_AI_Virgin_g[aaa]<-fisher.test(matrix(c(gene_V_Y,gene_V_N,remaining_V_Y,remaining_V_N),2,2),alternative="greater")$p.value
myres$fisher_Diff_AI_g[aaa]<-fisher.test(matrix(c(gene_D_Y,gene_D_N,remaining_D_Y,remaining_D_N),2,2),alternative="greater")$p.value
myres$fisher_AI_Mated_l[aaa]<-fisher.test(matrix(c(gene_M_Y,gene_M_N,remaining_M_Y,remaining_M_N),2,2),alternative="less")$p.value
myres$fisher_AI_Virgin_l[aaa]<-fisher.test(matrix(c(gene_V_Y,gene_V_N,remaining_V_Y,remaining_V_N),2,2),alternative="less")$p.value
myres$fisher_Diff_AI_l[aaa]<-fisher.test(matrix(c(gene_D_Y,gene_D_N,remaining_D_Y,remaining_D_N),2,2),alternative="less")$p.value
}
kegg<-fread(keggfile,data.table=F)
kegg<-kegg[,c("symbol","Kegg_desc")]

#Write table 8, i.e. table reporting 20 genes with the stronger excess of AI between environments according to fisher's exact test 
mytop<-myres[order(myres$fisher_Diff_AI_g),][1:20,]
mytop<-merge(mytop,kegg,by.x="Gene_name",by.y="symbol",all.x=TRUE)
mytop<-mytop[order(mytop$fisher_Diff_AI_g),]
write.table(mytop,outtop,sep="\t",quote=F,row.names=F)
#Write table 9, i.e. table reporting 20 genes with the stronger defect of AI between environments according to fisher's exact test 
mytopless<-myres[order(myres$fisher_Diff_AI_l),][1:20,]
mytopless<-merge(mytopless,kegg,by.x="Gene_name",by.y="symbol",all.x=TRUE)
mytopless<-mytopless[order(mytopless$fisher_Diff_AI_l),]
write.table(mytopless,outtopless,sep="\t",quote=F,row.names=F)
#Write full table 
write.table(myres,outfile,sep="\t",quote=F,row.names=F)
browser()
}

#Same as gene.summary, but works for individual exons (because exons in the same gene are not independent and I want to find a system to classify the genes
# based on the exons having greater -or smaller- environmental variationin AI)
exon.summary<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
        keggfile="/projects/novabreed/share/marroni/collaborations/Lauren/GO/cat_tokegg.txt",
        outfile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Suppl_Table_exons_AI.txt",
        outtop="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Table_6_exons.txt",
        outtopless="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Table_7_exons.txt",
        outtopmeta="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Table_6_exons_meta.txt",
        outtoplessmeta="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Table_7_exons_meta.txt")
{
library(data.table)
newres<-fread(infile,data.table=F)
newres$myexon<-paste(newres$symbol_cat,newres$chrom,newres$start,newres$end)
myres<-data.frame(aggregate(newres$AI_Mated_decision,by=list(newres$myexon),FUN=length),
        aggregate(cbind(newres$AI_Mated_decision,newres$AI_Virgin_decision,newres$AI_diffinVirginandMated),by=list(newres$myexon),FUN=sum))
setnames(myres,c("Exon_name","Count","Gene_name_2","AI_Mated","AI_Virgin","Diff_AI"))
myres<-myres[,c("Exon_name","Count","AI_Mated","AI_Virgin","Diff_AI")]
#myres$fisher_Diff_AI<-myres$fisher_AI_Virgin<-myres$fisher_AI_Mated<-0
message("Performing analysis...")
for(aaa in 1:nrow(myres))
{
#Count number of significant (Y) and non-significant (N) comparisons in the considered gene for Mated (M), Virgin (V) and difference (D)
gene_M_Y<-myres$AI_Mated[aaa]
gene_M_N<-myres$Count[aaa]-myres$AI_Mated[aaa]
gene_V_Y<-myres$AI_Virgin[aaa]
gene_V_N<-myres$Count[aaa]-myres$AI_Virgin[aaa]
gene_D_Y<-myres$Diff_AI[aaa]
gene_D_N<-myres$Count[aaa]-myres$Diff_AI[aaa]


#Count number of significant (Y) and non-significant (N) comparisons in all genes excluded the considered one (remaining) for Mated (M), Virgin (V) and difference (D)
remaining_M_Y<-sum(myres$AI_Mated)-gene_M_Y
remaining_M_N<-sum(myres$Count-myres$AI_Mated)-gene_M_N
remaining_V_Y<-sum(myres$AI_Virgin)-gene_V_Y
remaining_V_N<-sum(myres$Count-myres$AI_Virgin)-gene_V_N
remaining_D_Y<-sum(myres$Diff_AI)-gene_D_Y
remaining_D_N<-sum(myres$Count-myres$Diff_AI)-gene_D_N

#Perform Fisher's exact test to test for excess of AI in each gene
myres$fisher_AI_Mated_g[aaa]<-fisher.test(matrix(c(gene_M_Y,gene_M_N,remaining_M_Y,remaining_M_N),2,2),alternative="greater")$p.value
myres$fisher_AI_Virgin_g[aaa]<-fisher.test(matrix(c(gene_V_Y,gene_V_N,remaining_V_Y,remaining_V_N),2,2),alternative="greater")$p.value
myres$fisher_Diff_AI_g[aaa]<-fisher.test(matrix(c(gene_D_Y,gene_D_N,remaining_D_Y,remaining_D_N),2,2),alternative="greater")$p.value
myres$fisher_AI_Mated_l[aaa]<-fisher.test(matrix(c(gene_M_Y,gene_M_N,remaining_M_Y,remaining_M_N),2,2),alternative="less")$p.value
myres$fisher_AI_Virgin_l[aaa]<-fisher.test(matrix(c(gene_V_Y,gene_V_N,remaining_V_Y,remaining_V_N),2,2),alternative="less")$p.value
myres$fisher_Diff_AI_l[aaa]<-fisher.test(matrix(c(gene_D_Y,gene_D_N,remaining_D_Y,remaining_D_N),2,2),alternative="less")$p.value
}
myres$Gene_name<-unlist(lapply(strsplit(myres$Exon_name," "),"[",1))
myres$chrom<-unlist(lapply(strsplit(myres$Exon_name," "),"[",2))
myres$start<-unlist(lapply(strsplit(myres$Exon_name," "),"[",3))
myres$end<-unlist(lapply(strsplit(myres$Exon_name," "),"[",4))
myres<-myres[,c("chrom","start","end","Gene_name","Count","AI_Mated","AI_Virgin","Diff_AI",
            "fisher_AI_Mated_g","fisher_AI_Virgin_g","fisher_Diff_AI_g","fisher_AI_Mated_l","fisher_AI_Virgin_l","fisher_Diff_AI_l")]


#Write table 8, i.e. table reporting 20 genes with the stronger excess of AI between environments according to fisher's exact test 
mytop<-myres[order(myres$fisher_Diff_AI_g),][1:20,]
write.table(mytop,outtop,sep="\t",quote=F,row.names=F)
#Write table 9, i.e. table reporting 20 genes with the stronger defect of AI between environments according to fisher's exact test 
mytopless<-myres[order(myres$fisher_Diff_AI_l),][1:20,]
write.table(mytopless,outtopless,sep="\t",quote=F,row.names=F)

message("Performing meta-analysis...")
#Perform meta-analysis across exons of each gene
genelist<-unique(myres$Gene_name)
mydat<-data.frame(genelist,rep(NA,length(genelist)),rep(NA,length(genelist)))
setnames(mydat,c("Gene_name","meta_p_greater","meta_p_less"))
for(bbb in 1:length(genelist))
{
sm<-myres[myres$Gene_name==genelist[bbb],]
if(nrow(sm)==1)
{
mydat$meta_p_greater[bbb]<-sm$fisher_Diff_AI_g
mydat$meta_p_less[bbb]<-sm$fisher_Diff_AI_l
next
}
mydat$meta_p_greater[bbb]<-Fisher.meta(sm$fisher_Diff_AI_g)[2]
mydat$meta_p_less[bbb]<-Fisher.meta(sm$fisher_Diff_AI_l)[2]
}
#browser()
#Write table table reporting 20 genes with the stronger excess of AI between environments according to fisher's exact test on exons and fisher meta-analysis on genes 
mytopmeta<-mydat[order(mydat$meta_p_greater),][1:20,]
write.table(mytopmeta,outtopmeta,sep="\t",quote=F,row.names=F)
#Write table table reporting 20 genes with the stronger lack of AI between environments according to fisher's exact test on exons and fisher meta-analysis on genes 
mytoplessmeta<-mydat[order(mydat$meta_p_less),][1:20,]
write.table(mytoplessmeta,outtoplessmeta,sep="\t",quote=F,row.names=F)

#Write full table 
write.table(myres,outfile,sep="\t",quote=F,row.names=F)
}

#Here we plot the proportion of AI detected in exons stratified for number of lines in which the exons have been tested, to test for differences between exons that are tested in a few lines vs exons that are tested in a lot of lines
plot.AI.numbers<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Suppl_Table_exons_AI.txt",
                        outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/proportion_sig.pdf")
{
library(data.table)
library(gplots)
mydata<-fread(infile,data.table=F)
mycounts<-aggregate(mydata[,c("Count","AI_Mated","AI_Virgin","Diff_AI")],by=list(mydata$Count),FUN="sum")
mycounts$Number<-mycounts$Count/mycounts$Group.1
mycounts$Sig<-mycounts$AI_Mated+mycounts$AI_Virgin+mycounts$Diff_AI
mycounts$Prop<-mycounts$Sig/mycounts$Count
totalsig<-sum(mycounts$Sig)
totalcounts<-sum(mycounts$Count)
totalprop<-totalsig/totalcounts
mycounts$chisquare<-mycounts$fisher<-NA
color<-rep("black",nrow(mycounts))
color[mycounts$Prop>totalprop]<-"red"
for(aaa in 1:nrow(mycounts))
{
mycounts$fisher[aaa]<-fisher.test(matrix(c(mycounts$Count[aaa],mycounts$Sig[aaa],totalcounts-mycounts$Count[aaa],totalsig-mycounts$Sig[aaa]),nrow=2))$p.value
mycounts$chisquare[aaa]<-chisq.test(matrix(c(mycounts$Count[aaa],mycounts$Sig[aaa],totalcounts-mycounts$Count[aaa],totalsig-mycounts$Sig[aaa]),nrow=2))$p.value

}
sigfish<-rep("",nrow(mycounts))
sigfish[mycounts$fisher<0.05]<-"*"
# Add the last empty value to avoid recycling of no 1 as the last
sigfish<-c(sigfish,"")
#sigfish[mycounts$fisher<0.05]<-mycounts$Group.1[mycounts$fisher<0.05]
sigchisq<-rep("",nrow(mycounts))
sigchisq[mycounts$chisquare<0.05]<-"*"
sigchisq<-c(sigchisq,"")
textpos<-seq(from=0.5,by=1.2,length.out=nrow(mycounts))
pdf(outgraph,width=15)
pino<-barplot(c(mycounts$Prop,totalprop),names.arg=c(mycounts$Group.1,"Tot"),cex.axis=0.8)
text(x=pino[,1],y=0.02+mycounts$Prop,labels=sigfish,col=color,)
dev.off()
browser()

}


Fisher.meta <- function(p) {
 Xsq <- -2*sum(log(p))
 p.val <- pchisq(Xsq, df = 2*length(p), lower.tail = FALSE)
 return(c(Xsq = Xsq, p.value = p.val))
 }




#Same as gene.summary, but instead of keeping into account exons, it keeps into account only genes.
#E.g. gives statistics on the number of genes that have AI in at least one exon and at least one line, while gene.summary gives, for each gene, the number of exons that have AI in at least one line.
gene.summary.short<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
        keggfile="/projects/novabreed/share/marroni/collaborations/Lauren/GO/cat_tokegg.txt",
        outfile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Suppl_Table_genes_AI_compact.txt",
        outtop="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Table_top_compact_X.txt",
        outtopless="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Table_bottom_compact_Y.txt")
{
library(data.table)
newres<-fread(infile,data.table=F)
newres$line_gene<-apply(cbind(newres$line,newres$symbol_cat),1,paste,collapse="_")
#setnames(newres,"symbol_cat","line_gene")
newres$FBtr_cat<-newres$FBpp_cat<-newres$Exon_Name_cat<-newres$exon_ID_cat<-newres$Exon_Gene_ID_cat<-NULL
myres<-data.frame(aggregate(newres$AI_Mated_decision,by=list(newres$line_gene),FUN=length),
        aggregate(cbind(newres$AI_Mated_decision,newres$AI_Virgin_decision,newres$AI_diffinVirginandMated),by=list(newres$line_gene),FUN=sum))

setnames(myres,c("line_gene","Count","Gene_name_2","AI_Mated","AI_Virgin","Diff_AI"))
myres<-myres[,c("line_gene","Count","AI_Mated","AI_Virgin","Diff_AI")]
myres$gene<-unlist(lapply(strsplit(myres$line_gene,"_"),"[",2))
#To facilitate my way of counting, I transforms all the numbers greater than 0 in 1
myres$Count[myres$Count>0]<-1
myres$AI_Mated[myres$AI_Mated>0]<-1
myres$AI_Virgin[myres$AI_Virgin>0]<-1
myres$Diff_AI[myres$Diff_AI>0]<-1

gres<-aggregate(cbind(myres$Count,myres$AI_Mated,myres$AI_Virgin,myres$Diff_AI),by=list(myres$gene),FUN=sum)
setnames(gres,c("Gene","Count","AI_Mated","AI_Virgin","Diff_AI"))
myres<-gres
#myres$fisher_Diff_AI<-myres$fisher_AI_Virgin<-myres$fisher_AI_Mated<-0
message("Performing analysis...")
for(aaa in 1:nrow(myres))
{
cat(aaa,"\n")

#Count number of significant (Y) and non-significant (N) comparisons in the considered gene for Mated (M), Virgin (V) and difference (D)
gene_M_Y<-myres$AI_Mated[aaa]
gene_M_N<-myres$Count[aaa]-myres$AI_Mated[aaa]
gene_V_Y<-myres$AI_Virgin[aaa]
gene_V_N<-myres$Count[aaa]-myres$AI_Virgin[aaa]
gene_D_Y<-myres$Diff_AI[aaa]
gene_D_N<-myres$Count[aaa]-myres$Diff_AI[aaa]


#Count number of significant (Y) and non-significant (N) comparisons in all genes excluded the considered one (remaining) for Mated (M), Virgin (V) and difference (D)
remaining_M_Y<-sum(myres$AI_Mated)-gene_M_Y
remaining_M_N<-sum(myres$Count-myres$AI_Mated)-gene_M_N
remaining_V_Y<-sum(myres$AI_Virgin)-gene_V_Y
remaining_V_N<-sum(myres$Count-myres$AI_Virgin)-gene_V_N
remaining_D_Y<-sum(myres$Diff_AI)-gene_D_Y
remaining_D_N<-sum(myres$Count-myres$Diff_AI)-gene_D_N

#Perform Fisher's exact test to test for excess of AI in each gene
myres$fisher_AI_Mated_g[aaa]<-fisher.test(matrix(c(gene_M_Y,gene_M_N,remaining_M_Y,remaining_M_N),2,2),alternative="greater")$p.value
myres$fisher_AI_Virgin_g[aaa]<-fisher.test(matrix(c(gene_V_Y,gene_V_N,remaining_V_Y,remaining_V_N),2,2),alternative="greater")$p.value
myres$fisher_Diff_AI_g[aaa]<-fisher.test(matrix(c(gene_D_Y,gene_D_N,remaining_D_Y,remaining_D_N),2,2),alternative="greater")$p.value
myres$fisher_AI_Mated_l[aaa]<-fisher.test(matrix(c(gene_M_Y,gene_M_N,remaining_M_Y,remaining_M_N),2,2),alternative="less")$p.value
myres$fisher_AI_Virgin_l[aaa]<-fisher.test(matrix(c(gene_V_Y,gene_V_N,remaining_V_Y,remaining_V_N),2,2),alternative="less")$p.value
myres$fisher_Diff_AI_l[aaa]<-fisher.test(matrix(c(gene_D_Y,gene_D_N,remaining_D_Y,remaining_D_N),2,2),alternative="less")$p.value
}
kegg<-fread(keggfile,data.table=F)
kegg<-kegg[,c("symbol","Kegg_desc")]
browser()



#Write table 8, i.e. table reporting 20 genes with the stronger excess of AI between environments according to fisher's exact test 
mytop<-myres[order(myres$fisher_Diff_AI_g),][1:20,]
mytop<-merge(mytop,kegg,by.x="Gene",by.y="symbol",all.x=TRUE)
mytop<-mytop[order(mytop$fisher_Diff_AI_g),]
write.table(mytop,outtop,sep="\t",quote=F,row.names=F)
#Write table 9, i.e. table reporting 20 genes with the stronger defect of AI between environments according to fisher's exact test 
mytopless<-myres[order(myres$fisher_Diff_AI_l),][1:20,]
mytopless<-merge(mytopless,kegg,by.x="Gene",by.y="symbol",all.x=TRUE)
mytopless<-mytopless[order(mytopless$fisher_Diff_AI_l),]
write.table(mytopless,outtopless,sep="\t",quote=F,row.names=F)
#Write full table 
write.table(myres,outfile,sep="\t",quote=F,row.names=F)
}




#it=inconsistence threshold, i.e. the proportion of fusions with inconsistent direction of AI in Mated and Virgin
#   above which the whole gene will be marked as "inconsistent" 
top.ext<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
	outfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/genes_AI_diff_VM.txt",
	outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/genes_AI_diff_VM.pdf",
	it=0.3)
{
library(data.table)
library(grid)
library(gridExtra)
library(gtable)
newres<-fread(infile,data.table=F)

newres$line_gene<-apply(cbind(newres$line,newres$FBgn_cat,newres$fusion_id),1,paste,collapse="_")
#Only keep essential columns
newres<-newres[,!names(newres)%in%c("M_num_reps","V_num_reps","flag_100sim","FBtr","FBtrs_per_exon","FBpp",
									"TesterinMated_q025","TesterinMated_q975","TesterVirgin_q025","TesterVirgin_q975",
									"Exon_Name_cat",
									"FBpp_cat","FBtr_cat","exon_ID_cat")]

#List of genes showing major differences between Mated and Virgin
#pp<-aggregate(newres$AI_diffinVirginandMated,by=list(newres$FBgn),FUN="sum")
setnames(newres,"symbol_cat","gene_name")
pp<-data.frame(unique(newres$gene_name))
names(pp)<-"Gene"
pp$tot<-0
pp$pos<-0
pp$AI_Mgreater<-0
pp$AI_Vgreater<-0
for(aaa in 1:nrow(pp))
{
	pp$tot[aaa]<-sum(newres$gene_name==pp$Gene[aaa])
	pp$pos[aaa]<-sum(newres$gene_name==pp$Gene[aaa]&newres$AI_diffinVirginandMated>0)
}

#fisher
totpos<-sum(pp$pos)
totneg<-sum(pp$tot)-sum(pp$pos)
pp$neg<-pp$tot-pp$pos

pp$fisher<-0

for(aaa in 1:nrow(pp))
{
pp$fisher[aaa]<-fisher.test(matrix(c(pp$pos[aaa],pp$neg[aaa],totpos,totneg),2,2),alternative="greater")$p.value
} 

mytab<-pp[order(pp$fisher),][1:20,]
options(digits=3)
mytab<-mytab[,c("Gene","tot","pos","fisher")]
names(mytab)<-c("Gene","total","pos","fisher")
uff<-newres[,c("gene_name","chrom","start","end")][!duplicated(newres[,c("gene_name","chrom")]),]
names(uff)[1]<-"Gene"
newtab<-merge(mytab,uff,by="Gene",all=F,sort=F)
row.names(newtab)<- newtab[,"Gene"]
newtab<-newtab[,c("pos","total","chrom","start","end","fisher")]
colnames(newtab)<- names(newtab)

newres$MgreaterV<-newres$VgreaterM<-0
newres$MgreaterV[abs(newres$TesterinMated_mean-0.5)>abs(newres$TesterVirgin_mean-0.5)&newres$AI_diffinVirginandMated>0]<-1
newres$VgreaterM[abs(newres$TesterinMated_mean-0.5)<=abs(newres$TesterVirgin_mean-0.5)&newres$AI_diffinVirginandMated>0]<-1

#inconsist will measure how many exons in one gene have significant AI in different directions (in the same line). i.e. how many inconsistent signal we record 
#info will measure how many times in the lines we have more than two exons in one gene with significant AI in Virgin or Mated in each line. 

newtab$inconsist<-newtab$info<-0
for (bbb in 1:nrow(newtab))
{
sm<-newres[newres$gene_name==mytab$Gene[bbb],]
pp<-aggregate(sm[,c("MgreaterV","VgreaterM")],by=list(sm$line),FUN=sum)
pp$tot<-pp$MgreaterV+pp$VgreaterM
pp$prop<-pp$MgreaterV/(pp$tot)
pp$inconsist<-0
pp$inconsist[pp$prop>it&pp$prop<1-it]<-1
newtab$info[bbb]<-length(pp$tot[pp$tot>=2])
newtab$inconsist[bbb]<-sum(pp$inconsist)
}
browser()
write.table(newtab,outfile,quote=F,sep=",")

pdf(outgraph)
t1 <- tableGrob(newtab)
padding <- unit(15,"mm")
title <- textGrob("AI differ Mated Virgin extended",gp=gpar(fontsize=15))
table <- gtable_add_rows(t1, heights = grobHeight(title) + padding, pos = 0)
table <- gtable_add_grob(table, title, 1, 1, 1, ncol(table))
grid.newpage()
grid.draw(table)
dev.off()
}


AI.across.env<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
	outfile1="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Suppl_Table_genes_AI_both_environments.txt",
	outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/genes_AI_diff_VM.pdf",
    genes.to.remove="dp",min.test=6)
{
library(data.table)
library(grid)
library(gridExtra)
library(gtable)
newres<-fread(infile,data.table=F)

newres$line_gene<-apply(cbind(newres$line,newres$FBgn_cat,newres$fusion_id),1,paste,collapse="_")
#Only keep essential columns
newres<-newres[,!names(newres)%in%c("M_num_reps","V_num_reps","flag_100sim","FBtr","FBtrs_per_exon","FBpp",
									"TesterinMated_q025","TesterinMated_q975","TesterVirgin_q025","TesterVirgin_q975",
									"Exon_Name_cat",
									"FBpp_cat","FBtr_cat","exon_ID_cat")]
#List of genes showing major differences between Mated and Virgin
#pp<-aggregate(newres$AI_diffinVirginandMated,by=list(newres$FBgn),FUN="sum")
setnames(newres,"symbol_cat","gene_name")
#Remove some selected genes, for which exonic structure was wrong (e.g. for dp we had 71 exons which is strange, compared to the 10 exons shown on flybase)
newres<-newres[!newres$gene_name%in%genes.to.remove,]
#Count the number of tests performed for each gene (in all exons in all lines)
mylength<-aggregate(newres$AI_Mated_decision,by=list(newres$gene_name),FUN=length)
setnames(mylength,c("gene_name","count"))
#Count number of exons of which each gene is composed
myex<-aggregate(newres$fusion_id[!duplicated(newres$fusion_id)],by=list(newres$gene_name[!duplicated(newres$fusion_id)]),FUN=length)
setnames(myex,c("gene_name","n_exons"))
#Count how often a gene showed AI (in all exons in all lines)  
mysig<-aggregate(cbind(newres$AI_Mated_decision,newres$AI_Virgin_decision,
                    newres$AI_diffinVirginandMated),by=list(newres$gene_name),FUN=sum)
setnames(mysig,c("gene_name","AI_Mated_decision","AI_Virgin_decision","AI_diffinVirginandMated"))
mycount<-aggregate(cbind(newres$TesterinMated_AI_Bayes_pval,
                    newres$TesterVirgin_AI_Bayes_pval,newres$independence_Bayesian_pvalue),by=list(newres$gene_name),FUN=median)
setnames(mycount,c("gene_name","TesterinMated_AI_Bayes_pval","TesterVirgin_AI_Bayes_pval","independence_Bayesian_pvalue"))
myone<-merge(mylength,mysig,by="gene_name")
mytwo<-merge(myone,mycount,by="gene_name")
myfinal<-merge(myex,mytwo,by="gene_name")
myfinal$AI_either<-round(0.5*(myfinal$AI_Mated_decision+myfinal$AI_Virgin_decision)/myfinal$count,3)
#Remove instances in which less than min.test tests were performed.
myfinal<-myfinal[myfinal$count>=min.test,]
myfinal<-myfinal[order(myfinal$AI_either,decreasing=TRUE),]
myfinal<-myfinal[,c("gene_name","count","AI_Mated_decision","AI_Virgin_decision","AI_either")]

outab<-myfinal[1:10,]
write.table(outab,outfile1,quote=F,row.names=F,sep="\t")
browser()
}




#it=inconsistence threshold, i.e. the proportion of fusions with inconsistent direction of AI in Mated and Virgin
#   above which the whole gene will be marked as "inconsistent" 
all.old<-function	(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/merged_data.csv",
	outfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/genes_AI_diff_VM.txt",
	outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/genes_AI_diff_VM.pdf",
	it=0.3)
{
library(data.table)
library(grid)
library(gridExtra)
library(gtable)
newres<-fread(infile,data.table=F)
newres$line_gene<-apply(cbind(newres$line,newres$FBgn,newres$fusion_id),1,paste,collapse="_")
#Only keep essential columns
newres<-newres[,!names(newres)%in%c("flag_less500","flag_less10","flag_100sim","FBtr","FBtrs_per_exon","FBpp",
									"TesterinMated_q025","TesterinMated_q975","TesterVirgin_q025","TesterVirgin_q975",
									"FBpp_cat","FBtr_cat","exon_ID_cat")]


#newres<-newres[1:10000,]


#List of genes showing major differences between Mated and Virgin
#pp<-aggregate(newres$AI_diffinVirginandMated,by=list(newres$FBgn),FUN="sum")
pp<-data.frame(unique(newres$gene_name))
names(pp)<-"Gene"
pp$tot<-0
pp$pos<-0
pp$AI_Mgreater<-0
pp$AI_Vgreater<-0
for(aaa in 1:nrow(pp))
{
	pp$tot[aaa]<-sum(newres$gene_name==pp$Gene[aaa])
	pp$pos[aaa]<-sum(newres$gene_name==pp$Gene[aaa]&newres$AI_diffinVirginandMated>0)
}

#fisher
totpos<-sum(pp$pos)
totneg<-sum(pp$tot)-sum(pp$pos)
pp$neg<-pp$tot-pp$pos

pp$fisher<-0

for(aaa in 1:nrow(pp))
{
pp$fisher[aaa]<-fisher.test(matrix(c(pp$pos[aaa],pp$neg[aaa],totpos,totneg),2,2),alternative="greater")$p.value
} 

mytab<-pp[order(pp$fisher),][1:20,]
options(digits=3)
mytab<-mytab[,c("Gene","tot","pos","fisher")]
names(mytab)<-c("Gene","total","pos","fisher")
uff<-newres[,c("gene_name","chrom","start","end")][!duplicated(newres[,c("gene_name","chrom")]),]
names(uff)[1]<-"Gene"
newtab<-merge(mytab,uff,by="Gene",all=F,sort=F)
row.names(newtab)<- newtab[,"Gene"]
newtab<-newtab[,c("pos","total","chrom","start","end","fisher")]
colnames(newtab)<- names(newtab)

newres$MgreaterV<-newres$VgreaterM<-0
newres$MgreaterV[abs(newres$TesterinMated_mean-0.5)>abs(newres$TesterVirgin_mean-0.5)]<-1
newres$VgreaterM[abs(newres$TesterinMated_mean-0.5)<=abs(newres$TesterVirgin_mean-0.5)]<-1

newtab$info<-newtab$inconsistent<-0
for (bbb in 1:nrow(newtab))
{
sm<-newres[newres$gene_name==mytab$Gene[bbb],]
pp<-aggregate(sm[,c("MgreaterV","VgreaterM")],by=list(sm$line),FUN=sum)
pp$tot<-pp$MgreaterV+pp$VgreaterM
pp$prop<-pp$MgreaterV/(pp$tot)
pp$inconsist<-0
pp$inconsist[pp$prop>it&pp$prop<it]<-1
newtab$info[bbb]<-length(pp$tot[pp$tot>=2])
newtab$inconsist[bbb]<-sum(pp$inconsist)
}

write.table(newtab,outfile,quote=F,sep=",",row.names=F)

pdf(outgraph)
t1 <- tableGrob(newtab)
padding <- unit(15,"mm")
title <- textGrob("AI differ Mated Virgin extended",gp=gpar(fontsize=15))
table <- gtable_add_rows(t1, heights = grobHeight(title) + padding, pos = 0)
table <- gtable_add_grob(table, title, 1, 1, 1, ncol(table))
grid.newpage()
grid.draw(table)
dev.off()
}


compare.tableS4<-function(
	files4="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/Supplemental_Table4_lmm2.csv",
	infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/merged_data.csv",
	outfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables_old_vs_new/merged_TableS4.csv",
	outpdf="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots_old_vs_new/merged_TableS4_plot.pdf")
{
library(data.table)

tableS4<-fread(files4,data.table=F)
#Remove the Prosalp gene which has 1 in both categories
tableS4<-tableS4[tableS4$significant_in_mated_only+tableS4$significant_in_virgin_only<2,]
myres<-fread(infile,data.table=F)
tableS4$independence_Bayesian_pvalue<-tableS4$AI_diffinVirginandMated<-tableS4$MV_concold<-tableS4$MV_discold<-NA
tableS4$MV_concnew<-tableS4$MV_discnew<-tableS4$theta_hat_AI_DIFF<-NA
tableS4$assigned_M<-tableS4$assigned_V<-tableS4$assigned_tot<-tableS4$difference<-tableS4$difference_var<-NA
tableS4$TesterinMated_mean<-tableS4$TesterVirgin_mean<-tableS4$TesterinMated_var<-tableS4$TesterVirgin_var<-NA
cat("Total number of genes in which AI differs between Virgin and Mated:",length(unique(myres$gene_name[myres$AI_diffinVirginandMated>0])),"\n")
cat("Total number of data points in which AI differs between Virgin and Mated:",sum(myres$AI_diffinVirginandMated>0),"\n")
for(aaa in 1:nrow(tableS4))
{
small<-myres[grep(tableS4$gene_name[aaa],myres$gene_name),]
if(nrow(small)==0) next
tableS4$independence_Bayesian_pvalue[aaa]<-min(small$independence_Bayesian_pvalue,na.rm=T)
tableS4$AI_diffinVirginandMated[aaa]<-max(small$AI_diffinVirginandMated,na.rm=T)
tableS4$MV_discold[aaa]<-sum(small$AI_intersection_test_M!=small$AI_intersection_test_V)
tableS4$MV_concold[aaa]<-sum(small$AI_intersection_test_M>0&small$AI_intersection_test_V>0)
tableS4$MV_discnew[aaa]<-sum(small$AI_Mated_decision!=small$AI_Virgin_decision)
tableS4$MV_concnew[aaa]<-sum(small$AI_Mated_decision>0&small$AI_Virgin_decision>0)
tableS4$assigned_M[aaa]<-mean(small$counts_M_tester+small$counts_M_line)
tableS4$assigned_V[aaa]<-mean(small$counts_V_tester+small$counts_V_line)
tableS4$assigned_tot[aaa]<-mean(small$counts_M_tester+small$counts_M_line+small$counts_V_tester+small$counts_V_line)

tableS4$TesterinMated_mean[aaa]<-mean(small$TesterinMated_mean)
tableS4$TesterVirgin_mean[aaa]<-mean(small$TesterVirgin_mean)
tableS4$difference[aaa]<-mean(abs(small$TesterVirgin_mean-small$TesterinMated_mean))
tableS4$theta_hat_AI_DIFF[aaa]<-mean(abs(small$theta_hat_AI_V-small$theta_hat_AI_M))
tableS4$TesterinMated_var[aaa]<-sd(small$TesterinMated_mean)^2
tableS4$TesterVirgin_var[aaa]<-sd(small$TesterVirgin_mean)^2



}
tableS4<-na.omit(tableS4)
tableS4<-tableS4[tableS4$MV_discold>0,]
write.table(tableS4,outfile,sep=",",row.names=F,quote=F)
pdf(outpdf)
boxplot(log(tableS4$assigned_M,10)~tableS4$AI_diffinVirginandMated,col="cadetblue3",main=expression("Log"[10]*" Reads assigned to tester or line in Mated"))
boxplot(log(tableS4$assigned_V,10)~tableS4$AI_diffinVirginandMated,col="cadetblue3",main=expression("Log"[10]*" Reads assigned to tester or line in Virgin"))
boxplot(log(tableS4$assigned_tot,10)~tableS4$AI_diffinVirginandMated,col="cadetblue3",main=expression("Log"[10]*" Reads assigned to tester or line in Both"))
boxplot(tableS4$TesterinMated_mean~tableS4$AI_diffinVirginandMated,col="cadetblue3",main=expression(paste(theta," Mated")))
boxplot(tableS4$TesterVirgin_mean~tableS4$AI_diffinVirginandMated,col="cadetblue3",main=expression(paste(theta," Virgin")))
boxplot((tableS4$TesterinMated_mean-tableS4$TesterVirgin_mean)~tableS4$AI_diffinVirginandMated,col="cadetblue3",main=expression(paste(theta," Difference")))
boxplot(tableS4$TesterinMated_var~tableS4$AI_diffinVirginandMated,col="cadetblue3",main=expression(paste(theta," Variance in Mated")))
boxplot(tableS4$TesterVirgin_var~tableS4$AI_diffinVirginandMated,col="cadetblue3",main=expression(paste(theta," Variance in Virgin")))
boxplot(tableS4$independence_Bayesian_pvalue~tableS4$AI_diffinVirginandMated,col="cadetblue3",main="p-value")
boxplot(tableS4$difference~tableS4$AI_diffinVirginandMated,col="cadetblue3",main=expression(paste(theta," Difference")))
boxplot(tableS4$theta_hat_AI_DIFF~tableS4$AI_diffinVirginandMated,col="cadetblue3",main=expression(paste(theta," Orig Difference")))

boxplot(tableS4$theta_hat_AI_DIFF[tableS4$AI_diffinVirginandMated<1],tableS4$theta_hat_AI_DIFF[tableS4$AI_diffinVirginandMated>0],tableS4$difference[tableS4$AI_diffinVirginandMated<1],tableS4$difference[tableS4$AI_diffinVirginandMated>0],col=(c("cadetblue1","cadetblue1","cadetblue3","cadetblue3")),main=expression(paste(theta," Difference in genes that Orig model says have AI diff in M vs V")), names=c("0","1","0","1")) 
legend("topleft",legend=c("Orig model","Extended model"),fill=c("cadetblue1","cadetblue3"))
dev.off()

browser()
aggregate(tableS4$TesterinMated_mean,by=list(tableS4$AI_diffinVirginandMated),FUN=summary)
aggregate(tableS4$assigned_tot,by=list(tableS4$AI_diffinVirginandMated),FUN=summary)
}

investigate.single<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
linename="r149")
{
library(data.table)
# Very preliminary function to empirically investigate behaviour of lines
pp<-fread(infile,data.table=F)
pp149<-pp[pp$line==linename,]
pp149[1:3,]
summary(pp149$counts_M_both)
summary(pp$counts_M_both)
summary(pp149$counts_M_tester)
summary(pp$counts_M_tester)
summary(pp149$counts_M_tester+pp149$counts_M_line)
summary(pp$counts_M_tester+pp$counts_M_line)
summary(pp149$counts_V_tester+pp149$counts_V_line)
summary(pp$counts_V_tester+pp$counts_V_line)

summary(pp149$counts_V_tester/(pp149$counts_V_line+pp149$counts_V_tester))
summary(pp149$counts_M_tester/(pp149$counts_M_line+pp149$counts_M_tester))
summary(pp$counts_V_tester/(pp$counts_V_line+pp$counts_V_tester))
summary(pp$counts_M_tester/(pp$counts_M_line+pp$counts_M_tester))
table(pp149$chrom[pp149$AI_diffinVirginandMated==1])

pp149gene<-aggregate(cbind(pp149$AI_diffinVirginandMated),by=list(pp149$FBgn_cat),FUN=sum)
setnames(pp149gene,c("FBgn_cat","AI_diffinVirginandMated"))
pp149gene<-merge(pp149[,c("FBgn_cat","chrom")],pp149gene,by="FBgn_cat",all=F)
pp149[pp149$symbol_cat=="Cyp6g1",]
browser()
}


inspect.vcf<-function(indir="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/SNP",chr="2R",start=8073897,stop=8074407)
{
library(data.table)
setwd(indir)
filelist<-dir(pattern="\\.vcf")
for(aaa in 1:length(filelist))
{
mysnp<-fread(filelist[aaa],data.table=F)
myregion<-mysnp[mysnp$"#CHROM"==chr&mysnp$POS>=start&mysnp$POS<=stop,]
myregion$file<-rep(filelist[aaa],nrow(myregion))
ifelse(exists("fullregion"),fullregion<-rbind(fullregion,myregion),fullregion<-myregion)
}
fullregion$geno<-unlist(lapply(strsplit(fullregion$GENOTYPE,":"),"[",6))
fullregion$het.l<-unlist(lapply(strsplit(fullregion$geno,","),"[",2))
browser()



}



all.old.fusion<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/extend_library8.clean.csv",
	outtable="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/fusion_AI_diff_VM.txt",
	outpdf="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/fusion_AI_diff_VM.pdf")
{
library(data.table)
library(grid)
library(gridExtra)
library(gtable)
newres<-fread(infile,data.table=F)
newres$line_gene<-apply(cbind(newres$line,newres$FBgn,newres$fusion_id),1,paste,collapse="_")
#Only keep essential columns
newres<-newres[,!names(newres)%in%c("flag_less500","flag_less10","flag_100sim","FBtr","FBtrs_per_exon","FBpp",
									"TesterinMated_q025","TesterinMated_q975","TesterVirgin_q025","TesterVirgin_q975")]


#List of genes showing major differences between Mated and Virgin
#pp<-aggregate(newres$AI_diffinVirginandMated,by=list(newres$FBgn),FUN="sum")

pp<-data.frame(unique(newres$fusion_id))
names(pp)<-"fusion_id"
pp$tot<-0
pp$pos<-0
pp$AI_Mgreater<-0
pp$AI_Vgreater<-0
for(aaa in 1:nrow(pp))
{
pp$tot[aaa]<-sum(newres$fusion_id==pp$fusion_id[aaa])
pp$pos[aaa]<-sum(newres$fusion_id==pp$fusion_id[aaa]&newres$AI_diffinVirginandMated>0)
pp$AI_Mgreater[aaa]<-sum(newres$fusion_id==pp$fusion_id[aaa]&abs(newres$TesterinMated_mean-0.5)>abs(newres$TesterVirgin_mean-0.5))
pp$AI_Vgreater[aaa]<-sum(newres$fusion_id==pp$fusion_id[aaa]&abs(newres$TesterinMated_mean-0.5)<=abs(newres$TesterVirgin_mean-0.5))
}
cat("Made all my counts\n")


##chisquare mmm
prop.pos<-sum(pp$pos)/sum(pp$tot)
pp$chisq<-unlist(lapply(apply(cbind(pp$pos,pp$tot),1,chisq.test,p=c(prop.pos,1-prop.pos)),"[","p.value"))

#fisher
totpos<-sum(pp$pos)
totneg<-sum(pp$tot)-sum(pp$pos)
pp$neg<-pp$tot-pp$pos

pp$fisher<-0

for(aaa in 1:nrow(pp))
{
pp$fisher[aaa]<-fisher.test(matrix(c(pp$pos[aaa],pp$neg[aaa],totpos,totneg),2,2),alternative="greater")$p.value
} 
cat("Done Fisher\n")

#Tried a weighted proportion stuff. Not sure it's ok!
pp$weighted_prop<-pp$pos^2/pp$tot
mytab<-pp[order(pp$fisher),][1:20,]
options(digits=3)
mytab<-mytab[,c("fusion_id","tot","pos","fisher","AI_Mgreater","AI_Vgreater")]
names(mytab)<-c("fusion_id","total","positive","fisher","AI_Mgreater","AI_Vgreater")
uff<-newres[,c("fusion_id","FBgn_cat","chrom","start","end")][!duplicated(newres[,c("fusion_id","chrom")]),]
newtab<-merge(mytab,uff,by="fusion_id",all=F,sort=F)
row.names(newtab)<- newtab[,"fusion_id"]
newtab<-newtab[,c("FBgn_cat","positive","total","chrom","start","end","fisher","AI_Mgreater","AI_Vgreater")]
colnames(newtab)<- names(newtab)
write.table(newtab,outtable,quote=F,sep=",",row.names=F)

pdf(outpdf)
t1 <- tableGrob(newtab)
padding <- unit(15,"mm")
title <- textGrob("AI differ Mated Virgin extended",gp=gpar(fontsize=15))
table <- gtable_add_rows(t1, heights = grobHeight(title) + padding, pos = 0)
table <- gtable_add_grob(table, title, 1, 1, 1, ncol(table))
grid.newpage()
grid.draw(table)
dev.off()
browser()
}


#Input (pseudo)triangular matrix with row and column names 
tri.to.squ<-function(x)
{
rn<-row.names(x)
cn<-colnames(x)
an<-unique(c(cn,rn))
myval<-x[!is.na(x)]
mymat<-matrix(1,nrow=length(an),ncol=length(an),dimnames=list(an,an))
for(ext in 1:length(cn))
{
    for(int in 1:length(rn))
    {
    if(is.na(x[row.names(x)==rn[int],colnames(x)==cn[ext]])) next
    mymat[row.names(mymat)==rn[int],colnames(mymat)==cn[ext]]<-x[row.names(x)==rn[int],colnames(x)==cn[ext]]
    mymat[row.names(mymat)==cn[ext],colnames(mymat)==rn[int]]<-x[row.names(x)==rn[int],colnames(x)==cn[ext]]
    }

}
return(mymat)
}
