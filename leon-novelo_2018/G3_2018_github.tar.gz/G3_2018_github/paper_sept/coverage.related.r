#lowdef: upper limit of low coverage
#middef: upper limit of medium coverage
cov.ase<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/merged_data.csv",
	lowdef=1,meddef=3,
	tablestrat="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables_old_vs_new/strat_by_cov.pdf")
{
library(data.table)
library(grid)
library(gridExtra)
library(gtable)
merged<-fread(infile,data.table=F)
merged$length<-abs(merged$start-merged$end)
merged$counts_M_total<-merged$counts_M_tester+merged$counts_M_line+merged$counts_M_both
merged$counts_V_total<-merged$counts_V_tester+merged$counts_V_line+merged$counts_V_both
merged$M_APN<-merged$counts_M_total/merged$length
merged$V_APN<-merged$counts_V_total/merged$length
merged$covstrata_V<-merged$covstrata_M<-"1-Low"
merged$covstrata_V[merged$V_APN>=1&merged$V_APN<3]<-"2-Medium"
merged$covstrata_V[merged$V_APN>=3]<-"3-High"
merged$covstrata_M[merged$M_APN>=1&merged$M_APN<3]<-"2-Medium"
merged$covstrata_M[merged$M_APN>=3]<-"3-High"
mt1<-aggregate(cbind(merged$TesterVirgin_mean,merged$theta_hat_AI_V),by=list(merged$covstrata_V),FUN=mean)
mt2<-aggregate(cbind(merged$TesterinMated_mean,merged$theta_hat_AI_M),by=list(merged$covstrata_M),FUN=mean)

tt<-aggregate(cbind((merged$TesterVirgin_mean+merged$TesterinMated_mean)/2,(merged$theta_hat_AI_V+merged$theta_hat_AI_M)/2)~merged$covstrata_V+merged$covstrata_M,FUN=mean)
ltt<-aggregate(cbind((merged$TesterVirgin_mean+merged$TesterinMated_mean)/2,(merged$theta_hat_AI_V+merged$theta_hat_AI_M)/2)~merged$covstrata_V+merged$covstrata_M,FUN=length)


#tt<-aggregate(cbind(merged$TesterVirgin_mean,merged$TesterinMated_mean,merged$theta_hat_AI_V,merged$theta_hat_AI_M)~merged$covstrata_V+merged$covstrata_M,FUN=mean)


tt$V3<-paste(round(tt$V1,3),"-",round(tt$V2,3)," (n= ",ltt$V1,")",sep="")
#mytt.ext<-data.frame(matrix(tt$V1,ncol=3,nrow=3),row.names=unique(tt[,2]))
#names(mytt.ext)<-unique(tt[,2])
#mytt.base<-data.frame(matrix(tt$V2,ncol=3,nrow=3),row.names=unique(tt[,2]))
#names(mytt.base)<-unique(tt[,2])
#mytt.base<-round(mytt.base,3)
#mytt.ext<-round(mytt.ext,3)
mytt.bomb<-data.frame(matrix(tt$V3,ncol=3,nrow=3),row.names=unique(tt[,2]))
names(mytt.bomb)<-paste(c("Low","Medium","High"),"M",sep="_")
row.names(mytt.bomb)<-paste(c("Low","Medium","High"),"V",sep="_")


pdf(tablestrat)
t1 <- tableGrob(mytt.bomb)
padding <- unit(15,"mm")
title <- textGrob("Theta (Ext-Base)",gp=gpar(fontsize=15))
table <- gtable_add_rows(t1, heights = grobHeight(title) + padding, pos = 0)
table <- gtable_add_grob(table, title, 1, 1, 1, ncol(table))
grid.newpage()
grid.draw(table)
dev.off()

browser()
}
