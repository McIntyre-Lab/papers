# Stouffer.meta <- function(p, w) { # p is a vector of p-values
  # if (missing(w)) {
    # w <- rep(1, length(p))/length(p)
  # } else {
    # if (length(w) != length(p))
      # stop("Length of p and w must equal!")
  # }
  # Zi <- qnorm(1-p) 
  # Z  <- sum(w*Zi)/sqrt(sum(w^2))
  # p.val <- 1-pnorm(Z)
  # return(c(Z = Z, p.value = p.val))
# }

# Fisher.meta <- function(p) {
  # Xsq <- -2*sum(log(p))
  # p.val <- pchisq(Xsq, df = 2*length(p), lower.tail = FALSE)
  # return(c(Xsq = Xsq, p.value = p.val))
# }

signed.Fisher.meta<- function(p,sign) {
  p1<-p[sign>=0]
  p2<-p[sign<0]
  Xsq1<- -2*sum(log(p1))
  Xsq2 <- -2*sum(log(p2))
  Xsq<-abs(Xsq1-Xsq2)
  p.val <- pchisq(Xsq, df = 2*length(p), lower.tail = FALSE)
  return(c(Xsq = Xsq, p.value = p.val))
}


#Our approacvh is the same used here to take direction of effects into account: http://metainter.meb.uni-bonn.de/METAINTER_Manual.html#Abschnitt2_3

signed.Stouffer.meta <- function(p, w, sign) { # p is a vector of p-values
  if (missing(w)) {
    w <- rep(1, length(p))/length(p)
  } else {
    if (length(w) != length(p))
      stop("Length of p and w must equal!")
  }
  if(length(p)==1) Zi<-qnorm(p,lower.tail=F)
  if(length(p)>1)
  {
  Zi<-qnorm(p/2,lower.tail=FALSE) 
  Zi[sign<0]<-(-Zi[sign<0])
  }
  Z  <- sum(w*Zi)/sqrt(sum(w^2))
  p.val <- 1-pnorm(abs(Z))
  return(c(Z = Z, p.value = p.val))
}
