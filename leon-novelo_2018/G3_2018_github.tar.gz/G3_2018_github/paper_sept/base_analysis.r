#Import sas data, since I don't have SAS
library(sas7bdat)
pp<-read.sas7bdat("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/ase_extended/sas_data/extend_library8_18jan2016.sas7bdat")
#Since importing takes long, better save the data
write.csv(pp,"/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/extend_library8_18jan2016.csv",quote=F,row.names=F)
#Try reloading the data.frame, just to see how long it takes
library(data.table)
yy<-fread("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/extend_library8_18jan2016.csv",data.table=F)

mylogratio<-log2(yy$counts_M_tester/yy$counts_M_line)
mylogratio[mylogratio>10]<-10
mylogratio[mylogratio<(-10)]<-(-10)

pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/extend_library8_18jan2016_hist.pdf")
hist(mylogratio,breaks=100,main="Log2 ratio counts M_tester/M_line")

hist(yy$qsim_tester,breaks=50)
hist(yy$chisqpvalue,breaks=50)
hist(yy$independence_Bayesian_pvalue,breaks=50)
hist(yy$prob_alphagreater1greaterdelta,breaks=50)
hist(yy$prob_deltagreater1greateralpha,breaks=50)

hist(yy$TesterinMated_sampleprop,breaks=50)
hist(yy$TesterinMated_q025,breaks=50)
hist(yy$TesterinMated_q975,breaks=50)

hist(yy$TesterVirgin_q975,breaks=50)
hist(yy$TesterVirgin_AI_Bayes_pval,breaks=50)
hist(yy$AI_Mated_decision,breaks=50)
hist(yy$AI_Virgin_decision,breaks=50)
hist(yy$AI_diffinVirginandMated,breaks=50)
hist(yy$TesterinMated_mean,breaks=50)
hist(yy$TesterVirgin_mean,breaks=50)
hist(yy$alpha_postmean,breaks=50)
hist(yy$delta_postmean,breaks=50)

dev.off()



#Import the filtered dataset. HAve to ask the differences between the two
zz<-read.sas7bdat("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/ase_extended/sas_data/arg_filter_w_genes.sas7bdat")
write.csv(zz,"/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/arg_filter_w_genes.sas7bdat.csv",quote=F,row.names=F)
ww<-fread("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/arg_filter_w_genes.sas7bdat.csv",data.table=F)

pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/TesterinMated_mean_vs_TesterinMated_sampleprop.pdf")
plot(ww$TesterinMated_mean,ww$TesterinMated_sampleprop,pch=19,cex=0.5)
myreg<- lm(ww$TesterinMated_sampleprop~ww$TesterinMated_mean)
abline(myreg,col="red")
abline(0,1,col="blue")
dev.off()



#Plot distribution of theta in Mated and Virgin
pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/Justin2A.pdf")
plot(density(ww$TesterinMated_mean),main="arg_filter")
lines(density(ww$TesterVirgin_mean),col="red")
legend("topright",legend=c("Mated","Virgin"),lty=1,col=c("black","red"))
plot(density(yy$TesterinMated_mean),main="extend_library8")
lines(density(yy$TesterVirgin_mean),col="red")
legend("topright",legend=c("Mated","Virgin"),lty=1,col=c("black","red"))
hist(ww$TesterinMated_mean,breaks=50, main= "TesterinMated_mean in arg_filter")
hist(yy$TesterinMated_mean,breaks=50, main= "TesterinMated_mean in extend_library8")
hist(ww$TesterVirgin_mean,breaks=50, main= "TesterVirgin_mean in arg_filter")
hist(yy$TesterVirgin_mean,breaks=50, main= "TesterVirgin_mean in extend_library8")
M_APN<-(ww$counts_M_tester+ww$counts_M_line+ww$counts_M_both)/abs(ww$end_exon-ww$start_exon)
V_APN<-(ww$counts_V_tester+ww$counts_V_line+ww$counts_V_both)/abs(ww$end_exon-ww$start_exon)
plot(density(ww$TesterinMated_mean[M_APN>1&V_APN>1]),main="arg_filter both APN > 1")
lines(density(ww$TesterVirgin_mean[M_APN>1&V_APN>1]),col="red")
Md_APN<-(ww$counts_M_tester+ww$counts_M_line)/abs(ww$end_exon-ww$start_exon)
Vd_APN<-(ww$counts_V_tester+ww$counts_V_line)/abs(ww$end_exon-ww$start_exon)
plot(density(ww$TesterinMated_mean[Md_APN>0.5&Vd_APN>0.5]),main="arg_filter both dAPN > 0.5")
lines(density(ww$TesterVirgin_mean[Md_APN>0.5&Vd_APN>0.5]),col="red")
plot(density(ww$TesterinMated_mean[Md_APN>1&Vd_APN>1]),main="arg_filter both dAPN > 1")
lines(density(ww$TesterVirgin_mean[Md_APN>1&Vd_APN>1]),col="red")
legend("topright",legend=c("Mated","Virgin"),lty=1,col=c("black","red"))
dev.off()

#Plot distribution of theta in Mated and Virgin stratified by line
#This is to see if some line contribute more to the bump. Answer. YES

#On the raw data
pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/density_theta_raw_by_line.pdf")
for(aaa in unique(yy$line))
{
mydf<-yy[yy$line==aaa,]
plot(density(mydf$TesterinMated_mean),main=paste("extend_library8",aaa))
lines(density(mydf$TesterVirgin_mean),col="red")
legend("topright",legend=c("Mated","Virgin"),lty=1,col=c("black","red"))
}
dev.off()

#On the filtered data

pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/density_theta_by_line.pdf")
for(aaa in unique(ww$line))
{
mydf<-ww[ww$line==aaa,]
plot(density(mydf$TesterinMated_mean),main=paste("arg_filter",aaa))
lines(density(mydf$TesterVirgin_mean),col="red")
legend("topright",legend=c("Mated","Virgin"),lty=1,col=c("black","red"))
}
dev.off()


pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/density_theta_sampleprop_by_line.pdf")
for(aaa in unique(ww$line))
{
mydf<-ww[ww$line==aaa,]
plot(density(mydf$TesterinMated_sampleprop),main=paste("arg_filter",aaa))
lines(density(mydf$TesterVirgin_sampleprop),col="red")
legend("topright",legend=c("Mated","Virgin"),lty=1,col=c("black","red"))
}
dev.off()


#The figure above shows a bump in the right tail. Find out what's causing that.

#When bump is 4, the mean is >0.95 in both mated and virgin. (This is the most common case)
upperlimit<-0.95
ww$bump<-0
ww$bump[ww$TesterVirgin_mean>upperlimit&ww$TesterinMated_mean>upperlimit]<-3
ww$bump[ww$TesterVirgin_mean>upperlimit&ww$TesterinMated_mean<=upperlimit]<-2
ww$bump[ww$TesterVirgin_mean<=upperlimit&ww$TesterinMated_mean>upperlimit]<-1
mycol<-"cyan"
pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/findthebump.pdf")
#plot(ww$TesterVirgin_mean,ww$mean_apn_M,pch=19,cex=0.6)
boxplot(ww$mean_apn_M ~ ww$bump,log="y", main = "Bump vs mean_apn_M",col=mycol)
boxplot(ww$counts_M_tester+ww$counts_M_line ~ ww$bump,log="y", main = "Bump vs sum of M tester and line",col=mycol)
boxplot(ww$end_exon-ww$start_exon ~ ww$bump,log="y", main = "Bump vs exon length",col=mycol)
boxplot((ww$counts_M_tester+ww$counts_M_line)/(ww$end_exon-ww$start_exon) ~ ww$bump,log="y", main = "Bump vs AS coverage",col=mycol)
boxplot(ww$qsim_tester ~ ww$bump, main = "Bump vs qsim_tester",col=mycol)
dev.off()
fast<-aggregate(ww,by=list(ww$bump),FUN="median")



#Compare theta in the two datasets but use the "sampleprop". I don't know the difference bewteen the two
pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/Justin2A_sampleprop.pdf")
plot(density(ww$TesterinMated_sampleprop),main="arg_filter")
lines(density(ww$TesterVirgin_sampleprop),col="red")
legend("topright",legend=c("Mated","Virgin"),lty=1,col=c("black","red"))
plot(density(yy$TesterinMated_sampleprop),main="extend_library8")
lines(density(yy$TesterVirgin_sampleprop),col="red")
legend("topright",legend=c("Mated","Virgin"),lty=1,col=c("black","red"))
hist(ww$TesterinMated_sampleprop,breaks=50, main= "TesterinMated_sampleprop in arg_filter")
hist(yy$TesterinMated_sampleprop,breaks=50, main= "TesterinMated_sampleprop in extend_library8")
hist(ww$TesterVirgin_sampleprop,breaks=50, main= "TesterVirgin_sampleprop in arg_filter")
hist(yy$TesterVirgin_sampleprop,breaks=50, main= "TesterVirgin_sampleprop in extend_library8")
M_APN<-(ww$counts_M_tester+ww$counts_M_line+ww$counts_M_both)/abs(ww$end_exon-ww$start_exon)
V_APN<-(ww$counts_V_tester+ww$counts_V_line+ww$counts_V_both)/abs(ww$end_exon-ww$start_exon)
plot(density(ww$TesterinMated_sampleprop[M_APN>1&V_APN>1]),main="arg_filter both APN > 1")
lines(density(ww$TesterVirgin_sampleprop[M_APN>1&V_APN>1]),col="red")
Md_APN<-(ww$counts_M_tester+ww$counts_M_line)/abs(ww$end_exon-ww$start_exon)
Vd_APN<-(ww$counts_V_tester+ww$counts_V_line)/abs(ww$end_exon-ww$start_exon)
plot(density(ww$TesterinMated_sampleprop[Md_APN>0.5&Vd_APN>0.5]),main="arg_filter both dAPN > 0.5")
lines(density(ww$TesterVirgin_sampleprop[Md_APN>0.5&Vd_APN>0.5]),col="red")
plot(density(ww$TesterinMated_sampleprop[Md_APN>1&Vd_APN>1]),main="arg_filter both dAPN > 1")
lines(density(ww$TesterVirgin_sampleprop[Md_APN>1&Vd_APN>1]),col="red")
legend("topright",legend=c("Mated","Virgin"),lty=1,col=c("black","red"))
dev.off()


#When bump is 4, the mean is >0.95 in both mated and virgin. (This is the most common case)
#Alternative stat, usisnt sampleprop
ww$bump<-0
ww$bump[ww$TesterVirgin_sampleprop>0.95&ww$TesterinMated_sampleprop>0.95]<-3
ww$bump[ww$TesterVirgin_sampleprop>0.95&ww$TesterinMated_sampleprop<=0.95]<-2
ww$bump[ww$TesterVirgin_sampleprop<=0.95&ww$TesterinMated_sampleprop>0.95]<-1
mycol<-"cyan"
pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/findthebump_sampleprop.pdf")
boxplot(ww$mean_apn_M ~ ww$bump,log="y", main = "Bump vs mean_apn_M",col=mycol)
boxplot(ww$counts_M_tester+ww$counts_M_line ~ ww$bump,log="y", main = "Bump vs sum of M tester and line",col=mycol)
boxplot(ww$end_exon-ww$start_exon ~ ww$bump,log="y", main = "Bump vs exon length",col=mycol)
boxplot((ww$counts_M_tester+ww$counts_M_line)/(ww$end_exon-ww$start_exon) ~ ww$bump,log="y", main = "Bump vs AS coverage",col=mycol)
boxplot(ww$qsim_tester ~ ww$bump, main = "Bump vs qsim_tester",col=mycol)
dev.off()



#Plot theta in Virgin and Mates in each line
pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/Justin3.pdf")
mylength<-52
perpage<-4
for(aaa in 1:(mylength/perpage))
{
	mymat<-matrix(c(1,2,3,4),2,2,byrow=T)
	layout(mymat)
	for(bbb in perpage:1)
	{
		cat("aaa=",aaa,"bbb=",bbb,"yourline=",perpage*aaa-(bbb-1),"\n")		
		ccc<-perpage*aaa-(bbb-1)		
		tset<-ww[ww$line==new.sig$Group.1[ccc],]
		plot(tset$TesterinMated_mean,tset$TesterVirgin_mean,pch=19,cex=0.5,main=new.sig$Group.1[ccc],xlab=expression(paste("Mated ",hat(theta))),ylab=expression(paste("Virgin ",hat(theta))))
		myreg<- lm(tset$TesterVirgin_mean~tset$TesterinMated_mean)
abline(myreg,col="red")
abline(0,1)
	}
}
dev.off()


#Compute cis and trans contributions
#Equation taken from here:
#https://github.com/McIntyre-Lab/papers/blob/master/fear_ase_2016/scripts/ase_Python/ase_cisEq.py
#Now we do it with the MAted, then we can rewrite for the Virgin

#VERY IMPORTANT: here we do the scaling by ambiguous reads (are we sure that, as stated in the paper, we do the scaling ONLY for Eii?)
#Not for Eti???
ww$Eti<-ww$counts_M_tester
ww$Eii<-ww$counts_M_line/ww$counts_M_both
ww$diffEtiEii <- ww$Eti-ww$Eii
ww$diffEiiEti <- ww$Eii-ww$Eti
ww$sumEtiEii<- ww$Eti + ww$Eii

#Split the data.frame by exons (this will create a list)
#I could have done everything using aggregate, I don't know why I decided to use lists.
#Let's say it was an exercise!
grp<-split(ww,ww$exon_id)
#Create a df with one entry per exon to summarize results
newdf<-data.frame(exon_id=names(grp),stringsAsFactors=F)
newdf$n<-unlist(lapply(grp,nrow))
fake<-lapply(grp,function(i) {sum(i$sumEtiEii)})
newdf$mu<-unlist(fake)/(2*newdf$n)
newdf$sumEti<-unlist(lapply(grp,function(i) {sum(i$Eti)}))

#Now, merge newdf and ww, because we need to perform diffEtiEii/n for each individual exon in each individual line
aa<-merge(ww,newdf,by="exon_id",all=T)
aa$diff_n<-aa$diffEtiEii/aa$n
#Resplit the data.frame by exons (we need to re-split because we laso want to stratify the diff_n column)
grp<-split(aa,aa$exon_id)

#Now, work again on grouped df to compute the cis effects in the tester genotype for each allele
newdf$cis_tester<-unlist(lapply(grp,function(i) {sum(i$diff_n)}))
#Merge again with the extended df, to compute cis effect on all the lines
bb<-merge(aa,newdf[,c("exon_id","cis_tester")],by="exon_id",all=T)
bb$cis_line<-bb$diffEiiEti+bb$cis_tester
bb$trans_tester<-2*(bb$sumEti/bb$n-bb$mu-bb$cis_tester)
bb$trans_line<-2*(bb$Eti - bb$mu - bb$cis_tester) - bb$trans_tester

#Select exons with AI in mated
AIM<-bb[bb$AI_Mated_decision>0,]
#compute mean and variance (should it be done across lines or across exons?)
#IN the paper Justin did by exons
AIM_cis_mean<-aggregate(AIM$cis_line,by=list(AIM$exon_id),FUN=mean)
AIM_cis_sd<-aggregate(AIM$cis_line,by=list(AIM$exon_id),FUN=sd)
AIM_cis_var$x<-AIM_cis_sd$x^2
AIM_cis_var$x[AIM_cis_mean$x<0]<-(-AIM_cis_var$x[AIM_cis_mean$x<0])

AIM_trans_mean<-aggregate(AIM$trans_line,by=list(AIM$exon_id),FUN=mean)
AIM_trans_sd<-aggregate(AIM$trans_line,by=list(AIM$exon_id),FUN=sd)
AIM_trans_var$x<-AIM_trans_sd$x^2
AIM_trans_var$x[AIM_trans_mean$x<0]<-(-AIM_trans_var$x[AIM_trans_mean$x<0])

#Select exons with AI in virgins
AIV<-bb[bb$AI_Virgin_decision>0,]
AIV_cis_mean<-aggregate(AIV$cis_line,by=list(AIV$exon_id),FUN=mean)
AIV_cis_sd<-aggregate(AIV$cis_line,by=list(AIV$exon_id),FUN=sd)
AIV_cis_var$x<-AIV_cis_sd$x^2
AIV_cis_var$x[AIV_cis_mean$x<0]<-(-AIV_cis_var$x[AIV_cis_mean$x<0])

AIV_trans_mean<-aggregate(AIV$trans_line,by=list(AIV$exon_id),FUN=mean)
AIV_trans_sd<-aggregate(AIV$trans_line,by=list(AIV$exon_id),FUN=sd)
AIV_trans_var$x<-AIV_trans_sd$x^2
AIV_trans_var$x[AIV_trans_mean$x<0]<-(-AIV_trans_var$x[AIV_trans_mean$x<0])


#Plot mean and variance of cis and trans estimates in each exon
colcis<-"plum2"
coltrans<-"darkorange"
meanlim<-2000
varlim<-100000000
adjmean<-25
adjvar<-1000
pdf("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/Justin4.pdf")
layout(matrix(c(1,2,3,4),2,2,byrow=T))
plot(density(AIM_cis_mean$x,adjust=adjmean),col=colcis,main="Mated mean",xlim=c(-meanlim,meanlim))
lines(density(AIM_trans_mean$x,adjust=adjmean),col=coltrans)
legend("topleft",legend=c("cis","trans"),lty=1,col=c(colcis,coltrans))
#plot(density(AIM_cis_sd$x,na.rm=T),col=colcis,main="Mated sd")
#lines(density(AIM_trans_sd$x,na.rm=T),col=coltrans)
plot(density(AIM_cis_var$x,na.rm=T,adjust=adjvar),col=colcis,main="Mated variance",xlim=c(-varlim,varlim))
lines(density(AIM_trans_var$x,na.rm=T,adjust=adjvar),col=coltrans)
legend("topleft",legend=c("cis","trans"),lty=1,col=c(colcis,coltrans))
plot(density(AIV_cis_mean$x,adjust=adjmean),col=colcis,main="Virgin mean",xlim=c(-meanlim,meanlim))
lines(density(AIV_trans_mean$x,adjust=adjmean),col=coltrans)
legend("topleft",legend=c("cis","trans"),lty=1,col=c(colcis,coltrans))
#plot(density(AIV_cis_sd$x,na.rm=T),col=colcis,,main="Virgin sd")
#lines(density(AIV_trans_sd$x,na.rm=T),col=coltrans)
plot(density(AIV_cis_var$x,na.rm=T,adjust=adjvar),col=colcis,,main="Virgin variance",xlim=c(-varlim,varlim))
lines(density(AIV_trans_var$x,na.rm=T,adjust=adjvar),col=coltrans)
legend("topleft",legend=c("cis","trans"),lty=1,col=c(colcis,coltrans))
dev.off()

