cd /projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/bayesian_geno_as_env
for STATUS in M V
do
echo "module load lang/r/3.2.3; cd /projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/bayesian_geno_as_env; R --no-save --args /projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/geno_as_environment/in_r365_r907_${STATUS}.csv /projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/geno_as_environment/out_r365_r907_${STATUS}.csv < NBmodel_WITHBOTH8_gammaalphadeltainboth.r >log.out 2>log.err"| qsub -N geno_env -l vmem=2G,walltime=24:00:00
done

