drosophila.biomart<-function(host="www.ensembl.org",touse="ensembl",org="melanogaster",outfile="/projects/novabreed/share/marroni/collaborations/Lauren/GO/GO_slim.txt")
{
library(biomaRt)
mylist<-listMarts(host=host)

mysets<-listDatasets(useMart(touse, host = host))
#Grep organism name in the d and select the corresponding dataset name
mydataset<-mysets$dataset[grep(org,mysets$dataset,ignore.case = T,value=F)]

allattributes<-listAttributes(useDataset(dataset = as.character(mydataset), mart    = useMart(touse,host = host)))
allfilters<-listFilters(useDataset(dataset = as.character(mydataset), mart    = useMart(touse,host = host)))


#Use a given dataset for analysis
myusemart <- useDataset(as.character(mydataset), mart = useMart(touse, host = host))


#Only return the selected gene
# geneSet <- "100247573"
# resultTable <- getBM(attributes = c("ensembl_gene_id","entrezgene","start_position","end_position","description","go_accession"), filter= "entrezgene",values = geneSet, mart = myusemart)

#Get all genes and their annotations
# resultTable <- getBM(attributes=c("ensembl_gene_id","entrezgene","start_position","end_position","description","go_accession"), mart = myusemart)

#Get all genes and their annotations
resultTable <- getBM(attributes=c("ensembl_gene_id","flybase_gene_id","start_position","end_position","go_id","goslim_goa_accession"), mart = myusemart)
write.table(resultTable,outfile,quote=F,row.names=F,sep="\t")
}

reformat.go.parallel<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/GO/GO_slim.txt",outfile="/projects/novabreed/share/marroni/collaborations/Lauren/GO/GO_reformatted.txt",
								ncores=4,fields=c("ensembl_gene_id","start_position","end_position"))
{
library(doMC)
registerDoMC(cores=ncores)
library(data.table)
if(length(grep("go_id",fields))) stop("Maybe you do not know what you are doing! Call Fabio\n")
go<-fread(infile,data.table=F)
go_small<-go[,fields]
go_small<-go_small[!duplicated(go_small),]
go_small$go_accession<-""
pp<-foreach(aaa=1:nrow(go_small),.combine=rbind) %dopar%
{
	cat("Riga",aaa,"di",nrow(go_small),"\n")
	go_small$go_accession[aaa]<- paste(go$go_id[go$ensembl_gene_id==go_small$ensembl_gene_id[aaa]],sep=";",collapse=";")
	data.frame(go_small[aaa,])
}
go_small<-pp
#go_small<-go_small[!duplicated(go_small$ensembl_gene_id),]
write.table(go_small,outfile,quote=F,row.names=F,sep="\t")
}

reformat.goslim.parallel<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/GO/GO_slim.txt",
            outfile="/projects/novabreed/share/marroni/collaborations/Lauren/GO/GO_slim_reformatted.txt",
								ncores=4,fields=c("ensembl_gene_id","start_position","end_position"))
{
library(doMC)
registerDoMC(cores=ncores)
library(data.table)
go<-fread(infile,data.table=F)
go_small<-go[,fields]
go_small<-go_small[!duplicated(go_small),]
go_small$goslim_goa_accession<-""
pp<-foreach(aaa=1:nrow(go_small),.combine=rbind) %dopar%
{
	cat("Riga",aaa,"di",nrow(go_small),"\n")
	go_small$goslim_goa_accession[aaa]<- paste(unique(go$goslim_goa_accession[go$ensembl_gene_id==go_small$ensembl_gene_id[aaa]]),sep=";",collapse=";")
	data.frame(go_small[aaa,])
}
go_small<-pp
go_small<-go_small[!duplicated(go_small$ensembl_gene_id),]
write.table(go_small,outfile,quote=F,row.names=F,sep="\t")
}





topGO.drosophila<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/GO/GO_slim_reformatted.txt",
    outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/GO/GOres.pdf",
    outfile="/projects/novabreed/share/marroni/collaborations/Lauren/GO/GOres.txt",
    gene.file="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Suppl_Table_genes_AI.txt",
    file.for.names="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
    col.to.sel="fisher_Diff_AI_g",pvalue="0.05",go.column="goslim_goa_accession",ontology="BP",top.res=100)
{
library(data.table)
library(topGO)
godata<-fread(infile,data.table=F)
genes<-fread(gene.file,data.table=F)
#Read the file in which the Flybase names are also stored
gene.names<-fread(file.for.names,data.table=F)
gene.names<-gene.names[,c("symbol_cat","FBgn_cat")]
gene.names<-gene.names[!duplicated(gene.names),]
setnames(gene.names,c("Gene_name","FB_name"))
genes<-merge(genes,gene.names,by="Gene_name",all=F)

allmygenes<-genes$FB_name
myInterestingGenes<-genes$FB_name[genes[,col.to.sel]<pvalue]
#Create geneList object to be specified as the allGenes parameter for creating a topGO object
#This object is a named numeric vector including all the genes; genes included in myInterestingGenes have value 1, the others have value 0
finto <- as.integer(allmygenes %in% myInterestingGenes)
finto<-as.numeric(finto)
names(finto) <- allmygenes
#Create the gene2GO object, by analyzing the reformatted GO file (we already created a properly formatted file with the functions above)
mygene2GO<-as.list(strsplit(godata[,go.column],";"))
mygene2GO<-setNames(mygene2GO,godata$ensembl_gene_id)
#Finally create this stupid topGO object
#From here I have some problems!!!!!!
mytopgo<-new("topGOdata",ontology=ontology,allGenes=finto,annot = annFUN.gene2GO, geneSel= topgomerda , gene2GO = mygene2GO)
sampleGOdata<-mytopgo
#Run fisher test
resultFisher <- runTest(sampleGOdata, algorithm = "classic", statistic = "fisher")
#Run Kolmogorov-Smirnov
resultKS <- runTest(sampleGOdata, algorithm = "classic", statistic = "ks")
resultKS.elim <- runTest(sampleGOdata, algorithm = "elim", statistic = "ks")
top.res<-min(top.res,length(resultFisher@score),length(resultKS@score),length(resultKS.elim@score))
#Extract Fisher results
allRes <- GenTable(sampleGOdata, classicFisher = resultFisher,
 classicKS = resultKS, elimKS = resultKS.elim,
 orderBy = "classicFisher", ranksOf = "elimKS", topNodes = top.res)
pValue.classic <- score(resultKS)
pValue.elim <- score(resultKS.elim)[names(pValue.classic)]
gstat <- termStat(sampleGOdata, names(pValue.classic))
gSize <- gstat$Annotated / max(gstat$Annotated) * 4
gCol <- colMap(gstat$Significant)
allRes<-allRes[allRes$classicFisher<=pvalue,]
write.table(allRes,outfile,row.names=F,quote=F,sep="\t")
pdf(outgraph)
plot(pValue.classic, pValue.elim, xlab = "p-value classic", ylab = "p-value elim",
pch = 19, cex = gSize, col = gCol)
# sel.go <- names(pValue.classic)[pValue.elim < pValue.classic]
# cbind(termStat(sampleGOdata, sel.go),
 # elim = pValue.elim[sel.go],
 # classic = pValue.classic[sel.go])
 showSigOfNodes(sampleGOdata, score(resultFisher), firstSigNodes = 5, useInfo = 'all')
dev.off()

}


#Todo: find the names of drosophila genes that can be used to mine KEGG database.

enrich.kegg<-function(gene.file="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Suppl_Table_genes_AI.txt",
            good.names="/projects/novabreed/share/marroni/collaborations/Lauren/GO/databases/GCF_000001215.4_Release_6_plus_ISO1_MT_feature_table.txt",
            kegg.table="/projects/novabreed/share/marroni/collaborations/Lauren/GO/kegg_AI.txt",
            col.to.sel="Diff_AI",
            keggbarplot="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_9.pdf")
{
library(data.table)
library(DOSE)
library(clusterProfiler)
message("Reading gene tables...")
mydata<-fread(gene.file,data.table=F)
mygood<-fread(good.names,data.table=F)
mygood<-mygood[!duplicated(mygood$locus_tag),]
snewnames<-merge(mydata,mygood,by.x="Gene_name",by.y="symbol")
myuniv<-snewnames$locus_tag
myde<-snewnames$locus_tag[snewnames[,col.to.sel]>0]

kk <- enrichKEGG(myde, organism="dme", pvalueCutoff=0.05, universe=myuniv,pAdjustMethod="BH",qvalueCutoff=0.1)

dkk<-kk[1:nrow(kk)]

dkk$geneID<-NULL
dkk$category<-"Genes_with_AI_diff"
fintable<-dkk
myde<-snewnames$locus_tag[snewnames[,col.to.sel]==0]
kk <- enrichKEGG(myde, organism="dme", pvalueCutoff=0.05, universe=myuniv,pAdjustMethod="BH",qvalueCutoff=0.1)
dkk<-kk[1:nrow(kk)]
dkk$geneID<-NULL
dkk$category<-"Genes_without_AI_diff"
fintable<-rbind(fintable,dkk)
write.table(fintable,kegg.table,quote=F,sep="\t",row.names=F)
fintable$logp<--log10(fintable$p.adjust)
#fintable$logp[fintable$category=="Genes_without_AI_diff"]<-(-1)*fintable$logp[fintable$category=="Genes_without_AI_diff"]
fintable$Description<-gsub(" ","\n",fintable$Description)
fintable$col<-"red"
fintable$col[fintable$category=="Genes_without_AI_diff"]<-"blue"
pdf(keggbarplot)
par(mar=c(5,9,4,2))
barplot(fintable$logp,horiz=T,names=fintable$Description,las=1,col=fintable$col, xlab=bquote(italic(-log[10])*~q-value ))
dev.off()
browser()
}


gene.to.kegg<-function(good.names="/projects/novabreed/share/marroni/collaborations/Lauren/GO/databases/GCF_000001215.4_Release_6_plus_ISO1_MT_feature_table.txt",
            out.table="/projects/novabreed/share/marroni/collaborations/Lauren/GO/cat_tokegg.txt")
{



#Not used, only here for remembering how to download the database
message("Downloading latest KEGG database...")
mykegg<-download_KEGG(species="dme",keyType="kegg")
message("Merging the two different names versions...")
fullkegg<-merge(mykegg$KEGGPATHID2NAME,mykegg$KEGGPATHID2EXTID,by="from")
setnames(fullkegg,c("Kegg","Kegg_desc","locus_tag"))
allgenes<-fread(good.names,data.table=F)
veryfull<-merge(fullkegg,allgenes,by="locus_tag")
veryfull<-veryfull[,c("symbol","locus_tag","Kegg","Kegg_desc")]
veryfull<-veryfull[!duplicated(veryfull),]
write.table(veryfull,out.table,row.names=F,quote=F,sep="\t")

}



#OLD STUFF BELOW


topgomerda<-function(x)
{
y<-x>0
return(y)
}

colMap <- function(x) {
  .col <- rep(rev(heat.colors(length(unique(x)))), time = table(x))
  return(.col[match(1:length(x), order(x))])
}


prove.topGO<-function()
{
sampleGOdata <- new("topGOdata",
 description = "Simple session", ontology = "BP",
 allGenes = geneList, geneSel = topDiffGenes,
 nodeSize = 10,
 annot = annFUN.db, affyLib = affyLib)

}

#Given
sel.genes.santi<-function(cuff.file="/projects/novabreed/share/marroni/collaborations/santi/CDS_Santi.txt",sample1="H",sample2="D",col.to.keep="gene_entrez")
{
library(data.table)
all<-fread(cuff.file,data.table=F)
all<-all[all$sample_1==sample1&all$sample_2==sample2,]
all<-all[all[,col.to.keep]!="",]
return(list(allgenes=all[,col.to.keep],sig.genes=all[all$significant=="yes",col.to.keep]))
browser()

}


