library(data.table)

#Compare computations of cis and trans contribution performed in the paper and with my method (they should be equivalent, given that I copied Justin's way!!!)

#Old is Table S3 of Justin's paper. This includes estimates of cis and trans
oldres<-fread("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/Supplemental_Table3_lmm1.csv",data.table=F)


#From this dataset we can get expression data
oldraw<-fread("/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/Supplemental_Data2_lmm3.csv",data.table=F)
oldraw$linecount<-oldraw$LINE_TOTAL_1+oldraw$LINE_TOTAL_2+oldraw$LINE_TOTAL_3
oldraw$testercount<-oldraw$TESTER_TOTAL_1+oldraw$TESTER_TOTAL_2+oldraw$TESTER_TOTAL_3
#Sadly enough I don't have the realt both. At least I set both to the sum of reads that could be discriminated
oldraw$both<-oldraw$linecount+oldraw$testercount
sraw<-oldraw[,c("line","mating_status","exon_ID_cat","testercount","linecount","both")]

sraw<-sraw[sraw$mating_status=="M",]
sraw<-sraw[sraw$both>0,]

source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/compute_cis_trans.r")
ff<-cistrans(sraw,exon="exon_ID_cat",paternal_counts="testercount",maternal_counts="linecount", both_counts="both")


smold<-oldres[,c("genotype","mating_status","cis_effects_genotype","trans_effects_genotype","Flybase551_FBgn")]
smold<-smold[!is.na(smold$cis_effects_genotype),]
smold<-smold[smold$mating_status=="M",]


myex<-unique(ff$exon_ID_cat)
myex<-unique(unlist(strsplit(myex,split="\\|")))
myex<-unlist(unique(lapply(strsplit(myex,split=":"),"[",1)))
pino<-data.frame()
for (aaa in 1:length(myex))
{
cat("Exon",aaa,"of",length(myex),"\n")
checkold<-smold[grep(myex[aaa],smold$Flybase551_FBgn),]
if(NROW(checkold)==0) next
cat("Mi fermo!\n")
checknew<-ff[grep(myex[aaa],ff$exon_ID_cat),]
pp<-merge(checknew,checkold,by.x="line",by.y="genotype",all=F)
pino<-rbind(pino,pp[sample(seq(1,nrow(pp)),1),])
}

#Something's wrong here

#We had a lot of NaNs. Now I reran the script by first removing all the instances in which both tester and line
#had zero counts. These are the instances giving NaNs.


#Pino is our final data.frame!!!
#For each instance in which we have co-occurrence of data between old and new we select one event. 
#Why? Because the way in which they are calculated and aggregated are different
#And there is the risk to sample the same data twice. If I merge the results by line and take only one point I am sure 
#that I take only unique events. The data points should be quite a low, anyhow.



