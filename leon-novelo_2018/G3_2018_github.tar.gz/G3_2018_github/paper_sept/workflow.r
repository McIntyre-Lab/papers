what.to.do=(commandArgs(TRUE))
if(length(what.to.do)>0)
{
	status<-as.character(unlist(strsplit(what.to.do[1],"="))[2])
}
#PROBLEM WITH OLD CLEANING: Filtered data set has some problems (e.g. one fusion is present 30 times in one line!)


#I don't know where the bug is, and I leave it alone.
#I performed my filtering on the raw data and obtained a clean file.
#Raw data has fusion names, but no gene name or position
#I use Justin info on the position of fusions (from supplementary data in the paper)

if(status=="best_cleaning")
{
    source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/clean_2016.r")
    #Private arguments
    exon.dev<-as.numeric(as.character(unlist(strsplit(what.to.do[2],"="))[2]))
    line.dev<-as.numeric(as.character(unlist(strsplit(what.to.do[3],"="))[2]))
    min.line.per.exon<-as.numeric(as.character(unlist(strsplit(what.to.do[4],"="))[2]))
    min.exon.per.line<-as.numeric(as.character(unlist(strsplit(what.to.do[5],"="))[2]))
	outfile<-as.character(unlist(strsplit(what.to.do[6],"="))[2])
    graphfile<-as.character(unlist(strsplit(what.to.do[7],"="))[2])
    #End of private arguments
    
    clean.2016(	outfile=outfile,
        max.fusion.dev.mean=exon.dev,max.fusion.dev.median=exon.dev,
        ratio.to.total=0.01,max.dev.mean=line.dev,max.dev.median=line.dev,min.line.per.fusion=2,min.fusions.per.line=250)
    #Plot the density of the current exon.dev and line.dev
    do.density.together(infile=outfile,outfile=graphfile)
}


if(status=="plot_together")
{
    #Private arguments
    indir<-as.character(unlist(strsplit(what.to.do[2],"="))[2])
    outfile<-as.character(unlist(strsplit(what.to.do[3],"="))[2])
    #End of private arguments
    source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/clean_2016.r")
    loop.density.together(indir=indir,outfile=outfile)
    #For the paper
    do.density.together(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
                        outfile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_S5.pdf")
}

if(status=="some_more_analysis")
{
    source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/clean_2016.r")
    #Plot an histogram with random expectation of ASE distribution in exons (takes about 35 minutes)
    check.dist.rand()
    #Plot an histogram with random expectation of ASE distribution in genes
    check.dist.rand(bygene=T,max.num=15,outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/gene_dist_15.pdf",
                    outtable="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/gene_dist_15.txt")
    check.dist.rand(do.log=T)
    #Prepare a table in which for each cat_name of our file we look for the kegg pathway. This will be used for tables 8 and 9
    source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/annotation.r")
    gene.to.kegg()

    #Plots a table with the genes with a high proportion of exons showing different AI between Mated and Virgin
    source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/gene_analysis_ext.r")
    top.ext(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
        outfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/new_only_ext_genes_AI_diff_VM.txt",
        outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/tables/new_only_ext_genes_AI_diff_VM.pdf")
    exon.summary()
    plot.AI.numbers()
    #gene.summary()
    
    #We do not perform the gene.summary.short analysis anymore, since it gives similar results to the original, but the aggregation causes loss of information at exon level and I don't like it.
    #gene.summary.short()
    #Write a text file with several summary statistics
    summary.statistics()
    #Provide tables with summary statistics relevant to environmental variation of ASE
    summary.MV()
    #test.excess.AI.in.lines()
    test.excess.AI.in.lines(outpdf="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_9.pdf")
    AI.across.env(outfile1="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Table_5.txt")
    lines.cov.plot(outfile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_S6.pdf")
    #This function below doesn't write to file, is just to explore results. I used it to check number of reads mapping in r149.
    investigate.single()
    }
if(status=="compare_old_new")
{
    source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/compare_old_new.r")
    several.tables(out1="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Table_3.txt")
    compare.old.new(pdf.compare.significant="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_3.pdf")
    cov.and.diff.AI(outfile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_4.pdf")
    #AI.oldnew(outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_S_box_AI_changehere.pdf")
    AI.oldnew(outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_6.pdf")
    BA.oldnew(outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_7.pdf",out.table="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Table_S1.txt",
    out.table2="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Table_Svecchia.txt")
    concordance.table(out.table="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Table_S2.txt")
    AIMV.oldnew()
    AIMV.oldnew(outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_7.pdf")
    exons.genes.AI(outfile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Table_4.txt",
                    outgraph="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_8.pdf")
    source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/gene_analysis_ext.r")
    exons.AI.old.new.plot(outfile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_S3.pdf",status="Mated",plotme=T)
    exons.AI.old.new.plot(outfile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_S4.pdf",status="Virgin",plotme=T)
    exons.AI.plot(outfile="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_S7.pdf")

}


if(status=="do_GO")

{
source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/annotation.r")
#The fetching of data from biomaRt is done only once. For this reason I am now commenting it.
#The commands below are needed only once
drosophila.biomart()
reformat.go.parallel()
reformat.goslim.parallel()
#Endo of once-only commands
for (ontology in c("BP","CC","MF"))
{
#GOslim
topGO.drosophila(outgraph=paste("/projects/novabreed/share/marroni/collaborations/Lauren/GO/GO_slim_res_",ontology,".pdf",sep=""),
    outfile=paste("/projects/novabreed/share/marroni/collaborations/Lauren/GO/GO_slim_res_",ontology,".txt",sep=""),
    gene.file="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Suppl_Table_genes_AI.txt",
    file.for.names="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
    col.to.sel="fisher_Diff_AI_g",pvalue="0.05",go.column="goslim_goa_accession",ontology=ontology,top.res=50)
#GO
topGO.drosophila(infile="/projects/novabreed/share/marroni/collaborations/Lauren/GO/GO_reformatted.txt",
    outgraph=paste("/projects/novabreed/share/marroni/collaborations/Lauren/GO/GO_res_",ontology,".pdf",sep=""),
    outfile=paste("/projects/novabreed/share/marroni/collaborations/Lauren/GO/GO_res_",ontology,".txt",sep=""),
    gene.file="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Suppl_Table_genes_AI.txt",
    file.for.names="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
    col.to.sel="fisher_Diff_AI_g",pvalue="0.05",go.column="go_accession",ontology=ontology,top.res=50)
}
}

if(status=="do_kegg")
{
source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/annotation.r")
enrich.kegg(keggbarplot="/projects/novabreed/share/marroni/collaborations/Lauren/paper_ase/Figures_Tables/Figure_10.pdf")

}


if(status=="geno_env")
{
#Select two genotypes and run analysis on them as if they were environments
source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/geno_as_env.r")


}

#FIN QUI!!!

if(status=="all")
{
#Do a lot of base analysis, including the import of data from SAS (import takes a while!)
source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/base_analysis.r")



#
#The output of the previous commands is fed to the following
#Perform some base comparisons with previous results
#We also write a file which is the merge of old and new data. All the work should be performed on that file
source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/compare_old_new.r")
compare.old.new()
#Boxplot of thetas stratified by evidence of differential AI according to old empiri, new empiric and new stat test
AIMV.oldnew()
AI.oldnew()
AI.oldnew(virgin=F)

#Plot the proportion of exons showing allelic imbalance in Mated, Tester of between the two
source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/gene_analysis_ext.r")
exons.AI.plot()
exons.AI.plot(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/extend_library8.clean.csv",outfile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/plots/Justin2B_only_ext.pdf")
exons.AI.old.new.plot()
#Plots a table with the genes with a high proportion of exons showing different AI between Mated and Virgin
all.old()


#Perform analysis on coverage and print the 3X3 table
source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/coverage.related.r")
cov.ase()




#Perform analysis of genes
source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/gene_analysis_ext.r")
all.old()

#Add estimates of cis and trans to the data set
source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/clean_2016.r")
add.cis.trans()
plot.cis.trans()

#Compare, on the new data set, the method in python for computing cis and trans, and the method in R.
source("/projects/novabreed/share/marroni/collaborations/Lauren/scripts/paper_sept/compare_old_new.r")

}
