solve.roX1<-function(gene.name="roX1",fbname="FBgn0019661",fusion_id="F13178_SI",
                    orig.file="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/extend_library8_18jan2016.csv",
                    gene.info.file="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/Supplemental_Data2_lmm3.csv")
{
library(data.table)
orig<-fread(orig.file,data.table=F)
nrow(orig[orig$fusion_id==fusion_id,])

#We have 66 rows corresponding to roX1 in the original file.
gene.info<-fread(gene.info.file,data.table=F)
nrow(gene.info[gene.info$exonic_region==fusion_id,])
#In gene.info, which is supplementary material from Justin paper, we also have epxression in roX1

rox<-orig[orig$fusion_id==fusion_id,]
#############################################################
mean(rox$counts_M_tester/rox$counts_M_line)
#4.780451
mean(orig$counts_M_tester/orig$counts_M_line)
#5.857416
mean(rox$counts_V_tester/rox$counts_V_line)
#1.49286
mean(orig$counts_V_tester/orig$counts_V_line)
#5.418987
#This data seem to suggest that in Virgin flies there is less AI. Is it true?
###############################################################
mean(rox$AI_Mated_decision)
#0.2878788
mean(orig$AI_Mated_decision)
#0.1522037
mean(rox$AI_Virgin_decision)
#0.2272727
mean(orig$AI_Virgin_decision)
#0.17437
#Apparently yes. Is it because expression in Virgin is lower?
mean(rox$counts_M_tester+rox$counts_M_line+rox$counts_M_both)
#198.4535
mean(orig$counts_M_tester+orig$counts_M_line+orig$counts_M_both)
#614.379
mean(rox$counts_V_tester+rox$counts_V_line+rox$counts_V_both)
#201.2652
mean(orig$counts_V_tester+orig$counts_V_line+orig$counts_V_both)
#629.4216
#Apparently not.

browser()
}

position.rox<-function(main.path="/projects/novabreed/share/marroni/collaborations/Lauren/ROX1_issue/RNAseq_data/ENCODE/",
                    folders=c("ENCSR316TMK","ENCSR627PBM","ENCSR866VWI", "ENCSR218XXK", "ENCSR881MQF", "ENCSR385YRP"),
                    all.file="/tophat_all_gene/seq_count.txt",nc.file="/tophat_out/seq_count.txt",fbname="FBgn0019661",ncname="FBtr0070634",
                    outfile="/projects/novabreed/share/marroni/collaborations/Lauren/ROX1_issue/RNAseq_data/ENCODE/rank.rox1.txt",also.nc=F)
{
library(data.table)
generank<-ncrank<-rep(NA,length(folders))
for (aaa in 1:length(folders))
{
    if(also.nc)
    {
        pp<-fread(paste(main.path,folders[aaa],nc.file,sep=""),data.table=F)
        pp<-pp[order(pp$V1,decreasing=T),]
        roxrank<-which(pp$V2==ncname)
        genenumber<-nrow(pp)
        ncrank[aaa]<-paste(roxrank,"/",genenumber,sep="")
    }
    pp<-fread(paste(main.path,folders[aaa],all.file,sep=""),data.table=F)
    pp<-pp[order(pp$V1,decreasing=T),]
    roxrank<-which(pp$V2==fbname)
    genenumber<-nrow(pp)
    generank[aaa]<-paste(roxrank,"/",genenumber,sep="")
}
mydf<-data.frame(folders,ncrank,generank)
write.table(mydf,outfile,sep="\t",quote=F,row.names=F)
}

rank.rox.our.data<-function(infile="/projects/novabreed/share/marroni/collaborations/Lauren/agerken/data_fabio/minline_1_minfusion_1/extend_library8_clean_exon_max_dev_1_line_max_dev_1.csv",
                        fbname="FBgn0019661")
{
library(data.table)
pp<-fread(infile,data.table=F)
pp$counts_M_total<-pp$counts_M_tester+pp$counts_M_line+pp$counts_M_both
pp$counts_V_total<-pp$counts_V_tester+pp$counts_V_line+pp$counts_V_both
ff<-aggregate(cbind(pp$counts_M_total,pp$counts_V_total),by=list(pp$FBgn_cat),FUN=mean)
setnames(ff,c("gene","M","V"))
morder<-ff[order(ff$M,decreasing=T),]
which(morder$gene==fbname)
vorder<-ff[order(ff$V,decreasing=T),]
which(vorder$gene==fbname)

}