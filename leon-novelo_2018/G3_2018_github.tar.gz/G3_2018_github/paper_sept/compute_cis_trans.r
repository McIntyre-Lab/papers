#Compute cis and trans contributions
#Equation taken from here:
#https://github.com/McIntyre-Lab/papers/blob/master/fear_ase_2016/scripts/ase_Python/ase_cisEq.py
#Now we do it with the Mated, then we can rewrite for the Virgin

#NB in our case, we stick to the fact that the tester is paternal and line is maternal.

# ww: a data frame containing at least the following fields (we could do without the data.frame and only the fields, but prefer not to)
# 	exon: name of the column carrying exon name
# 	paternal_counts: name of the column carrying counts of reads that have been assigned to the paternal allele
# 	maternal_counts: name of the column carrying counts of reads that have been assigned to the maternal allele
#   both_counts: name of the column carrying counts of reads that align equally well to both

cistrans<-function(ww,exon="exon_id",paternal_counts="counts_M_tester",maternal_counts="counts_M_line", both_counts="counts_M_both")
{
#VERY IMPORTANT: here we do the scaling by ambiguous reads (are we sure that, as stated in the paper, we do the scaling ONLY for Eii?)
#Not for Eti???
#Change name of the exon column
names(ww)[names(ww)==exon]<-"exon_id"
########################

ww$Eti<-ww[,paternal_counts]
ww$Eii<-ww[,maternal_counts]/ww[,both_counts]
ww$diffEtiEii <- ww$Eti-ww$Eii
ww$diffEiiEti <- ww$Eii-ww$Eti
ww$sumEtiEii<- ww$Eti + ww$Eii

#Split the data.frame by exons (this will create a list)
#I could have done everything using aggregate, I don't know why I decided to use lists.
#Let's say it was an exercise!
grp<-split(ww,ww$exon_id)
#Create a df with one entry per exon to summarize results
newdf<-data.frame(exon_id=names(grp),stringsAsFactors=F)
newdf$n<-unlist(lapply(grp,nrow))
fake<-lapply(grp,function(i) {sum(i$sumEtiEii)})
newdf$mu<-unlist(fake)/(2*newdf$n)
newdf$sumEti<-unlist(lapply(grp,function(i) {sum(i$Eti)}))

#Now, merge newdf and ww, because we need to perform diffEtiEii/n for each individual exon in each individual line
aa<-merge(ww,newdf,by="exon_id",all=T)
aa$diff_n<-aa$diffEtiEii/aa$n
#Resplit the data.frame by exons (we need to re-split because we laso want to stratify the diff_n column)
grp<-split(aa,aa$exon_id)

#Now, work again on grouped df to compute the cis effects in the tester genotype for each allele
newdf$cis_tester<-unlist(lapply(grp,function(i) {sum(i$diff_n)}))
#Merge again with the extended df, to compute cis effect on all the lines
bb<-merge(aa,newdf[,c("exon_id","cis_tester")],by="exon_id",all=T)
bb$cis_line<-bb$diffEiiEti+bb$cis_tester
bb$trans_tester<-2*(bb$sumEti/bb$n-bb$mu-bb$cis_tester)
bb$trans_line<-2*(bb$Eti - bb$mu - bb$cis_tester) - bb$trans_tester

#Reassiqn original name
names(bb)[names(bb)=="exon_id"]<-exon
cc<-bb[,c("cis_line","trans_line","cis_tester","trans_tester")]
return(cc)
}
