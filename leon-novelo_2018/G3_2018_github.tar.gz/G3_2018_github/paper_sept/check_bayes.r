check.problematic<-function(
	infile="/projects/novabreed/share/marroni/collaborations/Lauren/RNA_alignments/ext_bayesian/input_LR_MV.csv",
	problematic.file="/projects/novabreed/share/marroni/collaborations/Lauren/RNA_alignments/ext_bayesian/problematic_fusions.txt")
{
library(data.table)
mydat<-fread(infile)
problematic.exons<-scan(problematic.file,what="",sep="\n")
qline<-qtester<-rep(NA,length(problematic.exons))
for(aaa in 1:length(problematic.exons))
{
myindex<-grep(problematic.exons[aaa],mydat$fusion_id)
cat(myindex,"\n")
if(length(myindex)==0) next
qline[aaa]<-mydat$qsim_line[myindex]
qtester[aaa]<-mydat$qsim_tester[myindex]
}

}



