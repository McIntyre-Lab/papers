# Load modules
for MYLINE in 2 3
do

module load lang/python/2.7.3

#Set directories
PROJ=/projects/novabreed/share/marroni/collaborations/Lauren
ORIG=$PROJ/dna_se
if [ ! -e $ORIG ]; then mkdir -p $ORIG; fi
SCRIPTS=$PROJ/scripts

OUTPUT=$PROJ/fastq_split_dups
if [ ! -e $OUTPUT ]; then mkdir -p $OUTPUT; fi

OUTCOUNTS=$PROJ/duplicate_counts
if [ ! -e $OUTCOUNTS ]; then mkdir -p $OUTCOUNTS; fi

OUTLOGS=$PROJ/duplicate_counts/logs
if [ ! -e $OUTLOGS ]; then mkdir -p $OUTLOGS; fi

## Design file
     DESIGN_FILE=$PROJ/design_files/p_noir_vcr18_dna_design.csv
     DESIGN=$(cat $DESIGN_FILE | head -n $MYLINE | tail -n 1)
     IFS=',' read -ra ARRAY <<< "$DESIGN"

FOLDER=${ARRAY[0]}
READ1=${ARRAY[1]}
READ2=${ARRAY[2]}
NAME=${READ1/_R1/}

$SCRIPTS/fastqSplitDups.py -r1 $FOLDER/${READ1}.fastq --outdir $OUTPUT -o $OUTCOUNTS/${NAME}_duplicate_counts_summary.csv -t $OUTCOUNTS/${NAME}_001_duplicate_sequences.tsv -g $OUTLOGS/${NAME}_001_fastqSplitDups.log

done

