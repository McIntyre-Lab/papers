#!/bin/bash

for PBS_ARRAYID in 2 3 4 5
do 

# PBS_ARRAYID=2

# Load modules

module load lang/python/2.7.3

#Set directories
PROJ=/projects/novabreed/share/marroni/collaborations/Lauren
ORIG=/projects/novabreed/share/marroni/collaborations/Lauren/fastq_dna_pnoir_VCR18
QC=/projects/novabreed/share/marroni/collaborations/Lauren/qc_dna_p_noir_vcr18_pe
MCPYTHON=/projects/novabreed/share/marroni/collaborations/Lauren/qc_pipeline/scripts

OUTPUT=$QC/fastq_split_dups
if [ ! -e $OUTPUT ]; then mkdir -p $OUTPUT; fi

OUTCOUNTS=$QC/duplicate_counts
if [ ! -e $OUTCOUNTS ]; then mkdir -p $OUTCOUNTS; fi

OUTLOGS=$QC/duplicate_counts/logs
if [ ! -e $OUTLOGS ]; then mkdir -p $OUTLOGS; fi

## Design file (for paired end reads)
     DESIGN_FILE=$PROJ/design_files/qc_design_file.csv

     DESIGN=$(cat $DESIGN_FILE | head -n $PBS_ARRAYID | tail -n 1)
     IFS=',' read -ra ARRAY <<< "$DESIGN"

     LOCATION=${ARRAY[0]}
     READ=${ARRAY[1]}.fastq
     NAME=${ARRAY[2]}

#Comment by Fabio
#I modified the script to incorporate -r2 as well

$MCPYTHON/fastqSplitDups.py -r1 $ORIG/${READ} -r2 $ORIG/${READ/R1/R2} --outdir $OUTPUT -o $OUTCOUNTS/${NAME}_duplicate_counts_summary.csv -t $OUTCOUNTS/${NAME}_001_duplicate_sequences.tsv -g $OUTLOGS/${NAME}_001_fastqSplitDups.log

done
