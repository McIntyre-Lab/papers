# Scripts used in the paper: Direct Testing for Allele-Specific Expression Differences Between Conditions
https://doi.org/10.1534/g3.117.300139

Most of the scripts are shared with previous work performed on AI in McIntyre lab.
They deal with aligning reads to the two different references, computing bias, and counting the number of reads mapping to each reference.
The folder *paper_sept* contains the scripts and R functions specifically developed for the paper.
The folder *Model_and_Test_Set* contains the "official" implementation of the Bayesian model for estimation of difference of AI between conditions, 
including a test input data. 
The folder *data* contains the cleaned datafile (obtained with slight modifications from Fear et al 2016) used for most analysis.